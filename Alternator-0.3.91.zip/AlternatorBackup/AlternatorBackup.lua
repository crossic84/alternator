-- Alternator Backup companion for WoW 5.4.8
-- Stores lightweight, account-wide Character Statistics recovery snapshots in a
-- separate physical SavedVariables file (AlternatorBackup.lua).

local VERSION = "0.3.91"
local BACKUP_VERSION = 6
local MAX_RECENT_SNAPSHOTS = 10
local MAX_DAILY_SNAPSHOTS = 30
local MAX_MANUAL_SNAPSHOTS = 10
local MAX_SAFETY_SNAPSHOTS = 3
local MAX_SNAPSHOTS = MAX_RECENT_SNAPSHOTS + MAX_DAILY_SNAPSHOTS + MAX_MANUAL_SNAPSHOTS + MAX_SAFETY_SNAPSHOTS
local suppressNextLogoutBackup = false
local pendingSessionIds = {}

local function DeepCopy(value, seen)
    if type(value) ~= "table" then return value end
    seen = seen or {}
    if seen[value] then return seen[value] end
    local copy = {}
    seen[value] = copy
    for k, v in pairs(value) do
        copy[DeepCopy(k, seen)] = DeepCopy(v, seen)
    end
    return copy
end

local function CountEntries(tbl)
    local count = 0
    if type(tbl) == "table" then
        for _ in pairs(tbl) do count = count + 1 end
    end
    return count
end

local function BuildDayKey(timestamp)
    if type(timestamp) ~= "number" or timestamp <= 0 or type(date) ~= "function" then return nil end
    local info = date("*t", timestamp)
    if type(info) ~= "table" then return nil end
    return string.format("%04d%02d%02d", tonumber(info.year) or 0, tonumber(info.month) or 0, tonumber(info.day) or 0)
end

local function SnapshotTime(snapshot)
    return type(snapshot) == "table" and (tonumber(snapshot.backupAt) or 0) or 0
end

local function BuildSourceInfo(sourceInfo)
    sourceInfo = type(sourceInfo) == "table" and sourceInfo or {}
    local name = sourceInfo.name
    local realm = sourceInfo.realm
    local class = sourceInfo.class
    if (not name or name == "") and type(UnitName) == "function" then name = UnitName("player") end
    if (not realm or realm == "") and type(GetRealmName) == "function" then realm = GetRealmName() end
    if (not class or class == "") and type(UnitClass) == "function" then
        local _, classFile = UnitClass("player")
        class = classFile
    end
    return {
        name = name or "Unknown",
        realm = realm or "Unknown",
        class = class or "UNKNOWN",
    }
end

-- Only capture data needed to recover Character Statistics. The old implementation
-- copied the whole AlternatorDB 10-40 times, which made SavedVariables enormous,
-- caused very slow logout, and could make the backup file fail to persist cleanly.
local function BuildStatisticsPayload(db)
    local payload = { characters = {} }
    if type(db) ~= "table" or type(db.characters) ~= "table" then return payload end

    for charKey, char in pairs(db.characters) do
        if type(char) == "table" and type(char.statistics) == "table" then
            local statistics = char.statistics
            if next(statistics) ~= nil then
                payload.characters[charKey] = {
                    name = char.name,
                    realm = char.realm,
                    class = char.class,
                    guid = char.guid,
                    level = char.level,
                    statisticsScannedAt = char.statisticsScannedAt,
                    statistics = DeepCopy(statistics),
                }
            end
        end
    end
    return payload
end

local function CountStatisticsCharactersFromPayload(payload)
    return type(payload) == "table" and CountEntries(payload.characters) or 0
end

local function CountStatisticsHistoryBucketsFromPayload(payload)
    local count = 0
    if type(payload) == "table" and type(payload.characters) == "table" then
        for _, char in pairs(payload.characters) do
            local history = type(char) == "table" and type(char.statistics) == "table" and char.statistics.history or nil
            if type(history) == "table" then
                for _ in pairs(history) do count = count + 1 end
            end
        end
    end
    return count
end

local function ExtractStatisticsPayloadFromLegacyDatabase(database)
    return BuildStatisticsPayload(database)
end

local function SortIdsNewestFirst(db, ids)
    table.sort(ids, function(a, b)
        return SnapshotTime(db.snapshotStore and db.snapshotStore[a]) > SnapshotTime(db.snapshotStore and db.snapshotStore[b])
    end)
end

local function NewSnapshotId(db, stamp)
    db.nextSnapshotSerial = (tonumber(db.nextSnapshotSerial) or 0) + 1
    return tostring(tonumber(stamp) or 0) .. ":" .. tostring(db.nextSnapshotSerial)
end

local function AddSnapshotToStore(db, snapshot)
    local id = NewSnapshotId(db, SnapshotTime(snapshot))
    db.snapshotStore[id] = snapshot
    return id
end

local function TrimRecent(db)
    while #db.recentIds > MAX_RECENT_SNAPSHOTS do table.remove(db.recentIds) end
end

local function TrimManual(db)
    while #db.manualIds > MAX_MANUAL_SNAPSHOTS do table.remove(db.manualIds) end
end

local function TrimSafety(db)
    while #db.safetyIds > MAX_SAFETY_SNAPSHOTS do table.remove(db.safetyIds) end
end

local function RebuildDailyArchive(db, currentStamp)
    local currentDay = BuildDayKey(tonumber(currentStamp) or 0)
    local newestByDay = {}

    for _, id in ipairs(db.dailyIds or {}) do
        local snapshot = db.snapshotStore[id]
        local dayKey = BuildDayKey(SnapshotTime(snapshot))
        if dayKey and dayKey ~= currentDay then
            local previousId = newestByDay[dayKey]
            if not previousId or SnapshotTime(snapshot) > SnapshotTime(db.snapshotStore[previousId]) then
                newestByDay[dayKey] = id
            end
        end
    end

    for _, id in ipairs(db.recentIds or {}) do
        local snapshot = db.snapshotStore[id]
        local dayKey = BuildDayKey(SnapshotTime(snapshot))
        if dayKey and dayKey ~= currentDay then
            local previousId = newestByDay[dayKey]
            if not previousId or SnapshotTime(snapshot) > SnapshotTime(db.snapshotStore[previousId]) then
                newestByDay[dayKey] = id
            end
        end
    end

    local dailyIds = {}
    for _, id in pairs(newestByDay) do table.insert(dailyIds, id) end
    SortIdsNewestFirst(db, dailyIds)
    while #dailyIds > MAX_DAILY_SNAPSHOTS do table.remove(dailyIds) end
    db.dailyIds = dailyIds
end

local function CleanupSnapshotStore(db)
    local used = {}
    for _, id in ipairs(db.recentIds or {}) do used[id] = true end
    for _, id in ipairs(db.dailyIds or {}) do used[id] = true end
    for _, id in ipairs(db.manualIds or {}) do used[id] = true end
    for _, id in ipairs(db.safetyIds or {}) do used[id] = true end
    for id in pairs(db.snapshotStore or {}) do
        if not used[id] then db.snapshotStore[id] = nil end
    end
end

local function CountStatisticsCharactersInDatabase(database)
    local count = 0
    if type(database) == "table" and type(database.characters) == "table" then
        for _, char in pairs(database.characters) do
            if type(char) == "table" and type(char.statistics) == "table" and next(char.statistics) ~= nil then
                count = count + 1
            end
        end
    end
    return count
end

local function CountStatisticsHistoryBucketsInDatabase(database)
    local count = 0
    if type(database) == "table" and type(database.characters) == "table" then
        for _, char in pairs(database.characters) do
            local history = type(char) == "table" and type(char.statistics) == "table" and char.statistics.history or nil
            if type(history) == "table" then
                for _ in pairs(history) do count = count + 1 end
            end
        end
    end
    return count
end

local function NormalizeSnapshot(snapshot)
    if type(snapshot) ~= "table" then return nil end

    -- New manual full backups keep a complete AlternatorDB copy. They are kept
    -- outside the automatic Recent/Daily statistics rotation.
    if snapshot.kind == "full" or type(snapshot.fullDatabase) == "table" then
        snapshot.kind = "full"
        if type(snapshot.fullDatabase) ~= "table" and type(snapshot.database) == "table" then
            snapshot.fullDatabase = snapshot.database
        end
        snapshot.database = nil
        snapshot.dbCharacterCount = tonumber(snapshot.dbCharacterCount) or CountEntries(snapshot.fullDatabase and snapshot.fullDatabase.characters)
        snapshot.statisticsCharacterCount = tonumber(snapshot.statisticsCharacterCount) or CountStatisticsCharactersInDatabase(snapshot.fullDatabase)
        snapshot.historyBucketCount = tonumber(snapshot.historyBucketCount) or CountStatisticsHistoryBucketsInDatabase(snapshot.fullDatabase)
        return snapshot
    end

    snapshot.kind = "statistics"
    if type(snapshot.statisticsPayload) ~= "table" then
        if type(snapshot.database) == "table" then
            snapshot.statisticsPayload = ExtractStatisticsPayloadFromLegacyDatabase(snapshot.database)
        else
            snapshot.statisticsPayload = { characters = {} }
        end
    end
    -- Legacy automatic full snapshots are intentionally reduced to lightweight
    -- Character Statistics data during migration.
    snapshot.database = nil
    snapshot.fullDatabase = nil
    snapshot.statisticsCharacterCount = CountStatisticsCharactersFromPayload(snapshot.statisticsPayload)
    snapshot.historyBucketCount = CountStatisticsHistoryBucketsFromPayload(snapshot.statisticsPayload)
    return snapshot
end

local function IsSafetyReason(reason)
    return reason == "pre-restore" or reason == "pre-full-restore"
end

local function IsManualReason(reason)
    return reason == "manual statistics" or reason == "manual full" or reason == "legacy"
end

local function AddUniqueId(list, id)
    if not id then return end
    for _, existing in ipairs(list or {}) do
        if existing == id then return end
    end
    table.insert(list, id)
end

local function MigrateOldDatabase(oldDb)
    local db = {
        backupVersion = BACKUP_VERSION,
        maxRecentSnapshots = MAX_RECENT_SNAPSHOTS,
        maxDailySnapshots = MAX_DAILY_SNAPSHOTS,
        maxManualSnapshots = MAX_MANUAL_SNAPSHOTS,
        maxSafetySnapshots = MAX_SAFETY_SNAPSHOTS,
        maxSnapshots = MAX_SNAPSHOTS,
        snapshotStore = {},
        recentIds = {},
        dailyIds = {},
        manualIds = {},
        safetyIds = {},
        nextSnapshotSerial = 0,
        lastBackupAt = tonumber(oldDb and oldDb.lastBackupAt) or tonumber(oldDb and oldDb.backupAt) or nil,
        lastBackupDate = oldDb and (oldDb.lastBackupDate or oldDb.backupDate) or nil,
    }

    local function classifyAndAdd(id, suggestedStorage)
        local snapshot = id and db.snapshotStore[id] or nil
        if not snapshot then return end
        local reason = tostring(snapshot.reason or "")
        if IsSafetyReason(reason) or suggestedStorage == "safety" then
            AddUniqueId(db.safetyIds, id)
        elseif IsManualReason(reason) or suggestedStorage == "manual" or snapshot.kind == "full" then
            AddUniqueId(db.manualIds, id)
        elseif suggestedStorage == "daily" then
            AddUniqueId(db.dailyIds, id)
        else
            AddUniqueId(db.recentIds, id)
        end
    end

    if type(oldDb) == "table" and type(oldDb.snapshotStore) == "table" then
        local idMap = {}
        for oldId, oldSnapshot in pairs(oldDb.snapshotStore) do
            local snapshot = NormalizeSnapshot(oldSnapshot)
            if snapshot then
                idMap[oldId] = AddSnapshotToStore(db, snapshot)
            end
        end
        for _, oldId in ipairs(oldDb.recentIds or {}) do classifyAndAdd(idMap[oldId], "recent") end
        for _, oldId in ipairs(oldDb.dailyIds or {}) do classifyAndAdd(idMap[oldId], "daily") end
        for _, oldId in ipairs(oldDb.fullIds or {}) do classifyAndAdd(idMap[oldId], "manual") end
        for _, oldId in ipairs(oldDb.manualIds or {}) do classifyAndAdd(idMap[oldId], "manual") end
        for _, oldId in ipairs(oldDb.safetyIds or {}) do classifyAndAdd(idMap[oldId], "safety") end
    elseif type(oldDb) == "table" and type(oldDb.snapshots) == "table" then
        local snapshots = {}
        for _, snapshot in ipairs(oldDb.snapshots) do
            snapshot = NormalizeSnapshot(snapshot)
            if snapshot then table.insert(snapshots, snapshot) end
        end
        table.sort(snapshots, function(a, b) return SnapshotTime(a) > SnapshotTime(b) end)
        for _, snapshot in ipairs(snapshots) do
            local id = AddSnapshotToStore(db, snapshot)
            classifyAndAdd(id, "recent")
        end
    elseif type(oldDb) == "table" and type(oldDb.database) == "table" then
        local snapshot = {
            kind = "statistics",
            backupAt = tonumber(oldDb.backupAt) or 0,
            backupDate = oldDb.backupDate or "Legacy backup",
            alternatorVersion = oldDb.alternatorVersion or "unknown",
            reason = "legacy",
            sourceCharacterName = "Unknown",
            sourceCharacterRealm = "Unknown",
            sourceCharacterClass = "UNKNOWN",
            statisticsPayload = ExtractStatisticsPayloadFromLegacyDatabase(oldDb.database),
        }
        NormalizeSnapshot(snapshot)
        local id = AddSnapshotToStore(db, snapshot)
        AddUniqueId(db.manualIds, id)
    end

    SortIdsNewestFirst(db, db.recentIds)
    SortIdsNewestFirst(db, db.dailyIds)
    SortIdsNewestFirst(db, db.manualIds)
    SortIdsNewestFirst(db, db.safetyIds)
    TrimRecent(db)
    TrimManual(db)
    TrimSafety(db)
    RebuildDailyArchive(db, type(time) == "function" and time() or 0)
    CleanupSnapshotStore(db)
    return db
end

local function EnsureBackupDatabase()
    if type(AlternatorBackupDB) ~= "table" then AlternatorBackupDB = {} end

    if tonumber(AlternatorBackupDB.backupVersion) ~= BACKUP_VERSION
        or type(AlternatorBackupDB.snapshotStore) ~= "table"
        or type(AlternatorBackupDB.recentIds) ~= "table"
        or type(AlternatorBackupDB.dailyIds) ~= "table"
        or type(AlternatorBackupDB.manualIds) ~= "table"
        or type(AlternatorBackupDB.safetyIds) ~= "table" then
        AlternatorBackupDB = MigrateOldDatabase(AlternatorBackupDB)
    end

    local db = AlternatorBackupDB
    db.backupVersion = BACKUP_VERSION
    db.maxRecentSnapshots = MAX_RECENT_SNAPSHOTS
    db.maxDailySnapshots = MAX_DAILY_SNAPSHOTS
    db.maxManualSnapshots = MAX_MANUAL_SNAPSHOTS
    db.maxSafetySnapshots = MAX_SAFETY_SNAPSHOTS
    db.maxSnapshots = MAX_SNAPSHOTS
    db.snapshotStore = type(db.snapshotStore) == "table" and db.snapshotStore or {}
    db.recentIds = type(db.recentIds) == "table" and db.recentIds or {}
    db.dailyIds = type(db.dailyIds) == "table" and db.dailyIds or {}
    db.manualIds = type(db.manualIds) == "table" and db.manualIds or {}
    db.safetyIds = type(db.safetyIds) == "table" and db.safetyIds or {}

    for _, snapshot in pairs(db.snapshotStore) do NormalizeSnapshot(snapshot) end
    SortIdsNewestFirst(db, db.recentIds)
    SortIdsNewestFirst(db, db.dailyIds)
    SortIdsNewestFirst(db, db.manualIds)
    SortIdsNewestFirst(db, db.safetyIds)
    TrimRecent(db)
    TrimManual(db)
    TrimSafety(db)
    RebuildDailyArchive(db, type(time) == "function" and time() or 0)
    CleanupSnapshotStore(db)
    return db
end

local function GetFilterCategory(snapshot, storage)
    local reason = tostring(snapshot and snapshot.reason or "")
    if reason == "legacy" then return "legacy" end
    if IsSafetyReason(reason) or storage == "Safety" then return "safety" end
    if storage == "Recent" then return "recent" end
    if storage == "Daily archive" then return "daily" end
    if snapshot and snapshot.kind == "full" then return "full" end
    return "manualStats"
end

local function BuildDisplayList(db)
    local list = {}
    for i, id in ipairs(db.recentIds or {}) do
        table.insert(list, { id = id, storage = "Recent", storageIndex = i, kind = "statistics" })
    end
    for i, id in ipairs(db.dailyIds or {}) do
        table.insert(list, { id = id, storage = "Daily archive", storageIndex = i, kind = "statistics" })
    end
    for i, id in ipairs(db.manualIds or {}) do
        local snapshot = db.snapshotStore[id]
        table.insert(list, { id = id, storage = "Manual", storageIndex = i, kind = snapshot and snapshot.kind or "statistics" })
    end
    for i, id in ipairs(db.safetyIds or {}) do
        local snapshot = db.snapshotStore[id]
        table.insert(list, { id = id, storage = "Safety", storageIndex = i, kind = snapshot and snapshot.kind or "statistics" })
    end
    return list
end

local function SaveStatisticsSnapshot(reason, sourceInfo, storage)
    if type(AlternatorDB) ~= "table" then return false end
    local db = EnsureBackupDatabase()
    local stamp = type(time) == "function" and time() or 0
    local source = BuildSourceInfo(sourceInfo)
    local payload = BuildStatisticsPayload(AlternatorDB)
    local snapshot = {
        kind = "statistics",
        backupAt = stamp,
        backupDate = type(date) == "function" and date("%Y-%m-%d %H:%M:%S", stamp) or "",
        alternatorVersion = AlternatorDB.lastAddonVersion or VERSION,
        reason = reason or "logout",
        sourceCharacterName = source.name,
        sourceCharacterRealm = source.realm,
        sourceCharacterClass = source.class,
        statisticsCharacterCount = CountStatisticsCharactersFromPayload(payload),
        historyBucketCount = CountStatisticsHistoryBucketsFromPayload(payload),
        statisticsPayload = payload,
    }

    local id = AddSnapshotToStore(db, snapshot)
    if storage == "manual" then
        table.insert(db.manualIds, 1, id)
        TrimManual(db)
        pendingSessionIds[id] = true
    elseif storage == "safety" then
        table.insert(db.safetyIds, 1, id)
        TrimSafety(db)
    else
        table.insert(db.recentIds, 1, id)
        TrimRecent(db)
        RebuildDailyArchive(db, stamp)
        db.lastBackupAt = stamp
        db.lastBackupDate = snapshot.backupDate
    end
    CleanupSnapshotStore(db)
    return true, id
end

function AlternatorBackup_SaveNow(reason, sourceInfo)
    if reason == "pre-restore" then
        return SaveStatisticsSnapshot(reason, sourceInfo, "safety")
    elseif reason == "manual statistics" then
        return SaveStatisticsSnapshot(reason, sourceInfo, "manual")
    elseif reason == "logout" or reason == "exit game" then
        return SaveStatisticsSnapshot(reason, sourceInfo, "recent")
    end
    return SaveStatisticsSnapshot(reason or "manual statistics", sourceInfo, "manual")
end

function AlternatorBackup_SaveFullNow(reason, sourceInfo)
    if type(AlternatorDB) ~= "table" then return false end
    local db = EnsureBackupDatabase()
    local stamp = type(time) == "function" and time() or 0
    local source = BuildSourceInfo(sourceInfo)
    local fullDatabase = DeepCopy(AlternatorDB)
    local snapshot = {
        kind = "full",
        backupAt = stamp,
        backupDate = type(date) == "function" and date("%Y-%m-%d %H:%M:%S", stamp) or "",
        alternatorVersion = AlternatorDB.lastAddonVersion or VERSION,
        reason = reason or "manual full",
        sourceCharacterName = source.name,
        sourceCharacterRealm = source.realm,
        sourceCharacterClass = source.class,
        dbCharacterCount = CountEntries(fullDatabase.characters),
        statisticsCharacterCount = CountStatisticsCharactersInDatabase(fullDatabase),
        historyBucketCount = CountStatisticsHistoryBucketsInDatabase(fullDatabase),
        fullDatabase = fullDatabase,
    }

    local id = AddSnapshotToStore(db, snapshot)
    if reason == "pre-full-restore" then
        table.insert(db.safetyIds, 1, id)
        TrimSafety(db)
    else
        table.insert(db.manualIds, 1, id)
        TrimManual(db)
        pendingSessionIds[id] = true
    end
    CleanupSnapshotStore(db)
    return true, id
end

function AlternatorBackup_GetSnapshotCount()
    local db = EnsureBackupDatabase()
    return #(BuildDisplayList(db))
end

function AlternatorBackup_GetRecentSnapshotCount()
    return #EnsureBackupDatabase().recentIds
end

function AlternatorBackup_GetDailySnapshotCount()
    return #EnsureBackupDatabase().dailyIds
end

function AlternatorBackup_GetManualSnapshotCount()
    return #EnsureBackupDatabase().manualIds
end

function AlternatorBackup_GetSafetySnapshotCount()
    return #EnsureBackupDatabase().safetyIds
end

function AlternatorBackup_GetFullSnapshotCount()
    local db = EnsureBackupDatabase()
    local count = 0
    for _, id in ipairs(db.manualIds or {}) do
        local snapshot = db.snapshotStore[id]
        if snapshot and snapshot.kind == "full" then count = count + 1 end
    end
    return count
end

function AlternatorBackup_GetSnapshotInfo(index)
    local db = EnsureBackupDatabase()
    local entry = BuildDisplayList(db)[tonumber(index) or 0]
    local snap = entry and db.snapshotStore[entry.id] or nil
    if type(snap) ~= "table" then return nil end
    return {
        id = entry.id,
        index = tonumber(index),
        kind = snap.kind or entry.kind or "statistics",
        backupAt = tonumber(snap.backupAt) or 0,
        backupDate = snap.backupDate or "Unknown",
        alternatorVersion = snap.alternatorVersion or "unknown",
        reason = snap.reason or "logout",
        storage = entry.storage,
        storageIndex = entry.storageIndex,
        filterCategory = GetFilterCategory(snap, entry.storage),
        pendingSave = pendingSessionIds[entry.id] and true or false,
        sourceCharacterName = snap.sourceCharacterName or "Unknown",
        sourceCharacterRealm = snap.sourceCharacterRealm or "Unknown",
        sourceCharacterClass = snap.sourceCharacterClass or "UNKNOWN",
        dbCharacterCount = tonumber(snap.dbCharacterCount) or (snap.kind == "full" and CountEntries(snap.fullDatabase and snap.fullDatabase.characters) or nil),
        statisticsCharacterCount = tonumber(snap.statisticsCharacterCount) or (snap.kind == "full" and CountStatisticsCharactersInDatabase(snap.fullDatabase) or CountStatisticsCharactersFromPayload(snap.statisticsPayload)),
        historyBucketCount = tonumber(snap.historyBucketCount) or (snap.kind == "full" and CountStatisticsHistoryBucketsInDatabase(snap.fullDatabase) or CountStatisticsHistoryBucketsFromPayload(snap.statisticsPayload)),
    }
end

local function ResolveSnapshotById(snapshotId)
    local db = EnsureBackupDatabase()
    local snap = snapshotId and db.snapshotStore[snapshotId] or nil
    if type(snap) ~= "table" then return nil, nil end
    return db, snap
end

local function MergeStatisticsPayloadIntoLiveDB(payload)
    if type(AlternatorDB) ~= "table" then AlternatorDB = {} end
    AlternatorDB.characters = type(AlternatorDB.characters) == "table" and AlternatorDB.characters or {}
    if type(payload) ~= "table" or type(payload.characters) ~= "table" then return false end

    for charKey, saved in pairs(payload.characters) do
        if type(saved) == "table" and type(saved.statistics) == "table" then
            local char = AlternatorDB.characters[charKey]
            if type(char) ~= "table" then
                char = {
                    name = saved.name,
                    realm = saved.realm,
                    class = saved.class,
                    guid = saved.guid,
                    level = saved.level,
                }
                AlternatorDB.characters[charKey] = char
            else
                if not char.name then char.name = saved.name end
                if not char.realm then char.realm = saved.realm end
                if not char.class then char.class = saved.class end
                if not char.guid then char.guid = saved.guid end
                if not char.level then char.level = saved.level end
            end
            char.statistics = DeepCopy(saved.statistics)
            char.statisticsScannedAt = saved.statisticsScannedAt or (saved.statistics and saved.statistics.scannedAt)
        end
    end
    return true
end

function AlternatorBackup_RestoreSnapshotById(snapshotId)
    local db, snap = ResolveSnapshotById(snapshotId)
    if not db or type(snap) ~= "table" or snap.kind == "full" or type(snap.statisticsPayload) ~= "table" then return false end

    SaveStatisticsSnapshot("pre-restore", BuildSourceInfo(), "safety")
    suppressNextLogoutBackup = true
    return MergeStatisticsPayloadIntoLiveDB(snap.statisticsPayload)
end

function AlternatorBackup_RestoreFullSnapshotById(snapshotId)
    local db, snap = ResolveSnapshotById(snapshotId)
    if not db or type(snap) ~= "table" or snap.kind ~= "full" or type(snap.fullDatabase) ~= "table" then return false end

    AlternatorBackup_SaveFullNow("pre-full-restore", BuildSourceInfo())
    suppressNextLogoutBackup = true
    AlternatorDB = DeepCopy(snap.fullDatabase)
    return true
end

-- Backwards-compatible index-based wrappers used by older UI code.
function AlternatorBackup_RestoreSnapshot(index)
    local info = AlternatorBackup_GetSnapshotInfo(index)
    return info and AlternatorBackup_RestoreSnapshotById(info.id) or false
end

function AlternatorBackup_RestoreFullSnapshot(index)
    local info = AlternatorBackup_GetSnapshotInfo(index)
    return info and AlternatorBackup_RestoreFullSnapshotById(info.id) or false
end

local function RemoveIdFromList(list, snapshotId)
    if type(list) ~= "table" then return end
    for i = #list, 1, -1 do
        if list[i] == snapshotId then table.remove(list, i) end
    end
end

function AlternatorBackup_DeleteSnapshotById(snapshotId)
    local db = EnsureBackupDatabase()
    if not snapshotId or type(db.snapshotStore[snapshotId]) ~= "table" then return false end
    RemoveIdFromList(db.recentIds, snapshotId)
    RemoveIdFromList(db.dailyIds, snapshotId)
    RemoveIdFromList(db.manualIds, snapshotId)
    RemoveIdFromList(db.safetyIds, snapshotId)
    db.snapshotStore[snapshotId] = nil
    pendingSessionIds[snapshotId] = nil
    CleanupSnapshotStore(db)
    return true
end

function AlternatorBackup_ShouldSkipNextLogout()
    if suppressNextLogoutBackup then
        suppressNextLogoutBackup = false
        return true
    end
    return false
end

function AlternatorBackup_GetMaxSnapshots()
    return MAX_SNAPSHOTS
end

function AlternatorBackup_GetRetentionPolicyText()
    return string.format("Keeps %d automatic Recent statistics snapshots, %d Daily archive snapshots, %d manual backups total (Statistics + Full), and %d restore-safety snapshots.", MAX_RECENT_SNAPSHOTS, MAX_DAILY_SNAPSHOTS, MAX_MANUAL_SNAPSHOTS, MAX_SAFETY_SNAPSHOTS)
end

-- SavedVariables are initialized only after this addon's ADDON_LOADED event.
local backupLifecycle = CreateFrame("Frame")
local pendingAutomaticReason = nil
local backupInitialized = false
backupLifecycle:RegisterEvent("ADDON_LOADED")
backupLifecycle:RegisterEvent("PLAYER_CAMPING")
backupLifecycle:RegisterEvent("PLAYER_QUITING")
backupLifecycle:RegisterEvent("PLAYER_LOGOUT")

-- Some 5.4.8/private-server clients do not reliably emit PLAYER_CAMPING / PLAYER_QUITING.
-- Secure post-hooks give us a second, harmless way to identify the user's action.
if type(hooksecurefunc) == "function" then
    if type(_G.Logout) == "function" then
        pcall(hooksecurefunc, "Logout", function() pendingAutomaticReason = "logout" end)
    end
    if type(_G.Quit) == "function" then
        pcall(hooksecurefunc, "Quit", function() pendingAutomaticReason = "exit game" end)
    end
end

backupLifecycle:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" then
        if arg1 == "AlternatorBackup" then
            EnsureBackupDatabase()
            backupInitialized = true
        end
        return
    end

    if event == "PLAYER_CAMPING" then
        pendingAutomaticReason = "logout"
        return
    elseif event == "PLAYER_QUITING" then
        pendingAutomaticReason = "exit game"
        return
    elseif event ~= "PLAYER_LOGOUT" then
        return
    end

    if not backupInitialized then
        EnsureBackupDatabase()
        backupInitialized = true
    end

    if AlternatorBackup_ShouldSkipNextLogout() then
        pendingAutomaticReason = nil
        return
    end

    if type(_G.Alternator) == "table" and type(_G.Alternator.PrepareLogoutBackup) == "function" then
        _G.Alternator:PrepareLogoutBackup()
    end

    local automaticReason = pendingAutomaticReason
    pendingAutomaticReason = nil

    -- /reload also fires PLAYER_LOGOUT, but it is intentionally not a backup
    -- trigger. Automatic statistics snapshots are created only for a real
    -- character Logout or Exit Game.
    if automaticReason ~= "logout" and automaticReason ~= "exit game" then
        return
    end

    local sourceInfo = nil
    if type(_G.Alternator) == "table" and type(_G.Alternator.GetBackupSourceInfo) == "function" then
        sourceInfo = _G.Alternator:GetBackupSourceInfo()
    end
    AlternatorBackup_SaveNow(automaticReason, sourceInfo)
end)

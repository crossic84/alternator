-- Alternator
-- Prototype for World of Warcraft: Mists of Pandaria 5.4.8 (Interface 50400)
-- Character overview + minimap launcher; achievement details integrate with Blizzard_AchievementUI.

local ADDON_NAME = ...
local AA = {}
_G.Alternator = AA

local VERSION = "0.3.91"
local DB_VERSION = 2
local COLLECTION_DETAIL_VERSION = 3
local SCAN_PER_FRAME = 60
local AUTO_SCAN_DELAY = 3
local PAGE_SIZE = 20
local ACCOUNT_WIDE_FLAG = 0x20000
local UNIQUE_ROW_HEIGHT = 24
local UNIQUE_VISIBLE_ROWS = 14
local MISSING_ROW_HEIGHT = 24
local MISSING_VISIBLE_ROWS = 14
local MISSING_FOS_SCAN_MAX_ID = 10000

-- Character lifetime statistics exposed by the original Achievement/Statistics API.
-- IDs are stable statistic achievement IDs on the 5.4.8 client.  Money values
-- are stored by Blizzard in copper.
local CHARACTER_STATISTIC_DEFS = {
    questTotal = { id = 98,  label = "Quests completed" },
    questDaily = { id = 97,  label = "Daily quests completed" },
    goldTotal  = { id = 328, label = "Total gold acquired", money = true },
    goldLooted = { id = 333, label = "Gold looted", money = true },
    goldQuest  = { id = 326, label = "Gold from quest rewards", money = true },
    goldAuction= { id = 919, label = "Gold earned from auctions", money = true },
    goldVendor = { id = 921, label = "Gold from vendors", money = true },
}

-- Some 5.4.8/private-server clients do not expose every statistic under the
-- same numeric ID even though the Statistics UI itself can display it.  Keep
-- the canonical IDs above as fast candidates, but also resolve the actual
-- statistic IDs from the client's Statistics catalogue by their display name.
local STATISTIC_ID_CACHE = nil

local STATISTICS_PERIOD_OPTIONS = {
    { value = "all",    text = "All time" },
    { value = "today",  text = "Today" },
    { value = "7d",     text = "Last 7 days" },
    { value = "30d",    text = "Last 30 days" },
    { value = "month",  text = "This month" },
    { value = "custom", text = "Custom range" },
}

local DASHBOARD_ROW_HEIGHT = 21
local DASHBOARD_MAX_ROWS = 30
local DASHBOARD_WIDTH = 1080
local DASHBOARD_HEIGHT = 620
local DASHBOARD_MIN_WIDTH = 1080
local DASHBOARD_MIN_HEIGHT = 640
local DASHBOARD_MAX_WIDTH = 1500
local DASHBOARD_MAX_HEIGHT = 900

local RECIPE_ROW_HEIGHT = 21
local RECIPE_VISIBLE_ROWS = 14
local RECIPE_WIDTH = 620
local RECIPE_HEIGHT = 400

-- Dedicated collection-diff tooltip. The stock GameTooltip is intentionally
-- not used for the full mount/pet diff because it cannot lay out a long list
-- cleanly across several columns.
local COLLECTION_TOOLTIP_FONT_SIZE = 10
local COLLECTION_TOOLTIP_TITLE_SIZE = 12
local COLLECTION_TOOLTIP_ROW_HEIGHT = 13
local COLLECTION_TOOLTIP_COLUMN_WIDTH = 160
local COLLECTION_TOOLTIP_ITEMS_PER_COLUMN = 10

-- MoP 5.4.8 skill-line IDs. Names are only used as a compact display label;
-- the actual skill values are read from GetProfessions()/GetProfessionInfo().
local PROFESSION_ABBREVIATIONS = {
    [171] = "Alch",
    [164] = "BS",
    [333] = "Ench",
    [202] = "Eng",
    [182] = "Herb",
    [773] = "Ins",
    [755] = "JWC",
    [165] = "LW",
    [186] = "Min",
    [393] = "Skin",
    [197] = "Tail",
    [794] = "Arch",
    [356] = "Fish",
    [185] = "Cook",
    [129] = "First Aid",
}

-- Full profession names are also kept by skill-line ID as a fallback for older
-- saved snapshots.  Normal scans store the localized name returned by
-- GetProfessionInfo(), but some older Alternator records can contain the skill
-- and skillLine without a usable name.
local PROFESSION_NAMES_BY_SKILLLINE = {
    [171] = "Alchemy",
    [164] = "Blacksmithing",
    [333] = "Enchanting",
    [202] = "Engineering",
    [182] = "Herbalism",
    [773] = "Inscription",
    [755] = "Jewelcrafting",
    [165] = "Leatherworking",
    [186] = "Mining",
    [393] = "Skinning",
    [197] = "Tailoring",
    [794] = "Archaeology",
    [356] = "Fishing",
    [185] = "Cooking",
    [129] = "First Aid",
}

-- Complete Wrathion legendary-cloak chain for original MoP 5.4.8.
-- The compact Summary table still references a handful of legacy keys
-- (valor/pvp/secrets/meta/runestones/cloak/legendaryCloak), while the
-- character detail view shows every chronological step below.
local LEGENDARY_MILESTONES = {
    -- Chapter I: Trial of the Black Prince
    { key = "stranger", chapter = 1, chapterTitle = "Chapter I - Trial of the Black Prince", title = "Stranger in a Strange Land", questAlternatives = { 31488, 31489 }, progressMode = "active" },
    { key = "legendMaking", chapter = 1, title = "A Legend in the Making", questID = 31454, progressMode = "active" },
    { key = "trial", chapter = 1, title = "Trial of the Black Prince", questID = 31468, progressMode = "active" },
    { key = "strength", chapter = 1, title = "The Strength of One's Foes", questID = 31473, progressMode = "multiObjective", objectiveIndices = { 1, 2 } },
    { key = "fear", chapter = 1, title = "Fear Itself", questID = 31481, progressMode = "objective", objectiveIndex = 1 },
    { key = "breath", chapter = 1, title = "Breath of the Black Prince", questID = 31482, progressMode = "active" },

    -- Chapter II: Wrathion's War
    { key = "incoming", chapter = 2, chapterTitle = "Chapter II - Wrathion's War", title = "Incoming...", questID = 31483, progressMode = "objective", objectiveIndex = 1 },
    { key = "measure", chapter = 2, title = "The Measure of a Leader", questIDs = { Alliance = 32373, Horde = 32427 }, progressMode = "active" },
    { key = "pursuit", chapter = 2, title = "The Prince's Pursuit", questIDs = { Alliance = 32374, Horde = 32429 }, progressMode = "active" },
    {
        key = "valor", chapter = 2, header = "Valor", title = "A Test of Valor",
        questIDs = { Alliance = 32474, Horde = 32476 },
        achievementIDs = { Alliance = 8030, Horde = 8031 },
        progressMode = "valorAchievement", objectiveIndex = 1,
    },
    { key = "changeCommand", chapter = 2, title = "A Change of Command", questIDs = { Alliance = 32388, Horde = 32430 }, progressMode = "objective", objectiveIndex = 1 },
    {
        key = "pvp", chapter = 2, header = "PvP", title = "The Lion Roars / Glory to the Horde",
        titles = { Alliance = "The Lion Roars", Horde = "Glory to the Horde" },
        questIDs = { Alliance = 32389, Horde = 32431 }, progressMode = "binary",
    },
    {
        key = "chapter2Final", chapter = 2, title = "Call of the Packmaster / The Soul of the Horde",
        titles = { Alliance = "Call of the Packmaster", Horde = "The Soul of the Horde" },
        questIDs = { Alliance = 32390, Horde = 32432 }, progressMode = "active",
    },

    -- Chapter III: Two Princes
    { key = "thunderKing", chapter = 3, chapterTitle = "Chapter III - Two Princes", title = "The Thunder King", questID = 32457, progressMode = "active", optional = true },
    { key = "meetUpstairs", chapter = 3, title = "Meet Me Upstairs", questID = 32590, progressMode = "active" },
    {
        key = "secrets", chapter = 3, header = "Secrets", title = "Secrets of the First Empire",
        questID = 32591, progressMode = "multiObjective", objectiveIndices = { 1, 2 },
    },
    { key = "champion", chapter = 3, title = "I Need a Champion", questID = 32592, progressMode = "active" },
    { key = "thunderForge", chapter = 3, title = "The Thunder Forge", questID = 32593, progressMode = "active" },
    { key = "stormLord", chapter = 3, title = "Spirit of the Storm Lord", questID = 32594, progressMode = "active" },
    { key = "meta", chapter = 3, header = "Meta", title = "The Crown of Heaven", questID = 32595, progressMode = "active" },
    { key = "runestones", chapter = 3, header = "Runestones", title = "Echoes of the Titans", questID = 32596, progressMode = "objective", objectiveIndex = 1 },
    { key = "thunderHeart", chapter = 3, title = "Heart of the Thunder King", questID = 32597, progressMode = "objective", objectiveIndex = 1 },

    -- Chapter IV: Celestial Blessings
    { key = "reckoning", chapter = 4, chapterTitle = "Chapter IV - Celestial Blessings", title = "A Reckoning", questID = 32598, progressMode = "active", optional = true },
    { key = "celestial", chapter = 4, title = "Celestial Blessings", questID = 32805, progressMode = "binary" },
    { key = "cloak", chapter = 4, header = "Cloak", title = "Cloak of Virtue", questID = 32861, progressMode = "active" },
    {
        key = "chapter4Transition", chapter = 4, title = "Preparing to Strike / Meet Me Back at the Inn",
        questAlternatives = { 32870, 33087 }, progressMode = "active", inferCompleteFromLater = true,
    },

    -- Chapter V: Judgment of the Black Prince
    { key = "timelessDiscovery", chapter = 5, chapterTitle = "Chapter V - Judgment of the Black Prince", title = "A Timeless Discovery", questID = 33088, progressMode = "active" },
    { key = "timelessSecrets", chapter = 5, title = "Secrets of the Timeless Isle", questID = 33098, progressMode = "objective", objectiveIndex = 1 },
    { key = "emperorWay", chapter = 5, title = "The Emperor's Way", questID = 33100, progressMode = "binary" },
    { key = "legendaryCloak", chapter = 5, header = "Leg. Cloak", title = "A Pandaren Legend", questID = 33104, progressMode = "active" },
    { key = "judgment", chapter = 5, title = "Judgment of the Black Prince", questID = 33105, progressMode = "objective", objectiveIndex = 1 },
}

local LEGENDARY_QUEST_DESCRIPTIONS = {
    stranger = "Meet Wrathion in the Tavern in the Mists and begin the Black Prince legendary quest line.",
    legendMaking = "Speak with Wrathion and learn what he expects from the champions of Pandaria.",
    trial = "Prove yourself to the Black Prince by building reputation through combat across Pandaria.",
    strength = "Collect 10 Sigils of Power and 10 Sigils of Wisdom from raid bosses in Mogu'shan Vaults, Heart of Fear and Terrace of Endless Spring.",
    fear = "Defeat the Sha of Fear in the Terrace of Endless Spring and recover the item Wrathion requires.",
    breath = "Return to Wrathion after the first trials and complete the opening chapter of the legendary journey.",

    incoming = "Meet Wrathion again as the Alliance-Horde conflict reaches Krasarang Wilds and the next chapter begins.",
    measure = "Follow Wrathion's investigation of your faction's leadership and the escalating war in Pandaria.",
    pursuit = "Continue Wrathion's campaign tasks and advance your standing with the Black Prince.",
    valor = "Earn the required Valor Points to demonstrate sustained effort during Wrathion's second chapter.",
    changeCommand = "Defeat the opposing faction commander in Krasarang Wilds as part of Wrathion's test of strength.",
    pvp = "Win the required Pandaria battlegrounds for your faction to prove yourself in the Alliance-Horde conflict.",
    chapter2Final = "Complete the faction-specific finale of Wrathion's war chapter and report back to the Black Prince.",

    thunderKing = "Follow the breadcrumb leading into Wrathion's Thunder King chapter on the Isle of Thunder.",
    meetUpstairs = "Meet Wrathion upstairs in the Tavern in the Mists to begin his plan concerning the Thunder King.",
    secrets = "Collect Secrets of the Empire from Throne of Thunder bosses and gather the additional materials Wrathion requests.",
    champion = "Prove that you are Wrathion's champion by completing the reputation requirement for the Black Prince.",
    thunderForge = "Enter the Thunder Forge scenario and help Wrathion create the weapon needed for the next stage of his plan.",
    stormLord = "Use the forged weapon against Nalak and capture the power of the Storm Lord for Wrathion.",
    meta = "Complete this stage of Wrathion's work and receive the legendary meta-gem reward associated with the Crown of Heaven.",
    runestones = "Collect Titan Runestones from eligible Throne of Thunder bosses for Wrathion's continuing investigation.",
    thunderHeart = "Defeat Lei Shen and recover the Heart of the Thunder King for Wrathion.",

    reckoning = "Return to Wrathion after the fall of the Thunder King and hear his conclusions about the events on the Isle of Thunder.",
    celestial = "Complete one of Wrathion's celestial challenges, tailored to the role you choose to prove.",
    cloak = "Return to Wrathion after the celestial challenge and receive the epic cloak that precedes the legendary version.",
    chapter4Transition = "Meet Wrathion again and prepare for the final stage of the legendary quest line leading to the Timeless Isle.",

    timelessDiscovery = "Travel to the Timeless Isle with Wrathion's guidance and begin the final chapter of the legendary journey.",
    timelessSecrets = "Gather the Timeless Isle currency and knowledge Wrathion needs for the final empowerment of your cloak.",
    emperorWay = "Defeat the August Celestials on the Timeless Isle as the final major combat trial before the legendary cloak.",
    legendaryCloak = "Return to Wrathion and transform your epic cloak into its legendary form, completing the main reward of the quest line.",
    judgment = "Complete Wrathion's final judgment after the events of Siege of Orgrimmar and close the Black Prince legendary story.",
}

local QUEST_STATE_COLORS = {
    done = { 0.18, 0.55, 0.18, 0.78 },
    active = { 0.90, 0.55, 0.08, 0.78 },
    none = { 0.62, 0.18, 0.18, 0.68 },
    skipped = { 0.22, 0.28, 0.34, 0.72 },
}

local PROF_STATE_COLORS = {
    max = { 0.20, 0.55, 0.15, 0.72 },
    partial = { 0.85, 0.58, 0.12, 0.72 },
    low = { 0.72, 0.25, 0.25, 0.58 },
    none = { 0.18, 0.18, 0.18, 0.55 },
}

local CHARACTER_SORT_OPTIONS = {
    { value = "name_asc",       text = "Name (A-Z)" },
    { value = "name_desc",      text = "Name (Z-A)" },
    { value = "class_asc",      text = "Class (A-Z)" },
    { value = "last_seen_desc", text = "Last online (newest first)" },
    { value = "last_seen_asc",  text = "Last online (oldest first)" },
}

local DASHBOARD_VIEW_OPTIONS = {
    { value = "professions", text = "Professions" },
    { value = "legendary",   text = "Legendary Cloak" },
    { value = "collections", text = "Mounts & Companions" },
}

local MAIN_SECTION_OPTIONS = {
    { value = "summary", text = "Summary" },
    { value = "characters", text = "Characters" },
}

-- Character-only detail tabs. These are hidden entirely while Summary is active.
local MAIN_TAB_OPTIONS = {
    { value = "overview", text = "Overview" },
    { value = "gear", text = "Gear" },
    { value = "reputations", text = "Reputations" },
    { value = "professions", text = "Professions" },
    { value = "legendary", text = "Legendary Cloak" },
    { value = "collections", text = "Mounts & Companions" },
}

-- Character currencies that are useful on a MoP 5.4.8 alt overview.
-- The legacy GetCurrencyInfo API accepts CurrencyID directly.
local TRACKED_CURRENCIES = {
    { id = 396, name = "Valor Points", short = "VP", default = true, totalCap = 3000, alertCap = 3000 },
    { id = 395, name = "Justice Points", short = "JP", default = false },
    { id = 392, name = "Honor Points", short = "Honor", default = false },
    { id = 390, name = "Conquest Points", short = "Conq", default = false },
    { id = 738, name = "Lesser Charm of Good Fortune", short = "Lesser", default = true },
    { id = 697, name = "Elder Charm of Good Fortune", short = "Elder", default = true },
    { id = 752, name = "Mogu Rune of Fate", short = "Mogu", default = true },
    { id = 776, name = "Warforged Seal", short = "Seal", default = true },
    { id = 777, name = "Timeless Coin", short = "Timeless", default = true },
    { id = 402, name = "Ironpaw Token", short = "Ironpaw", default = false },
    { id = 515, name = "Darkmoon Prize Ticket", short = "DMF", default = false },
    { id = 789, name = "Bloody Coin", short = "Bloody", default = false },
}

local CHARACTER_CARD_HEIGHT = 82
local CHARACTER_CARD_MAX_ROWS = 12

-- Professions whose TradeSkill recipe list can be captured by the 5.4.8 client.
-- Gathering professions are intentionally excluded from the recipe-scan guide.
local RECIPE_PROFESSION_SKILL_LINES = {
    [171] = true, [164] = true, [333] = true, [202] = true,
    [773] = true, [755] = true, [165] = true, [197] = true,
    [185] = true, [129] = true,
}

local RECIPE_PROFESSION_NAMES = {
    ["alchemy"] = true, ["blacksmithing"] = true, ["enchanting"] = true,
    ["engineering"] = true, ["inscription"] = true, ["jewelcrafting"] = true,
    ["leatherworking"] = true, ["tailoring"] = true, ["cooking"] = true,
    ["first aid"] = true,
}

-- Equipped gear slots tracked for offline character inspection.
local GEAR_SLOTS = {
    { id=1,  key="head",      label="Head" },
    { id=2,  key="neck",      label="Neck" },
    { id=3,  key="shoulder",  label="Shoulder" },
    { id=15, key="back",      label="Back" },
    { id=5,  key="chest",     label="Chest" },
    { id=9,  key="wrist",     label="Wrist" },
    { id=10, key="hands",     label="Hands" },
    { id=6,  key="waist",     label="Waist" },
    { id=7,  key="legs",      label="Legs" },
    { id=8,  key="feet",      label="Feet" },
    { id=11, key="finger1",   label="Finger 1" },
    { id=12, key="finger2",   label="Finger 2" },
    { id=13, key="trinket1",  label="Trinket 1" },
    { id=14, key="trinket2",  label="Trinket 2" },
    { id=16, key="mainhand",  label="Main Hand" },
    { id=17, key="offhand",   label="Off Hand" },
}

local REPUTATION_STANDING_NAMES = {
    [1]="Hated", [2]="Hostile", [3]="Unfriendly", [4]="Neutral",
    [5]="Friendly", [6]="Honored", [7]="Revered", [8]="Exalted",
}

-- Known MoP cooldown crafts. The generic API detector below also records any
-- other recipe for which GetTradeSkillCooldown() reports a cooldown.
local KNOWN_PROFESSION_COOLDOWN_RECIPES = {
    ["transmute: living steel"] = true,
    ["scroll of wisdom"] = true,
    ["serpent's heart"] = true,
    ["lightning steel ingot"] = true,
    ["balanced trillium ingot"] = true,
    ["magnificence of leather"] = true,
    ["magnificence of scales"] = true,
    ["hardened magnificent hide"] = true,
    ["imperial silk"] = true,
    ["celestial cloth"] = true,
    ["jard's peculiar energy source"] = true,
}


local COLOR_PREFIX = "|cffa656f0Alternator|r"
local GREEN = { 0.20, 1.00, 0.20 }
local RED = { 1.00, 0.25, 0.25 }
local GOLD = { 1.00, 0.82, 0.00 }
local GREY = { 0.65, 0.65, 0.65 }
local WHITE = { 1.00, 1.00, 1.00 }

local eventFrame = CreateFrame("Frame")
AA.eventFrame = eventFrame
AA.scan = nil
AA.autoScanAt = nil
AA.indexDirty = true
AA.ownershipIndex = nil
AA.uniqueCounts = nil
AA.uniqueLists = nil
AA.oldestCounts = nil
AA.oldestLists = nil
AA.oldestPendingCounts = nil
AA.oldestIndex = nil
AA.oldestSharedKnownCount = 0
AA.oldestSharedUnknownCount = 0
AA.achievementUIHooked = false
AA.headerHitbox = nil
AA.tooltipMarker = nil
AA.pendingTooltipOwner = nil
AA.pendingTooltipID = nil
AA.pendingTooltipAt = nil
AA.hookedAchievementButtons = 0
AA.uniqueTab = nil
AA.uniqueFrame = nil
AA.uniqueTabCreateAt = nil
AA.uniqueCollapsed = {}
AA.uniqueDisplayRows = {}
AA.missingTab = nil
AA.missingFrame = nil
AA.missingTabIndex = nil
AA.missingCollapsed = {}
AA.missingDisplayRows = {}
AA.missingCatalogue = nil
AA.missingCatalogueReady = false
AA.optionsPanel = nil
AA.optionsEnableCheck = nil
AA.optionsSortDropDown = nil
AA.uniqueSortDropDown = nil
AA.optionsRealmDropDown = nil
AA.uniqueRealmDropDown = nil
AA.missingRealmDropDown = nil
AA.lastSeenUpdateAt = nil
AA.profileScanAt = nil
AA.statisticsScanAt = nil
AA.moneyScanAt = nil
AA.moneyScanRetryCount = 0
AA.moneySnapshotReady = false
AA.dashboardFrame = nil
AA.dashboardRows = {}
AA.dashboardRealmDropDown = nil
AA.dashboardSortDropDown = nil
AA.minimapButton = nil
AA.optionsMinimapCheck = nil
AA.collectionTooltip = nil
AA.dashboardViewDropDown = nil
AA.recipeScanAt = nil
AA.recipeScanRetryCount = 0
AA.recipeScanRetryProfession = nil
AA.recipeScanInSecurePreClick = false
AA.recipeFrame = nil
AA.recipeResults = {}
AA.recipeContext = nil
AA.recipeGuideFrame = nil
AA.playedRequestAt = nil
AA.playedRequestCharacterKey = nil

local REMOVE_POPUP = "ALTERNATOR_REMOVE_CHARACTER"

StaticPopupDialogs[REMOVE_POPUP] = {
    text = "Remove %s from Alternator?\n\nAll stored Alternator data for this character (achievements, professions and legendary-quest progress) will be deleted. This does not affect the character or server data.",
    button1 = YES,
    button2 = NO,
    OnAccept = function(self, data)
        local charKey = data or self.data
        if charKey and Alternator then
            Alternator:RemoveCharacterByKey(charKey)
        end
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

local function Print(message)
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage(COLOR_PREFIX .. ": " .. tostring(message))
    end
end

local function Trim(text)
    if not text then
        return ""
    end
    return (string.gsub(text, "^%s*(.-)%s*$", "%1"))
end

local function Lower(text)
    return string.lower(text or "")
end

local function SafeRealmName()
    local realm = GetRealmName and GetRealmName() or "UnknownRealm"
    if not realm or realm == "" then
        realm = "UnknownRealm"
    end
    return realm
end

local function CurrentCharacterKey()
    local name = UnitName("player") or "Unknown"
    return name .. "-" .. SafeRealmName()
end

local function FormatTimestamp(timestamp)
    if not timestamp or timestamp <= 0 then
        return "never"
    end
    if date then
        return date("%Y-%m-%d %H:%M", timestamp)
    end
    return tostring(timestamp)
end

local function FormatPlayedTime(seconds)
    seconds = math.max(0, math.floor(tonumber(seconds) or 0))
    local days = math.floor(seconds / 86400)
    local hours = math.floor((seconds % 86400) / 3600)
    local minutes = math.floor((seconds % 3600) / 60)

    if days > 0 then
        return string.format("%dd %dh %dm", days, hours, minutes)
    elseif hours > 0 then
        return string.format("%dh %dm", hours, minutes)
    else
        return string.format("%dm", minutes)
    end
end

local function ParseStatisticNumber(value, isMoney)
    if value == nil then return nil end
    if type(value) == "number" then
        if isMoney and value < 0 then value = value + 4294967296 end
        return value
    end

    local text = tostring(value)
    if text == "" or text == "--" then return nil end

    -- Wealth statistics on older clients can be returned as a fully formatted
    -- money string containing the standard gold/silver/copper texture tags,
    -- rather than as one plain copper integer. Parse those components first.
    if isMoney then
        local function MoneyComponent(iconName)
            local pattern = "([%d%.,%s%-]+)|T[^|]-" .. iconName .. "[^|]*|t"
            local part = string.match(text, pattern)
            if not part then return nil end
            local sign = string.find(part, "%-", 1, true) and -1 or 1
            local digits = string.gsub(part, "[^%d]", "")
            if digits == "" then return nil end
            return sign * (tonumber(digits) or 0)
        end

        local gold = MoneyComponent("GoldIcon")
        local silver = MoneyComponent("SilverIcon")
        local copper = MoneyComponent("CopperIcon")
        if gold ~= nil or silver ~= nil or copper ~= nil then
            gold = gold or 0
            silver = silver or 0
            copper = copper or 0
            local negative = gold < 0 or silver < 0 or copper < 0
            local amount = (math.abs(gold) * 10000) + (math.abs(silver) * 100) + math.abs(copper)
            if negative then amount = -amount end
            if amount < 0 then amount = amount + 4294967296 end
            return amount
        end
    end

    -- Plain statistic strings may contain localized thousands separators.
    local cleaned = string.gsub(text, "[^%d%-]", "")
    if cleaned == "" or cleaned == "-" then return nil end
    local number = tonumber(cleaned)
    if number and isMoney and number < 0 then
        -- Old clients store several wealth statistics in signed 32-bit counters.
        number = number + 4294967296
    end
    return number
end

local function NormalizeStatisticLabel(value)
    local text = string.lower(tostring(value or ""))
    text = string.gsub(text, "[%s%p]+", "")
    return text
end

local function BuildStatisticIdCache()
    if STATISTIC_ID_CACHE then return STATISTIC_ID_CACHE end
    local cache = {}
    if type(GetStatisticsCategoryList) == "function" and type(GetCategoryNumAchievements) == "function" and type(GetAchievementInfo) == "function" then
        local ok, categories = pcall(GetStatisticsCategoryList)
        if ok and type(categories) == "table" then
            for _, categoryID in pairs(categories) do
                local count = 0
                local countOK, countValue = pcall(GetCategoryNumAchievements, categoryID, true)
                if countOK then count = tonumber(countValue) or 0 end
                if count <= 0 then
                    countOK, countValue = pcall(GetCategoryNumAchievements, categoryID)
                    if countOK then count = tonumber(countValue) or 0 end
                end
                for index = 1, count do
                    local infoOK, id, name = pcall(GetAchievementInfo, categoryID, index)
                    if infoOK and id and name and name ~= "" then
                        cache[NormalizeStatisticLabel(name)] = tonumber(id) or id
                    end
                end
            end
        end
    end
    STATISTIC_ID_CACHE = cache
    return cache
end

local function GetStatisticCandidateIDs(def)
    local result, seen = {}, {}
    local cache = BuildStatisticIdCache()
    local resolved = cache and cache[NormalizeStatisticLabel(def.label)]
    if resolved ~= nil then
        table.insert(result, resolved)
        seen[tostring(resolved)] = true
    end
    if def.id ~= nil and not seen[tostring(def.id)] then
        table.insert(result, def.id)
    end
    return result
end

local function StatisticsDayKey(timestamp)
    timestamp = tonumber(timestamp) or time()
    return date and date("%Y%m%d", timestamp) or tostring(math.floor(timestamp / 86400))
end

local function StartOfLocalDay(timestamp)
    timestamp = tonumber(timestamp) or time()
    if not date or not time then return timestamp - (timestamp % 86400) end
    local t = date("*t", timestamp)
    if type(t) ~= "table" then return timestamp - (timestamp % 86400) end
    return time({ year=t.year, month=t.month, day=t.day, hour=0, min=0, sec=0 })
end

local function StartOfLocalMonth(timestamp)
    timestamp = tonumber(timestamp) or time()
    if not date or not time then return timestamp - (30 * 86400) end
    local t = date("*t", timestamp)
    if type(t) ~= "table" then return timestamp - (30 * 86400) end
    return time({ year=t.year, month=t.month, day=1, hour=0, min=0, sec=0 })
end

local function CounterDelta(previous, current)
    previous = tonumber(previous)
    current = tonumber(current)
    if previous == nil or current == nil then return 0 end
    if current >= previous then return current - previous end
    -- If an external server correction/reset makes a statistic go backwards,
    -- do not invent negative activity.  The new value becomes the next baseline.
    return 0
end

local function FormatStatisticsDate(timestamp)
    timestamp = tonumber(timestamp) or time()
    if date then
        return date("%Y-%m-%d", timestamp)
    end
    return tostring(timestamp)
end

local function ParseStatisticsDate(text)
    if type(text) ~= "string" then return nil end
    local year, month, day = string.match(text, "^%s*(%d%d%d%d)%-(%d%d)%-(%d%d)%s*$")
    year, month, day = tonumber(year), tonumber(month), tonumber(day)
    if not year or not month or not day or month < 1 or month > 12 or day < 1 or day > 31 then
        return nil
    end
    if not time or not date then return nil end
    local stamp = time({ year=year, month=month, day=day, hour=0, min=0, sec=0 })
    if not stamp then return nil end
    local verify = date("*t", stamp)
    if type(verify) ~= "table" or verify.year ~= year or verify.month ~= month or verify.day ~= day then
        return nil
    end
    return stamp
end

local function DefaultStatisticsCustomRange()
    local today = StartOfLocalDay(time())
    return FormatStatisticsDate(today - (13 * 86400)), FormatStatisticsDate(today)
end

local function StatisticPeriodLabel(value)
    for _, option in ipairs(STATISTICS_PERIOD_OPTIONS) do
        if option.value == value then
            return option.text
        end
    end
    return "All time"
end

-- Achievement completion dates in the 5.4.8 API are day-precision values.
-- Store them as YYYYMMDD numbers so they compare cheaply and survive SavedVariables.
local function PackAchievementDate(month, day, year)
    month = tonumber(month)
    day = tonumber(day)
    year = tonumber(year)
    if not month or not day or not year or month <= 0 or day <= 0 then
        return nil
    end
    if year < 100 then
        year = 2000 + year
    end
    if year < 2000 or month > 12 or day > 31 then
        return nil
    end
    return (year * 10000) + (month * 100) + day
end

local function FormatAchievementDate(dateKey)
    dateKey = tonumber(dateKey)
    if not dateKey or dateKey <= 0 then
        return "unknown"
    end
    local year = math.floor(dateKey / 10000)
    local month = math.floor((dateKey % 10000) / 100)
    local day = dateKey % 100
    return string.format("%d/%02d/%02d", month, day, year % 100)
end

local function IsAccountWide(flags)
    if not flags or not bit or not bit.band then
        return false
    end
    return bit.band(flags, ACCOUNT_WIDE_FLAG) ~= 0
end

local function AchievementName(achievementID)
    if not achievementID then
        return "Unknown achievement"
    end
    local id, name = GetAchievementInfo(achievementID)
    if id and name then
        return name
    end
    return "Achievement #" .. tostring(achievementID)
end

local function AchievementLinkOrName(achievementID)
    local link = GetAchievementLink and GetAchievementLink(achievementID)
    if link then
        return link
    end
    return "[" .. AchievementName(achievementID) .. "] (#" .. tostring(achievementID) .. ")"
end

function AA:InitializeDatabase()
    if type(AlternatorDB) ~= "table" then
        AlternatorDB = {}
    end

    local db = AlternatorDB
    db.version = DB_VERSION
    db.characters = type(db.characters) == "table" and db.characters or {}
    db.settings = type(db.settings) == "table" and db.settings or {}
    if db.settings.enabled == nil then
        db.settings.enabled = true
    end
    if db.settings.characterSort == nil then
        db.settings.characterSort = "name_asc"
    end
    if db.settings.realmFilterAll == nil then
        db.settings.realmFilterAll = true
    end
    db.settings.selectedRealms = type(db.settings.selectedRealms) == "table" and db.settings.selectedRealms or {}
    if db.settings.uniqueViewMode ~= "oldest" then
        db.settings.uniqueViewMode = "unique"
    end
    local validDashboardView = false
    for _, option in ipairs(DASHBOARD_VIEW_OPTIONS) do
        if db.settings.dashboardView == option.value then
            validDashboardView = true
            break
        end
    end
    if not validDashboardView then
        db.settings.dashboardView = "professions"
    end
    -- 0.3.40 splits navigation into a main section (Summary / Characters)
    -- plus character-detail tabs. Migrate the old single-level Summary tab.
    if db.settings.dashboardSection ~= "summary" and db.settings.dashboardSection ~= "characters" then
        db.settings.dashboardSection = (db.settings.dashboardTab == "summary") and "summary" or "characters"
    end
    local validMainTab = false
    for _, option in ipairs(MAIN_TAB_OPTIONS) do
        if db.settings.dashboardTab == option.value then
            validMainTab = true
            break
        end
    end
    if not validMainTab then
        db.settings.dashboardTab = "overview"
    end
    db.currencyTextures = type(db.currencyTextures) == "table" and db.currencyTextures or {}
    db.moneySnapshots = type(db.moneySnapshots) == "table" and db.moneySnapshots or {}
    db.moneySnapshotsByGUID = type(db.moneySnapshotsByGUID) == "table" and db.moneySnapshotsByGUID or {}

    -- Keep gold in a dedicated account-level snapshot table as well as on the
    -- character record. Older versions stored only char.money. Backfill either
    -- direction so a later profile refresh cannot accidentally lose the value.
    for charKey, char in pairs(db.characters) do
        if type(char) == "table" then
            local snap = db.moneySnapshots[charKey]
            if type(snap) ~= "table" and char.guid and type(db.moneySnapshotsByGUID[char.guid]) == "table" then
                snap = db.moneySnapshotsByGUID[char.guid]
                db.moneySnapshots[charKey] = snap
            end
            if type(snap) == "table" and snap.amount ~= nil then
                local snapAt = tonumber(snap.scannedAt) or 0
                local charAt = tonumber(char.moneyScannedAt) or 0
                if char.money == nil or snapAt >= charAt then
                    char.money = tonumber(snap.amount) or 0
                    char.moneyScannedAt = snapAt > 0 and snapAt or char.moneyScannedAt
                end
            elseif char.money ~= nil and ((tonumber(char.money) or 0) > 0 or char.moneyScannedAt) then
                snap = { amount = tonumber(char.money) or 0, scannedAt = tonumber(char.moneyScannedAt) or 0, guid = char.guid }
                db.moneySnapshots[charKey] = snap
                if char.guid and char.guid ~= "" then db.moneySnapshotsByGUID[char.guid] = snap end
            end
        end
    end
    db.settings.shownCurrencies = type(db.settings.shownCurrencies) == "table" and db.settings.shownCurrencies or {}
    if db.settings.currencyDefaultsInitialized ~= true then
        for _, currency in ipairs(TRACKED_CURRENCIES) do
            if db.settings.shownCurrencies[tostring(currency.id)] == nil then
                db.settings.shownCurrencies[tostring(currency.id)] = currency.default and true or false
            end
        end
        db.settings.currencyDefaultsInitialized = true
    end
    db.settings.minimap = type(db.settings.minimap) == "table" and db.settings.minimap or {}
    if db.settings.minimap.hide == nil then
        db.settings.minimap.hide = false
    end
    db.settings.minimap.x = tonumber(db.settings.minimap.x) or -74
    db.settings.minimap.y = tonumber(db.settings.minimap.y) or -74
    if db.settings.includeRepeatableQuests == nil then
        db.settings.includeRepeatableQuests = true
    end
    local validStatisticsPeriod = false
    for _, option in ipairs(STATISTICS_PERIOD_OPTIONS) do
        if db.settings.statisticsPeriod == option.value then
            validStatisticsPeriod = true
            break
        end
    end
    if not validStatisticsPeriod then db.settings.statisticsPeriod = "all" end
    local defaultCustomFrom, defaultCustomTo = DefaultStatisticsCustomRange()
    if not ParseStatisticsDate(db.settings.statisticsCustomFrom or "") then
        db.settings.statisticsCustomFrom = defaultCustomFrom
    end
    if not ParseStatisticsDate(db.settings.statisticsCustomTo or "") then
        db.settings.statisticsCustomTo = defaultCustomTo
    end
    if ParseStatisticsDate(db.settings.statisticsCustomFrom) > ParseStatisticsDate(db.settings.statisticsCustomTo) then
        db.settings.statisticsCustomFrom, db.settings.statisticsCustomTo = db.settings.statisticsCustomTo, db.settings.statisticsCustomFrom
    end
    db.settings.statisticsCustomDays = math.max(1, math.min(3650, tonumber(db.settings.statisticsCustomDays) or 14))
    db.settings.dashboardSize = type(db.settings.dashboardSize) == "table" and db.settings.dashboardSize or {}
    db.settings.dashboardSize.width = math.max(DASHBOARD_MIN_WIDTH, math.min(DASHBOARD_MAX_WIDTH, tonumber(db.settings.dashboardSize.width) or DASHBOARD_WIDTH))
    db.settings.dashboardSize.height = math.max(DASHBOARD_MIN_HEIGHT, math.min(DASHBOARD_MAX_HEIGHT, tonumber(db.settings.dashboardSize.height) or DASHBOARD_HEIGHT))
    db.createdAt = db.createdAt or time()
    db.lastAddonVersion = VERSION

    self.db = db
end

function AA:IsEnabled()
    if not self.db or not self.db.settings then
        return true
    end
    return self.db.settings.enabled ~= false
end

function AA:SetEnabled(enabled, quiet)
    if not self.db then
        self:InitializeDatabase()
    end

    enabled = enabled and true or false
    self.db.settings = type(self.db.settings) == "table" and self.db.settings or {}
    self.db.settings.enabled = enabled

    if self.optionsEnableCheck then
        self.optionsEnableCheck:SetChecked(enabled)
    end

    if enabled then
        if self.uniqueTab then
            self.uniqueTab:Show()
        end
        if self.missingTab then
            self.missingTab:Show()
        end
        if self.headerHitbox then
            self.headerHitbox:EnableMouse(true)
        end
        if IsAddOnLoaded("Blizzard_AchievementUI") then
            self:HookAchievementUI()
            self:CreateUniqueTab()
            if self.uniqueTab then
                self.uniqueTab:Show()
            end
            if self.missingTab then
                self.missingTab:Show()
            end
        end
        self.autoScanAt = GetTime() + 0.5
        self:ScheduleProfileScan(0.5)
        self:TouchCurrentCharacterLastSeen()
        self.lastSeenUpdateAt = GetTime() + 60
        self:CreateMinimapButton()
        self:SetMinimapButtonShown(self:IsMinimapButtonShown())
        if not quiet then
            Print("Enabled. Achievement scanning, character overview, tooltips and the Unique/Missing tabs are active.")
        end
    else
        self.autoScanAt = nil
        self.profileScanAt = nil
        self.statisticsScanAt = nil
        self.recipeScanAt = nil
        self.recipeScanRetryCount = 0
        self.recipeScanRetryProfession = nil
        self.recipeScanInSecurePreClick = false
        self.lastSeenUpdateAt = nil
        self.scan = nil
        self.pendingTooltipOwner = nil
        self.pendingTooltipID = nil
        self.pendingTooltipAt = nil

        if GameTooltip and GameTooltip.__AlternatorID then
            GameTooltip:Hide()
        end

        local customAchievementPanelShown =
            (self.uniqueFrame and self.uniqueFrame:IsShown()) or
            (self.missingFrame and self.missingFrame:IsShown())
        if self.uniqueFrame and self.uniqueFrame:IsShown() then
            self.uniqueFrame:Hide()
        end
        if self.missingFrame and self.missingFrame:IsShown() then
            self.missingFrame:Hide()
        end
        if customAchievementPanelShown then
            if AchievementFrame and type(AchievementFrameBaseTab_OnClick) == "function" then
                AchievementFrameBaseTab_OnClick(1)
            elseif AchievementFrame and type(AchievementFrameTab_OnClick) == "function" then
                AchievementFrameTab_OnClick(1)
            end
        end

        if self.uniqueTab then
            self.uniqueTab:Hide()
        end
        if self.missingTab then
            self.missingTab:Hide()
        end
        if self.dashboardFrame and self.dashboardFrame:IsShown() then
            self.dashboardFrame:Hide()
        end
        if self.recipeFrame and self.recipeFrame:IsShown() then
            self.recipeFrame:Hide()
        end
        if self.recipeGuideFrame and self.recipeGuideFrame:IsShown() then
            self.recipeGuideFrame:Hide()
        end
        if self.headerHitbox then
            self.headerHitbox:EnableMouse(false)
        end
        if not quiet then
            Print("Disabled. Stored character, profession, quest and achievement data has been kept.")
        end
    end
end


function AA:IsMinimapButtonShown()
    if not self.db or not self.db.settings or not self.db.settings.minimap then
        return true
    end
    return self.db.settings.minimap.hide ~= true
end

function AA:SetMinimapButtonShown(shown)
    if not self.db then
        self:InitializeDatabase()
    end
    self.db.settings.minimap = type(self.db.settings.minimap) == "table" and self.db.settings.minimap or {}
    self.db.settings.minimap.hide = not (shown and true or false)

    if self.optionsMinimapCheck then
        self.optionsMinimapCheck:SetChecked(shown and true or false)
    end
    if self.minimapButton then
        if shown then
            self.minimapButton:Show()
        else
            self.minimapButton:Hide()
        end
    end
end

function AA:OpenOptions()
    self:CreateOptionsPanel()
    if InterfaceOptionsFrame_OpenToCategory and self.optionsPanel then
        InterfaceOptionsFrame_OpenToCategory(self.optionsPanel)
        InterfaceOptionsFrame_OpenToCategory(self.optionsPanel)
    end
end

local function IsValidCharacterSortMode(mode)
    for _, option in ipairs(CHARACTER_SORT_OPTIONS) do
        if option.value == mode then
            return true
        end
    end
    return false
end

function AA:GetCharacterSortMode()
    if not self.db or not self.db.settings then
        return "name_asc"
    end
    local mode = self.db.settings.characterSort
    if not IsValidCharacterSortMode(mode) then
        mode = "name_asc"
        self.db.settings.characterSort = mode
    end
    return mode
end

function AA:GetCharacterSortLabel()
    local mode = self:GetCharacterSortMode()
    for _, option in ipairs(CHARACTER_SORT_OPTIONS) do
        if option.value == mode then
            return option.text
        end
    end
    return "Name (A-Z)"
end

function AA:RefreshSortDropDowns()
    local label = self:GetCharacterSortLabel()
    if self.optionsSortDropDown and type(UIDropDownMenu_SetText) == "function" then
        UIDropDownMenu_SetText(self.optionsSortDropDown, label)
    end
    if self.uniqueSortDropDown and type(UIDropDownMenu_SetText) == "function" then
        UIDropDownMenu_SetText(self.uniqueSortDropDown, label)
    end
    if self.dashboardSortDropDown and type(UIDropDownMenu_SetText) == "function" then
        UIDropDownMenu_SetText(self.dashboardSortDropDown, label)
    end
end

function AA:SetCharacterSortMode(mode, quiet)
    if not IsValidCharacterSortMode(mode) then
        mode = "name_asc"
    end
    if not self.db then
        self:InitializeDatabase()
    end
    self.db.settings.characterSort = mode
    self:RefreshSortDropDowns()
    if self.uniqueFrame and self.uniqueFrame:IsShown() then
        self:RefreshUniqueTab(true)
    end
    if self.dashboardFrame and self.dashboardFrame:IsShown() then
        self:RefreshDashboard(true)
    end
    if not quiet then
        Print("Character order: " .. self:GetCharacterSortLabel() .. ".")
    end
end

local function RealmFilterKey(realm)
    return Lower(Trim(realm or "UnknownRealm"))
end

function AA:GetKnownRealmsSorted()
    local byKey = {}
    local result = {}

    if self.db and self.db.characters then
        for _, char in pairs(self.db.characters) do
            if type(char) == "table" and char.realm and char.realm ~= "" then
                local key = RealmFilterKey(char.realm)
                if not byKey[key] then
                    byKey[key] = char.realm
                end
            end
        end
    end

    local currentRealm = SafeRealmName()
    local currentKey = RealmFilterKey(currentRealm)
    if not byKey[currentKey] then
        byKey[currentKey] = currentRealm
    end

    for _, realm in pairs(byKey) do
        table.insert(result, realm)
    end
    table.sort(result, function(a, b)
        return Lower(a) < Lower(b)
    end)
    return result
end

function AA:IsRealmFilterAll()
    if not self.db or not self.db.settings then
        return true
    end
    return self.db.settings.realmFilterAll ~= false
end

function AA:IsRealmSelected(realm)
    if self:IsRealmFilterAll() then
        return true
    end
    local selected = self.db and self.db.settings and self.db.settings.selectedRealms
    return type(selected) == "table" and selected[RealmFilterKey(realm)] == true
end

function AA:GetSelectedRealmCount()
    if self:IsRealmFilterAll() then
        return #self:GetKnownRealmsSorted()
    end
    local count = 0
    local selected = self.db and self.db.settings and self.db.settings.selectedRealms or {}
    for _, realm in ipairs(self:GetKnownRealmsSorted()) do
        if selected[RealmFilterKey(realm)] then
            count = count + 1
        end
    end
    return count
end

function AA:GetRealmFilterLabel()
    local realms = self:GetKnownRealmsSorted()
    if self:IsRealmFilterAll() then
        return "All realms"
    end

    local selectedNames = {}
    for _, realm in ipairs(realms) do
        if self:IsRealmSelected(realm) then
            table.insert(selectedNames, realm)
        end
    end

    if #selectedNames == 0 then
        return "No realms"
    elseif #selectedNames == 1 then
        return selectedNames[1]
    elseif #selectedNames == 2 then
        return selectedNames[1] .. ", " .. selectedNames[2]
    end
    return tostring(#selectedNames) .. " realms"
end

function AA:RefreshRealmDropDowns()
    local label = self:GetRealmFilterLabel()
    if self.optionsRealmDropDown and type(UIDropDownMenu_SetText) == "function" then
        UIDropDownMenu_SetText(self.optionsRealmDropDown, label)
    end
    if self.uniqueRealmDropDown and type(UIDropDownMenu_SetText) == "function" then
        UIDropDownMenu_SetText(self.uniqueRealmDropDown, label)
    end
    if self.missingRealmDropDown and type(UIDropDownMenu_SetText) == "function" then
        UIDropDownMenu_SetText(self.missingRealmDropDown, label)
    end
    if self.dashboardRealmDropDown and type(UIDropDownMenu_SetText) == "function" then
        UIDropDownMenu_SetText(self.dashboardRealmDropDown, label)
    end
end

function AA:RealmFilterChanged(quiet)
    self:RefreshRealmDropDowns()

    -- The realm selection defines the comparison universe. Characters on
    -- unselected realms are ignored completely by Unique and Oldest indexes.
    self:InvalidateIndex()

    if self.uniqueFrame and self.uniqueFrame:IsShown() then
        local visible = self:GetVisibleScannedCharactersSorted()
        for _, char in ipairs(visible) do
            self.uniqueCollapsed[char.key] = true
        end
        self:RefreshUniqueTab(true)
    end
    if self.missingFrame and self.missingFrame:IsShown() then
        self:RefreshMissingTab(true)
    end
    if self.dashboardFrame and self.dashboardFrame:IsShown() then
        self:RefreshDashboard(true)
    end

    if not quiet then
        Print("Realm comparison filter: " .. self:GetRealmFilterLabel() .. ". Only selected realms are included in Unique/Oldest/Missing comparisons.")
    end
end

function AA:SetRealmFilterAll(enabled, quiet)
    if not self.db then
        self:InitializeDatabase()
    end
    self.db.settings.realmFilterAll = enabled and true or false
    if enabled then
        self.db.settings.selectedRealms = {}
    end
    self:RealmFilterChanged(quiet)
end

function AA:ToggleRealmSelection(realm)
    if not realm or realm == "" then
        return
    end
    if not self.db then
        self:InitializeDatabase()
    end

    local known = self:GetKnownRealmsSorted()
    local selected = self.db.settings.selectedRealms
    if type(selected) ~= "table" then
        selected = {}
        self.db.settings.selectedRealms = selected
    end

    local key = RealmFilterKey(realm)

    -- When the user clicks one realm while "All realms" is active, interpret it
    -- as turning that one realm off: materialize all known realms, then toggle it.
    if self:IsRealmFilterAll() then
        for _, knownRealm in ipairs(known) do
            selected[RealmFilterKey(knownRealm)] = true
        end
        self.db.settings.realmFilterAll = false
    end

    if selected[key] then
        selected[key] = nil
    else
        selected[key] = true
    end

    -- If every known realm is selected again, normalize back to "All realms" so
    -- realms discovered later are automatically visible too.
    local selectedCount = 0
    for _, knownRealm in ipairs(known) do
        if selected[RealmFilterKey(knownRealm)] then
            selectedCount = selectedCount + 1
        end
    end
    if #known > 0 and selectedCount == #known then
        self.db.settings.realmFilterAll = true
        self.db.settings.selectedRealms = {}
    end

    self:RealmFilterChanged(false)
end

function AA:ElevateDropDownLists(baseFrame)
    local maxLevels = UIDROPDOWNMENU_MAXLEVELS or 2
    local baseLevel = ((baseFrame and baseFrame.GetFrameLevel and baseFrame:GetFrameLevel()) or 100) + 30
    for level = 1, maxLevels do
        local list = _G["DropDownList" .. level]
        if list then
            list:SetToplevel(true)
            list:SetFrameStrata("TOOLTIP")
            list:SetFrameLevel(baseLevel + level)
        end
    end
end

function AA:AttachDropDownElevator(dropdown)
    if not dropdown or dropdown._aaDropDownElevatorAttached then
        return
    end
    dropdown._aaDropDownElevatorAttached = true

    local function elevate()
        AA:ElevateDropDownLists(dropdown:GetParent() or dropdown)
    end

    if dropdown.HookScript then
        dropdown:HookScript("OnMouseDown", elevate)
    end

    local button = dropdown.Button or (dropdown.GetName and dropdown:GetName() and _G[dropdown:GetName() .. "Button"])
    if button and button.HookScript then
        button:HookScript("OnClick", elevate)
    end
end

function AA:SetupRealmDropDown(dropdown, width)
    if not dropdown or type(UIDropDownMenu_Initialize) ~= "function" then
        return
    end

    UIDropDownMenu_Initialize(dropdown, function(self, level)
        if level ~= 1 then
            return
        end

        local allInfo = UIDropDownMenu_CreateInfo()
        allInfo.text = "All realms"
        -- Use a function instead of a snapshot boolean. MoP's UIDropDownMenu_Refresh
        -- re-evaluates function-valued checked states, which keeps the visible check
        -- box synchronized while the multi-select menu remains open.
        allInfo.checked = function()
            return AA:IsRealmFilterAll()
        end
        allInfo.isNotRadio = true
        allInfo.keepShownOnClick = true
        allInfo.func = function()
            AA:SetRealmFilterAll(true)
            if type(UIDropDownMenu_RefreshAll) == "function" then
                UIDropDownMenu_RefreshAll(dropdown)
            elseif type(UIDropDownMenu_Refresh) == "function" then
                UIDropDownMenu_Refresh(dropdown, nil, 1)
            end
        end
        UIDropDownMenu_AddButton(allInfo, level)

        local realms = AA:GetKnownRealmsSorted()
        for _, realm in ipairs(realms) do
            local realmName = realm
            local info = UIDropDownMenu_CreateInfo()
            info.text = realmName
            info.checked = function()
                return AA:IsRealmSelected(realmName)
            end
            info.isNotRadio = true
            info.keepShownOnClick = true
            info.func = function()
                AA:ToggleRealmSelection(realmName)
                if type(UIDropDownMenu_RefreshAll) == "function" then
                    UIDropDownMenu_RefreshAll(dropdown)
                elseif type(UIDropDownMenu_Refresh) == "function" then
                    UIDropDownMenu_Refresh(dropdown, nil, 1)
                end
            end
            UIDropDownMenu_AddButton(info, level)
        end
    end)

    UIDropDownMenu_SetWidth(dropdown, width or 170)
    UIDropDownMenu_SetText(dropdown, self:GetRealmFilterLabel())
    self:AttachDropDownElevator(dropdown)
end

function AA:GetUniqueViewMode()
    if not self.db or not self.db.settings then
        return "unique"
    end
    if self.db.settings.uniqueViewMode ~= "oldest" then
        self.db.settings.uniqueViewMode = "unique"
    end
    return self.db.settings.uniqueViewMode
end

function AA:SetUniqueViewMode(mode)
    if mode ~= "oldest" then
        mode = "unique"
    end
    if not self.db then
        self:InitializeDatabase()
    end
    self.db.settings.uniqueViewMode = mode

    if self.uniqueFrame and self.uniqueFrame.modeButton then
        self.uniqueFrame.modeButton:SetText(mode == "oldest" and "Show unique" or "Show oldest")
    end

    -- Switching views starts from a compact overview just like opening the tab.
    local chars = self:GetVisibleScannedCharactersSorted()
    for _, char in ipairs(chars) do
        self.uniqueCollapsed[char.key] = true
    end

    if self.uniqueFrame and self.uniqueFrame:IsShown() then
        self:RefreshUniqueTab(true)
    end
end

function AA:ToggleUniqueViewMode()
    if self:GetUniqueViewMode() == "oldest" then
        self:SetUniqueViewMode("unique")
    else
        self:SetUniqueViewMode("oldest")
    end
end

function AA:SetupSortDropDown(dropdown, width)
    if not dropdown or type(UIDropDownMenu_Initialize) ~= "function" then
        return
    end

    UIDropDownMenu_Initialize(dropdown, function(self, level)
        local current = AA:GetCharacterSortMode()
        for _, option in ipairs(CHARACTER_SORT_OPTIONS) do
            local mode = option.value
            local label = option.text
            local info = UIDropDownMenu_CreateInfo()
            info.text = label
            info.value = mode
            info.checked = (current == mode)
            info.func = function()
                AA:SetCharacterSortMode(mode)
                if type(CloseDropDownMenus) == "function" then
                    CloseDropDownMenus()
                end
            end
            UIDropDownMenu_AddButton(info, level)
        end
    end)

    UIDropDownMenu_SetWidth(dropdown, width or 185)
    UIDropDownMenu_SetText(dropdown, self:GetCharacterSortLabel())
    self:AttachDropDownElevator(dropdown)
end

function AA:GetDashboardView()
    if not self.db or not self.db.settings then
        return "professions"
    end
    local value = self.db.settings.dashboardView
    for _, option in ipairs(DASHBOARD_VIEW_OPTIONS) do
        if option.value == value then
            return value
        end
    end
    return "professions"
end

function AA:GetDashboardViewLabel()
    local value = self:GetDashboardView()
    for _, option in ipairs(DASHBOARD_VIEW_OPTIONS) do
        if option.value == value then
            return option.text
        end
    end
    return "Professions"
end

function AA:SetDashboardView(value)
    if not self.db then
        self:InitializeDatabase()
    end
    local valid = false
    for _, option in ipairs(DASHBOARD_VIEW_OPTIONS) do
        if option.value == value then
            valid = true
            break
        end
    end
    if not valid then
        value = "professions"
    end
    self.db.settings.dashboardView = value
    if self.dashboardViewDropDown then
        UIDropDownMenu_SetText(self.dashboardViewDropDown, self:GetDashboardViewLabel())
    end
    if self.dashboardFrame then
        self:ConfigureDashboardLayout()
        if self.dashboardFrame:IsShown() then
            self:RefreshDashboard(true)
        end
    end
end

function AA:SetupDashboardViewDropDown(dropdown, width)
    UIDropDownMenu_SetWidth(dropdown, width or 170)
    UIDropDownMenu_SetText(dropdown, self:GetDashboardViewLabel())
    self:AttachDropDownElevator(dropdown)
    UIDropDownMenu_Initialize(dropdown, function(selfDrop, level)
        for _, option in ipairs(DASHBOARD_VIEW_OPTIONS) do
            local value = option.value
            local label = option.text
            local info = UIDropDownMenu_CreateInfo()
            info.text = label
            info.value = value
            info.checked = function() return AA:GetDashboardView() == value end
            info.func = function() AA:SetDashboardView(value) end
            UIDropDownMenu_AddButton(info, level)
        end
    end)
end

function AA:CreateOptionsPanel()
    if self.optionsPanel or type(InterfaceOptions_AddCategory) ~= "function" then
        return self.optionsPanel
    end

    local panel = CreateFrame("Frame", "AlternatorOptionsPanel", UIParent)
    panel.name = "Alternator"

    -- The 5.4.8 Interface Options category itself does not scroll.  Keep all
    -- Alternator controls on a scroll child so adding currencies/settings never
    -- causes one section to overlap another.
    local scroll = CreateFrame("ScrollFrame", "AlternatorOptionsScrollFrame", panel, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", panel, "TOPLEFT", 0, -4)
    scroll:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -28, 8)
    scroll:EnableMouseWheel(true)

    local content = CreateFrame("Frame", "AlternatorOptionsScrollChild", scroll)
    content:SetSize(620, 1260)
    scroll:SetScrollChild(content)
    panel.scroll = scroll
    panel.content = content

    scroll:SetScript("OnMouseWheel", function(self, delta)
        local maxScroll = math.max(0, (content:GetHeight() or 0) - (self:GetHeight() or 0))
        local nextValue = math.max(0, math.min(maxScroll, (self:GetVerticalScroll() or 0) - (delta * 42)))
        self:SetVerticalScroll(nextValue)
    end)
    panel:SetScript("OnSizeChanged", function(self, width)
        content:SetWidth(math.max(560, (width or 620) - 42))
    end)

    local title = content:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", content, "TOPLEFT", 16, -16)
    title:SetText("Alternator")

    local subtitle = content:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    subtitle:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -8)
    subtitle:SetWidth(570)
    subtitle:SetJustifyH("LEFT")
    subtitle:SetText("Account-wide alt manager for achievements, professions and recipes, Legendary Cloak progress, collections, locations, gold, currencies and character statistics.")
    subtitle:SetTextColor(0.85, 0.85, 0.85)

    local version = content:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    version:SetPoint("TOPLEFT", subtitle, "BOTTOMLEFT", 0, -18)
    version:SetText("Version: " .. VERSION)

    local author = content:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    author:SetPoint("TOPLEFT", version, "BOTTOMLEFT", 0, -6)
    author:SetText("Author: Crossic")

    local enable = CreateFrame("CheckButton", "AlternatorOptionsEnable", content, "InterfaceOptionsCheckButtonTemplate")
    enable:SetPoint("TOPLEFT", author, "BOTTOMLEFT", -4, -22)
    local enableText = _G[enable:GetName() .. "Text"]
    if enableText then enableText:SetText("Enable Alternator") end
    enable:SetScript("OnClick", function(self) AA:SetEnabled(self:GetChecked() and true or false) end)

    local minimap = CreateFrame("CheckButton", "AlternatorOptionsMinimap", content, "InterfaceOptionsCheckButtonTemplate")
    minimap:SetPoint("TOPLEFT", enable, "BOTTOMLEFT", 0, -4)
    local minimapText = _G[minimap:GetName() .. "Text"]
    if minimapText then minimapText:SetText("Show minimap button") end
    minimap:SetScript("OnClick", function(self) AA:SetMinimapButtonShown(self:GetChecked() and true or false) end)

    local minimapHelp = content:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    minimapHelp:SetPoint("TOPLEFT", minimap, "BOTTOMLEFT", 4, -2)
    minimapHelp:SetWidth(570)
    minimapHelp:SetJustifyH("LEFT")
    minimapHelp:SetText("Left-click: open the character overview. Right-click: open these settings. Hold the left mouse button and drag to move the icon around the minimap.")
    minimapHelp:SetTextColor(0.70, 0.70, 0.70)

    local resetMinimap = CreateFrame("Button", "AlternatorOptionsResetMinimap", content, "UIPanelButtonTemplate")
    resetMinimap:SetSize(170, 24)
    resetMinimap:SetPoint("TOPLEFT", minimapHelp, "BOTTOMLEFT", 0, -8)
    resetMinimap:SetText("Reset minimap position")
    resetMinimap:SetScript("OnClick", function() AA:ResetMinimapButtonPosition() end)

    local sortLabel = content:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    sortLabel:SetPoint("TOPLEFT", resetMinimap, "BOTTOMLEFT", 0, -18)
    sortLabel:SetText("Character order:")

    local sortDropDown = CreateFrame("Frame", "AlternatorOptionsSortDropDown", content, "UIDropDownMenuTemplate")
    sortDropDown:SetPoint("TOPLEFT", sortLabel, "BOTTOMLEFT", -16, 2)
    self:SetupSortDropDown(sortDropDown)

    local sortHelp = content:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    sortHelp:SetPoint("TOPLEFT", sortDropDown, "BOTTOMLEFT", 18, 2)
    sortHelp:SetWidth(570)
    sortHelp:SetJustifyH("LEFT")
    sortHelp:SetText("'Last online' means the last time Alternator saw that character online. WoW 5.4.8 does not expose the server's offline-character last-login time to addons.")
    sortHelp:SetTextColor(0.70, 0.70, 0.70)

    local realmLabel = content:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    realmLabel:SetPoint("TOPLEFT", sortHelp, "BOTTOMLEFT", 0, -18)
    realmLabel:SetText("Realms to compare / display:")

    local realmDropDown = CreateFrame("Frame", "AlternatorOptionsRealmDropDown", content, "UIDropDownMenuTemplate")
    realmDropDown:SetPoint("TOPLEFT", realmLabel, "BOTTOMLEFT", -16, 2)
    self:SetupRealmDropDown(realmDropDown, 200)

    local realmHelp = content:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    realmHelp:SetPoint("TOPLEFT", realmDropDown, "BOTTOMLEFT", 18, 2)
    realmHelp:SetWidth(570)
    realmHelp:SetJustifyH("LEFT")
    realmHelp:SetText("Choose one or several realms. Unselected realms are ignored by the Unique/Oldest achievement calculations and hidden from the character overview.")
    realmHelp:SetTextColor(0.70, 0.70, 0.70)

    local dataHelp = content:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    dataHelp:SetPoint("TOPLEFT", realmHelp, "BOTTOMLEFT", 0, -16)
    dataHelp:SetWidth(570)
    dataHelp:SetJustifyH("LEFT")
    dataHelp:SetText("Alternator can only refresh character-specific data while that character is logged in. Log each character once after installing this version to populate professions, quest progress, location, money, currencies, statistics history and collection snapshots.")
    dataHelp:SetTextColor(0.70, 0.70, 0.70)

    local statisticsTitle = content:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    statisticsTitle:SetPoint("TOPLEFT", dataHelp, "BOTTOMLEFT", 0, -24)
    statisticsTitle:SetText("Quest statistics:")

    local includeRepeatables = CreateFrame("CheckButton", "AlternatorOptionsIncludeRepeatables", content, "InterfaceOptionsCheckButtonTemplate")
    includeRepeatables:SetPoint("TOPLEFT", statisticsTitle, "BOTTOMLEFT", -4, -4)
    local includeRepeatablesText = _G[includeRepeatables:GetName() .. "Text"]
    if includeRepeatablesText then includeRepeatablesText:SetText("Include repeatable quests in quest totals") end
    includeRepeatables:SetScript("OnClick", function(self)
        AA.db.settings.includeRepeatableQuests = self:GetChecked() and true or false
        if AA.dashboardFrame and AA.dashboardFrame:IsShown() then AA:RefreshDashboard(false) end
    end)

    local repeatableHelp = content:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    repeatableHelp:SetPoint("TOPLEFT", includeRepeatables, "BOTTOMLEFT", 4, -2)
    repeatableHelp:SetWidth(570)
    repeatableHelp:SetJustifyH("LEFT")
    repeatableHelp:SetText("WoW 5.4.8 exposes daily quest completions separately. When disabled, Alternator subtracts daily completions from the total quest statistic. Other repeatable quest types that Blizzard does not expose separately may still be included.")
    repeatableHelp:SetTextColor(0.70, 0.70, 0.70)

    local backupTitle = content:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    backupTitle:SetPoint("TOPLEFT", repeatableHelp, "BOTTOMLEFT", 0, -24)
    backupTitle:SetText("Backup & Restore:")

    local backupStatus = content:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    backupStatus:SetPoint("TOPLEFT", backupTitle, "BOTTOMLEFT", 0, -6)
    backupStatus:SetWidth(570)
    backupStatus:SetJustifyH("LEFT")
    backupStatus:SetTextColor(0.70, 0.70, 0.70)

    local backupButton = CreateFrame("Button", "AlternatorOptionsBackupManager", content, "UIPanelButtonTemplate")
    backupButton:SetSize(180, 24)
    backupButton:SetPoint("TOPLEFT", backupStatus, "BOTTOMLEFT", 0, -8)
    backupButton:SetText("Open Backup Manager")
    backupButton:SetScript("OnClick", function() AA:OpenBackupManager() end)

    local backupHelp = content:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    backupHelp:SetPoint("TOPLEFT", backupButton, "BOTTOMLEFT", 0, -5)
    backupHelp:SetWidth(570)
    backupHelp:SetJustifyH("LEFT")
    backupHelp:SetText("AlternatorBackup stores automatic Character Statistics backups on Logout / Exit Game plus optional manual full AlternatorDB backups in a separate physical SavedVariables file. /reload does not create a backup.")
    backupHelp:SetTextColor(0.70, 0.70, 0.70)

    local currencyTitle = content:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    currencyTitle:SetPoint("TOPLEFT", backupHelp, "BOTTOMLEFT", 0, -24)
    currencyTitle:SetText("Currencies shown on character cards:")

    local currencyHelp = content:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    currencyHelp:SetPoint("TOPLEFT", currencyTitle, "BOTTOMLEFT", 0, -6)
    currencyHelp:SetWidth(570)
    currencyHelp:SetJustifyH("LEFT")
    currencyHelp:SetText("These checkboxes only control the compact currency line on character cards in the left column. The Overview tab always shows every tracked currency.")
    currencyHelp:SetTextColor(0.70, 0.70, 0.70)

    panel.currencyChecks = {}
    local currencyAnchor = currencyHelp
    for i, currency in ipairs(TRACKED_CURRENCIES) do
        local check = CreateFrame("CheckButton", "AlternatorCurrencyCheck" .. tostring(currency.id), content, "InterfaceOptionsCheckButtonTemplate")
        if i == 1 then
            check:SetPoint("TOPLEFT", currencyHelp, "BOTTOMLEFT", -4, -8)
        else
            check:SetPoint("TOPLEFT", currencyAnchor, "BOTTOMLEFT", 0, -1)
        end
        local label = _G[check:GetName() .. "Text"]
        if label then label:SetText(currency.name) end
        check.currencyID = currency.id
        check:SetScript("OnClick", function(self)
            AA.db.settings.shownCurrencies[tostring(self.currencyID)] = self:GetChecked() and true or false
            if AA.dashboardFrame and AA.dashboardFrame:IsShown() then AA:RefreshDashboard(false) end
        end)
        panel.currencyChecks[currency.id] = check
        currencyAnchor = check
    end

    local bottomHelp = content:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    bottomHelp:SetPoint("TOPLEFT", currencyAnchor, "BOTTOMLEFT", 4, -12)
    bottomHelp:SetWidth(570)
    bottomHelp:SetJustifyH("LEFT")
    bottomHelp:SetText("Tip: hover a character card to see all currencies currently enabled for the compact left-column display.")
    bottomHelp:SetTextColor(0.60, 0.60, 0.60)

    panel.refresh = function()
        enable:SetChecked(AA:IsEnabled())
        minimap:SetChecked(AA:IsMinimapButtonShown())
        includeRepeatables:SetChecked(AA.db.settings.includeRepeatableQuests ~= false)
        AA:RefreshSortDropDowns()
        AA:RefreshRealmDropDowns()
        for _, currency in ipairs(TRACKED_CURRENCIES) do
            local check = panel.currencyChecks and panel.currencyChecks[currency.id]
            if check then check:SetChecked(AA.db.settings.shownCurrencies[tostring(currency.id)] == true) end
        end
    end

    panel.default = function()
        AA:SetEnabled(true, true)
        AA:SetMinimapButtonShown(true)
        AA:SetCharacterSortMode("name_asc", true)
        AA:SetRealmFilterAll(true, true)
        AA:SetUniqueViewMode("unique")
        AA.db.settings.includeRepeatableQuests = true
        AA.db.settings.statisticsPeriod = "all"
        AA.db.settings.statisticsCustomDays = 14
        local defaultCustomFrom, defaultCustomTo = DefaultStatisticsCustomRange()
        AA.db.settings.statisticsCustomFrom = defaultCustomFrom
        AA.db.settings.statisticsCustomTo = defaultCustomTo
        AA.db.settings.dashboardSection = "characters"
        AA.db.settings.dashboardTab = "overview"
        for _, currency in ipairs(TRACKED_CURRENCIES) do
            AA.db.settings.shownCurrencies[tostring(currency.id)] = currency.default and true or false
        end
        enable:SetChecked(true)
        minimap:SetChecked(true)
        includeRepeatables:SetChecked(true)
        AA:RefreshSortDropDowns()
        AA:RefreshRealmDropDowns()
        for _, currency in ipairs(TRACKED_CURRENCIES) do
            local check = panel.currencyChecks and panel.currencyChecks[currency.id]
            if check then check:SetChecked(AA.db.settings.shownCurrencies[tostring(currency.id)] == true) end
        end
    end

    panel.okay = function() end

    InterfaceOptions_AddCategory(panel)

    self.optionsPanel = panel
    self.optionsEnableCheck = enable
    self.optionsMinimapCheck = minimap
    self.optionsIncludeRepeatablesCheck = includeRepeatables
    self.optionsBackupStatus = backupStatus
    self.optionsBackupButton = backupButton
    self.optionsSortDropDown = sortDropDown
    self.optionsRealmDropDown = realmDropDown
    enable:SetChecked(self:IsEnabled())
    minimap:SetChecked(self:IsMinimapButtonShown())
    includeRepeatables:SetChecked(self.db.settings.includeRepeatableQuests ~= false)
    self:RefreshSortDropDowns()
    self:RefreshRealmDropDowns()
    self:RefreshBackupOptionsStatus()
    panel:HookScript("OnShow", function() AA:RefreshBackupOptionsStatus() end)
    return panel
end

function AA:GetBackupSourceInfo()
    local char = self.db and self.db.characters and self.currentCharacterKey and self.db.characters[self.currentCharacterKey] or nil
    if type(char) == "table" then
        return {
            name = char.name,
            realm = char.realm,
            class = char.class,
        }
    end
    local name = type(UnitName) == "function" and UnitName("player") or nil
    local realm = type(GetRealmName) == "function" and GetRealmName() or nil
    local classFile = nil
    if type(UnitClass) == "function" then
        local _, token = UnitClass("player")
        classFile = token
    end
    return { name = name, realm = realm, class = classFile }
end

local BACKUP_FILTER_DEFS = {
    { key = "recent", label = "Recent" },
    { key = "daily", label = "Daily archive" },
    { key = "manualStats", label = "Manual stats" },
    { key = "full", label = "Full backup" },
    { key = "safety", label = "Safety" },
}

function AA:GetBackupFilterSelection()
    if type(self.backupFilterSelection) ~= "table" then
        self.backupFilterSelection = {}
        for _, def in ipairs(BACKUP_FILTER_DEFS) do self.backupFilterSelection[def.key] = true end
    end
    -- Legacy backups remain internally readable for migration compatibility,
    -- but are intentionally hidden from the normal Backup Manager UI.
    self.backupFilterSelection.legacy = nil
    return self.backupFilterSelection
end

function AA:IsBackupFilterAll()
    local selected = self:GetBackupFilterSelection()
    for _, def in ipairs(BACKUP_FILTER_DEFS) do
        if not selected[def.key] then return false end
    end
    return true
end

function AA:SetBackupFilterAll(value)
    local selected = self:GetBackupFilterSelection()
    for _, def in ipairs(BACKUP_FILTER_DEFS) do selected[def.key] = value and true or false end
end

function AA:ToggleBackupFilter(key)
    local selected = self:GetBackupFilterSelection()
    selected[key] = not selected[key]
    local any = false
    for _, def in ipairs(BACKUP_FILTER_DEFS) do
        if selected[def.key] then any = true break end
    end
    if not any then selected[key] = true end
end

function AA:GetBackupFilterLabel()
    if self:IsBackupFilterAll() then return "All backups" end
    local selected = self:GetBackupFilterSelection()
    local labels = {}
    for _, def in ipairs(BACKUP_FILTER_DEFS) do
        if selected[def.key] then table.insert(labels, def.label) end
    end
    if #labels <= 2 then return table.concat(labels, " + ") end
    return tostring(#labels) .. " types selected"
end

function AA:SetupBackupFilterDropDown(dropdown, width)
    if not dropdown or type(UIDropDownMenu_Initialize) ~= "function" then return end
    UIDropDownMenu_Initialize(dropdown, function(self, level)
        if level ~= 1 then return end

        local allInfo = UIDropDownMenu_CreateInfo()
        allInfo.text = "All backups"
        allInfo.checked = function() return AA:IsBackupFilterAll() end
        allInfo.isNotRadio = true
        allInfo.keepShownOnClick = true
        allInfo.func = function()
            AA:SetBackupFilterAll(true)
            UIDropDownMenu_SetText(dropdown, AA:GetBackupFilterLabel())
            if type(UIDropDownMenu_RefreshAll) == "function" then UIDropDownMenu_RefreshAll(dropdown)
            elseif type(UIDropDownMenu_Refresh) == "function" then UIDropDownMenu_Refresh(dropdown, nil, 1) end
            AA:RefreshBackupManager()
        end
        UIDropDownMenu_AddButton(allInfo, level)

        for _, def in ipairs(BACKUP_FILTER_DEFS) do
            local key, label = def.key, def.label
            local info = UIDropDownMenu_CreateInfo()
            info.text = label
            info.checked = function() return AA:GetBackupFilterSelection()[key] and true or false end
            info.isNotRadio = true
            info.keepShownOnClick = true
            info.func = function()
                AA:ToggleBackupFilter(key)
                UIDropDownMenu_SetText(dropdown, AA:GetBackupFilterLabel())
                if type(UIDropDownMenu_RefreshAll) == "function" then UIDropDownMenu_RefreshAll(dropdown)
                elseif type(UIDropDownMenu_Refresh) == "function" then UIDropDownMenu_Refresh(dropdown, nil, 1) end
                AA:RefreshBackupManager()
            end
            UIDropDownMenu_AddButton(info, level)
        end
    end)
    UIDropDownMenu_SetWidth(dropdown, width or 170)
    UIDropDownMenu_SetText(dropdown, self:GetBackupFilterLabel())
    self:AttachDropDownElevator(dropdown)
end

function AA:GetFilteredBackupInfos()
    local result = {}
    if type(_G.AlternatorBackup_GetSnapshotCount) ~= "function" or type(_G.AlternatorBackup_GetSnapshotInfo) ~= "function" then
        return result
    end
    local selected = self:GetBackupFilterSelection()
    local count = tonumber(_G.AlternatorBackup_GetSnapshotCount()) or 0
    for i = 1, count do
        local info = _G.AlternatorBackup_GetSnapshotInfo(i)
        local category = info and info.filterCategory or nil
        if info and category and selected[category] then table.insert(result, info) end
    end
    return result
end

function AA:RefreshBackupOptionsStatus()
    if not self.optionsBackupStatus then return end
    if type(_G.AlternatorBackup_GetSnapshotCount) ~= "function" then
        self.optionsBackupStatus:SetText("AlternatorBackup companion is not loaded. Install/enable the AlternatorBackup folder included with Alternator.")
        self.optionsBackupStatus:SetTextColor(1.0, 0.25, 0.25)
        if self.optionsBackupButton then self.optionsBackupButton:Disable() end
        return
    end
    local recentCount = type(_G.AlternatorBackup_GetRecentSnapshotCount) == "function" and (tonumber(_G.AlternatorBackup_GetRecentSnapshotCount()) or 0) or 0
    local dailyCount = type(_G.AlternatorBackup_GetDailySnapshotCount) == "function" and (tonumber(_G.AlternatorBackup_GetDailySnapshotCount()) or 0) or 0
    local manualCount = type(_G.AlternatorBackup_GetManualSnapshotCount) == "function" and (tonumber(_G.AlternatorBackup_GetManualSnapshotCount()) or 0) or 0
    local safetyCount = type(_G.AlternatorBackup_GetSafetySnapshotCount) == "function" and (tonumber(_G.AlternatorBackup_GetSafetySnapshotCount()) or 0) or 0
    self.optionsBackupStatus:SetText(string.format("Account-wide backup active: %d recent + %d daily archive + %d manual + %d safety snapshot(s) stored in AlternatorBackup.lua.", recentCount, dailyCount, manualCount, safetyCount))
    self.optionsBackupStatus:SetTextColor(0.70, 0.90, 0.70)
    if self.optionsBackupButton then self.optionsBackupButton:Enable() end
end

function AA:RefreshBackupManager()
    local frame = self.backupManagerFrame
    if not frame then return end
    local available = type(_G.AlternatorBackup_GetSnapshotCount) == "function" and type(_G.AlternatorBackup_GetSnapshotInfo) == "function"
    local rawCount = available and (tonumber(_G.AlternatorBackup_GetSnapshotCount()) or 0) or 0
    local infos = available and self:GetFilteredBackupInfos() or {}
    local count = #infos

    if frame.filterDropDown and type(UIDropDownMenu_SetText) == "function" then
        UIDropDownMenu_SetText(frame.filterDropDown, self:GetBackupFilterLabel())
    end

    if frame.status then
        if available then
            local recentCount = type(_G.AlternatorBackup_GetRecentSnapshotCount) == "function" and (tonumber(_G.AlternatorBackup_GetRecentSnapshotCount()) or 0) or 0
            local dailyCount = type(_G.AlternatorBackup_GetDailySnapshotCount) == "function" and (tonumber(_G.AlternatorBackup_GetDailySnapshotCount()) or 0) or 0
            local manualCount = type(_G.AlternatorBackup_GetManualSnapshotCount) == "function" and (tonumber(_G.AlternatorBackup_GetManualSnapshotCount()) or 0) or 0
            local safetyCount = type(_G.AlternatorBackup_GetSafetySnapshotCount) == "function" and (tonumber(_G.AlternatorBackup_GetSafetySnapshotCount()) or 0) or 0
            frame.status:SetText(string.format("%d recent / %d daily / %d manual / %d safety", recentCount, dailyCount, manualCount, safetyCount))
            frame.status:SetTextColor(0.8, 0.8, 0.8)
        else
            frame.status:SetText("AlternatorBackup companion is not loaded.")
            frame.status:SetTextColor(1, 0.25, 0.25)
        end
    end
    if frame.statisticsButton then
        if available and type(_G.AlternatorBackup_SaveNow) == "function" then frame.statisticsButton:Enable() else frame.statisticsButton:Disable() end
    end
    if frame.fullButton then
        if available and type(_G.AlternatorBackup_SaveFullNow) == "function" then frame.fullButton:Enable() else frame.fullButton:Disable() end
    end

    local visibleRows = frame.visibleRows or 10
    local rowHeight = frame.rowHeight or 30
    local lineHeight = frame.lineHeight or rowHeight
    local offset = 0
    if frame.scrollFrame and FauxScrollFrame_GetOffset then
        FauxScrollFrame_Update(frame.scrollFrame, count, visibleRows, lineHeight)
        offset = FauxScrollFrame_GetOffset(frame.scrollFrame) or 0
    end

    for line = 1, visibleRows do
        local row = frame.rows and frame.rows[line]
        local info = infos[offset + line]
        if row then
            if info then
                row:Show()
                local prefixMap = { ["Recent"] = "R", ["Daily archive"] = "D", ["Manual"] = "M", ["Safety"] = "S" }
                local prefix = prefixMap[info.storage] or "?"
                row.indexText:SetText(prefix .. tostring(tonumber(info.storageIndex) or (offset + line)))
                row.dateText:SetText(info.backupDate or "Unknown")
                if row.sourceText then
                    row.sourceText:SetText(tostring(info.sourceCharacterName or "Unknown"))
                    local classColor = RAID_CLASS_COLORS and info.sourceCharacterClass and RAID_CLASS_COLORS[info.sourceCharacterClass] or nil
                    if classColor then row.sourceText:SetTextColor(classColor.r or 1, classColor.g or 1, classColor.b or 1)
                    else row.sourceText:SetTextColor(0.72, 0.72, 0.72) end
                end
                row.versionText:SetText("v" .. tostring(info.alternatorVersion or "?"))
                local statisticsCharacterCount = tonumber(info.statisticsCharacterCount) or 0
                local historyBucketCount = tonumber(info.historyBucketCount) or 0
                if info.kind == "full" then
                    local dbCharacterCount = tonumber(info.dbCharacterCount) or 0
                    row.charactersText:SetText(string.format("Full DB: %d %s", dbCharacterCount, dbCharacterCount == 1 and "character" or "characters"))
                else
                    row.charactersText:SetText(string.format("%d stats %s", statisticsCharacterCount, statisticsCharacterCount == 1 and "character" or "characters"))
                end
                if statisticsCharacterCount == 0 and historyBucketCount == 0 then
                    row.statisticsText:SetText("No statistics history")
                else
                    row.statisticsText:SetText(string.format("%d %s, %d daily %s", statisticsCharacterCount, statisticsCharacterCount == 1 and "character" or "characters", historyBucketCount, historyBucketCount == 1 and "record" or "records"))
                end
                if row.storageText then row.storageText:SetText(tostring(info.storage or "Recent")) end
                local reason = tostring(info.reason or "logout")
                local reasonLabels = {
                    ["logout"] = "Logout",
                    ["exit game"] = "Exit game",
                    ["manual statistics"] = "Manual stats",
                    ["manual full"] = "Manual full",
                    ["pre-restore"] = "Stats safety",
                    ["pre-full-restore"] = "Full safety",
                }
                row.reasonText:SetText(reasonLabels[reason] or reason)
                row.restoreButton.snapshotId = info.id
                row.restoreButton.snapshotKind = info.kind or "statistics"
                row.restoreButton:SetText(info.kind == "full" and "Restore full" or "Restore stats")
                row.restoreButton:Enable()
                row.deleteButton.snapshotId = info.id
                row.deleteButton.snapshotLabel = prefix .. tostring(tonumber(info.storageIndex) or (offset + line))
                row.deleteButton:Show()
            else
                row:Hide()
            end
        end
    end
    if frame.emptyText then
        if count == 0 then
            frame.emptyText:SetText(rawCount > 0 and "No backups match the current filter." or "No backup snapshots have been created yet.")
            frame.emptyText:Show()
        else
            frame.emptyText:Hide()
        end
    end
    self:RefreshBackupOptionsStatus()
end

function AA:CreateBackupManager()
    if self.backupManagerFrame then return self.backupManagerFrame end

    local frame = CreateFrame("Frame", "AlternatorBackupManagerFrame", UIParent)
    frame:SetSize(1230, 560)
    frame:SetPoint("CENTER")
    frame:SetFrameStrata("FULLSCREEN_DIALOG")
    frame:SetClampedToScreen(true)
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    frame:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 16, edgeSize = 14,
        insets = { left = 4, right = 4, top = 4, bottom = 4 },
    })
    frame:SetBackdropColor(0.035, 0.025, 0.015, 1)
    frame:SetBackdropBorderColor(0.62, 0.44, 0.16, 1)

    local contentShade = frame:CreateTexture(nil, "BACKGROUND")
    contentShade:SetPoint("TOPLEFT", frame, "TOPLEFT", 5, -5)
    contentShade:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -5, 5)
    contentShade:SetTexture(0.018, 0.016, 0.014, 1)

    local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 24, -20)
    title:SetText("Alternator Backup Manager")
    title:SetTextColor(1, 0.82, 0)

    local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -6, -6)

    local help = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    help:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -8)
    help:SetWidth(1150)
    help:SetJustifyH("LEFT")
    help:SetText("Automatic Statistics backups are created only on Logout / Exit Game: 10 Recent plus 30 Daily archive entries. Manual Statistics and Full backups share a separate 10-backup rotation. /reload never creates an automatic snapshot.")
    help:SetTextColor(0.72, 0.72, 0.72)

    local separator = frame:CreateTexture(nil, "BORDER")
    separator:SetPoint("TOPLEFT", help, "BOTTOMLEFT", 0, -10)
    separator:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -24, -10)
    separator:SetHeight(1)
    separator:SetTexture(0.50, 0.37, 0.16, 0.65)

    local statisticsButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    statisticsButton:SetSize(165, 24)
    statisticsButton:SetPoint("TOPLEFT", separator, "BOTTOMLEFT", 0, -10)
    statisticsButton:SetText("Statistics backup")
    statisticsButton:SetScript("OnClick", function()
        if type(_G.AlternatorBackup_SaveNow) == "function" and _G.AlternatorBackup_SaveNow("manual statistics", AA:GetBackupSourceInfo()) then
            Print("Manual Character Statistics backup created in memory. It will be written to disk on the next /reload, logout or exit.")
            AA:RefreshBackupManager()
        else
            Print("Could not create Statistics backup. AlternatorBackup is not available.")
        end
    end)
    frame.statisticsButton = statisticsButton

    local fullButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    fullButton:SetSize(135, 24)
    fullButton:SetPoint("LEFT", statisticsButton, "RIGHT", 8, 0)
    fullButton:SetText("Full backup")
    fullButton:SetScript("OnClick", function()
        if type(_G.AlternatorBackup_SaveFullNow) == "function" and _G.AlternatorBackup_SaveFullNow("manual full", AA:GetBackupSourceInfo()) then
            Print("Manual full AlternatorDB backup created in memory. It will be written to disk on the next /reload, logout or exit.")
            AA:RefreshBackupManager()
        else
            Print("Could not create full backup. AlternatorBackup is not available.")
        end
    end)
    frame.fullButton = fullButton

    local filterLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    filterLabel:SetPoint("LEFT", fullButton, "RIGHT", 18, 0)
    filterLabel:SetText("Show:")
    filterLabel:SetTextColor(1, 0.82, 0)

    local filterDropDown = CreateFrame("Frame", "AlternatorBackupFilterDropDown", frame, "UIDropDownMenuTemplate")
    filterDropDown:SetPoint("LEFT", filterLabel, "RIGHT", -12, -2)
    self:SetupBackupFilterDropDown(filterDropDown, 180)
    frame.filterDropDown = filterDropDown

    local status = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    status:SetPoint("LEFT", filterDropDown, "RIGHT", 6, 2)
    status:SetPoint("RIGHT", frame, "RIGHT", -30, 0)
    status:SetJustifyH("LEFT")
    status:SetTextColor(0.72, 0.72, 0.72)
    frame.status = status

    local header = CreateFrame("Frame", nil, frame)
    header:SetPoint("TOPLEFT", statisticsButton, "BOTTOMLEFT", 0, -18)
    header:SetPoint("RIGHT", frame, "RIGHT", -42, 0)
    header:SetHeight(24)
    local hbg = header:CreateTexture(nil, "BACKGROUND")
    hbg:SetAllPoints()
    hbg:SetTexture(0.04, 0.04, 0.04, 0.95)
    local hline = header:CreateTexture(nil, "BORDER")
    hline:SetPoint("BOTTOMLEFT", header, "BOTTOMLEFT", 0, 0)
    hline:SetPoint("BOTTOMRIGHT", header, "BOTTOMRIGHT", 0, 0)
    hline:SetHeight(1)
    hline:SetTexture(0.50, 0.37, 0.16, 0.85)
    local headers = {
        {"#", 8}, {"Snapshot", 38}, {"Character", 235}, {"Version", 365}, {"Contents", 455}, {"Statistics history", 625}, {"Set", 855}, {"Type", 955},
    }
    for _, h in ipairs(headers) do
        local fs = header:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        fs:SetPoint("LEFT", header, "LEFT", h[2], 0)
        fs:SetText(h[1])
        fs:SetTextColor(1, 0.82, 0)
    end

    local rowHeight = 28
    local visibleRows = 11
    frame.rowHeight = rowHeight
    frame.lineHeight = rowHeight + 2
    frame.visibleRows = visibleRows

    local rowContainer = CreateFrame("Frame", nil, frame)
    rowContainer:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, -2)
    rowContainer:SetPoint("RIGHT", header, "RIGHT", 0, 0)
    rowContainer:SetHeight((rowHeight + 2) * visibleRows)
    local containerBG = rowContainer:CreateTexture(nil, "BACKGROUND")
    containerBG:SetAllPoints()
    containerBG:SetTexture(0.018, 0.016, 0.014, 0.96)
    frame.rowContainer = rowContainer

    local scrollFrame = CreateFrame("ScrollFrame", "AlternatorBackupManagerScrollFrame", frame, "FauxScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", rowContainer, "TOPLEFT", 0, 0)
    scrollFrame:SetPoint("BOTTOMRIGHT", rowContainer, "BOTTOMRIGHT", 0, 0)
    scrollFrame:SetScript("OnVerticalScroll", function(self, offset)
        FauxScrollFrame_OnVerticalScroll(self, offset, frame.lineHeight, function() AA:RefreshBackupManager() end)
    end)
    frame.scrollFrame = scrollFrame

    frame.rows = {}
    local previous = nil
    for i = 1, visibleRows do
        local row = CreateFrame("Frame", nil, rowContainer)
        if previous then row:SetPoint("TOPLEFT", previous, "BOTTOMLEFT", 0, -2)
        else row:SetPoint("TOPLEFT", rowContainer, "TOPLEFT", 0, 0) end
        row:SetPoint("RIGHT", rowContainer, "RIGHT", 0, 0)
        row:SetHeight(rowHeight)
        local bg = row:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetTexture(0.10, 0.10, 0.10, (i % 2 == 0) and 0.75 or 0.55)
        local bottomLine = row:CreateTexture(nil, "BORDER")
        bottomLine:SetPoint("BOTTOMLEFT", row, "BOTTOMLEFT", 0, 0)
        bottomLine:SetPoint("BOTTOMRIGHT", row, "BOTTOMRIGHT", 0, 0)
        bottomLine:SetHeight(1)
        bottomLine:SetTexture(0.22, 0.18, 0.10, 0.55)

        row.indexText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        row.indexText:SetPoint("LEFT", 8, 0); row.indexText:SetWidth(26); row.indexText:SetJustifyH("LEFT")
        row.dateText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        row.dateText:SetPoint("LEFT", 38, 0); row.dateText:SetWidth(190); row.dateText:SetJustifyH("LEFT")
        row.sourceText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        row.sourceText:SetPoint("LEFT", 235, 0); row.sourceText:SetWidth(120); row.sourceText:SetJustifyH("LEFT")
        row.versionText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        row.versionText:SetPoint("LEFT", 365, 0); row.versionText:SetWidth(80); row.versionText:SetJustifyH("LEFT")
        row.charactersText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        row.charactersText:SetPoint("LEFT", 455, 0); row.charactersText:SetWidth(160); row.charactersText:SetJustifyH("LEFT")
        row.statisticsText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        row.statisticsText:SetPoint("LEFT", 625, 0); row.statisticsText:SetWidth(220); row.statisticsText:SetJustifyH("LEFT")
        row.storageText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        row.storageText:SetPoint("LEFT", 855, 0); row.storageText:SetWidth(90); row.storageText:SetJustifyH("LEFT")
        row.reasonText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        row.reasonText:SetPoint("LEFT", 955, 0); row.reasonText:SetWidth(110); row.reasonText:SetJustifyH("LEFT")

        row.restoreButton = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        row.restoreButton:SetSize(96, 22)
        row.restoreButton:SetPoint("RIGHT", row, "RIGHT", -32, 0)
        row.restoreButton:SetScript("OnClick", function(self)
            if not self.snapshotId then return end
            local popup = self.snapshotKind == "full" and "ALTERNATOR_RESTORE_FULL_BACKUP" or "ALTERNATOR_RESTORE_BACKUP"
            StaticPopup_Show(popup, "", nil, { id = self.snapshotId })
        end)

        local deleteButton = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        deleteButton:SetSize(22, 20)
        deleteButton:SetPoint("RIGHT", row, "RIGHT", -3, 0)
        deleteButton:SetText("X")
        if deleteButton:GetFontString() then deleteButton:GetFontString():SetTextColor(1.00, 0.30, 0.30) end
        deleteButton:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:ClearLines()
            GameTooltip:AddLine("Delete backup", 1, 0.25, 0.25)
            GameTooltip:AddLine("Permanently removes this snapshot from AlternatorBackup.", 0.70, 0.70, 0.70, true)
            GameTooltip:Show()
        end)
        deleteButton:SetScript("OnLeave", function(self) if GameTooltip and GameTooltip:IsOwned(self) then GameTooltip:Hide() end end)
        deleteButton:SetScript("OnClick", function(self)
            if not self.snapshotId then return end
            StaticPopup_Show("ALTERNATOR_DELETE_BACKUP", self.snapshotLabel or "backup", nil, { id = self.snapshotId })
        end)
        row.deleteButton = deleteButton
        frame.rows[i] = row
        previous = row
    end

    local emptyText = rowContainer:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    emptyText:SetPoint("TOPLEFT", rowContainer, "TOPLEFT", 8, -18)
    emptyText:SetText("No backup snapshots have been created yet.")
    emptyText:SetTextColor(0.72, 0.72, 0.72)
    frame.emptyText = emptyText

    frame:SetScript("OnShow", function() AA:RefreshBackupManager() end)
    frame:Hide()
    if UISpecialFrames then table.insert(UISpecialFrames, "AlternatorBackupManagerFrame") end
    self.backupManagerFrame = frame
    return frame
end

function AA:OpenBackupManager()
    local frame = self:CreateBackupManager()
    frame:Show()
    frame:Raise()
    self:RefreshBackupManager()
end

StaticPopupDialogs["ALTERNATOR_RESTORE_BACKUP"] = {
    text = "Restore Character Statistics backup?\n\nOnly Character Statistics data will be restored/merged into the live Alternator database. A safety statistics snapshot will be created first.",
    button1 = YES,
    button2 = NO,
    OnAccept = function(self, data)
        local snapshotId = data and data.id
        if not snapshotId or type(_G.AlternatorBackup_RestoreSnapshotById) ~= "function" then
            Print("Backup restore failed: AlternatorBackup is not available.")
            return
        end
        if _G.AlternatorBackup_RestoreSnapshotById(snapshotId) then
            Print("Character Statistics restored. Reloading UI...")
            if type(ReloadUI) == "function" then ReloadUI() end
        else
            Print("Backup restore failed: snapshot is unavailable or invalid.")
        end
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

StaticPopupDialogs["ALTERNATOR_RESTORE_FULL_BACKUP"] = {
    text = "Restore full AlternatorDB backup?\n\nThe complete live Alternator database will be replaced, including settings and all stored character data. A full safety backup of the current database will be created first.",
    button1 = YES,
    button2 = NO,
    OnAccept = function(self, data)
        local snapshotId = data and data.id
        if not snapshotId or type(_G.AlternatorBackup_RestoreFullSnapshotById) ~= "function" then
            Print("Full backup restore failed: AlternatorBackup is not available.")
            return
        end
        if _G.AlternatorBackup_RestoreFullSnapshotById(snapshotId) then
            Print("Full AlternatorDB restored. Reloading UI...")
            if type(ReloadUI) == "function" then ReloadUI() end
        else
            Print("Full backup restore failed: snapshot is unavailable or invalid.")
        end
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

StaticPopupDialogs["ALTERNATOR_DELETE_BACKUP"] = {
    text = "Delete backup %s?\n\nThis permanently removes the selected backup from AlternatorBackup.",
    button1 = YES,
    button2 = NO,
    OnAccept = function(self, data)
        local snapshotId = data and data.id
        if not snapshotId or type(_G.AlternatorBackup_DeleteSnapshotById) ~= "function" then
            Print("Backup delete failed: AlternatorBackup is not available.")
            return
        end
        if _G.AlternatorBackup_DeleteSnapshotById(snapshotId) then
            Print("Backup deleted.")
            AA:RefreshBackupManager()
        else
            Print("Backup delete failed: snapshot is unavailable.")
        end
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

local function ReadSpecializationForGroup(groupIndex, activeGroup)
    if type(GetSpecialization) ~= "function" or type(GetSpecializationInfo) ~= "function" then
        return nil
    end

    local okIndex, specIndex = pcall(GetSpecialization, false, false, groupIndex)
    specIndex = okIndex and tonumber(specIndex) or nil
    if not specIndex or specIndex <= 0 then
        return nil
    end

    local okInfo, specID, name, description, icon, background, role = pcall(GetSpecializationInfo, specIndex)
    if not okInfo or not name then
        return nil
    end

    return {
        index = specIndex,
        id = tonumber(specID),
        name = name,
        description = description,
        icon = icon,
        background = background,
        role = role,
        group = groupIndex,
        active = tonumber(activeGroup) == tonumber(groupIndex),
        scannedAt = time(),
    }
end

local function ReadCurrentSpecializations()
    if type(GetSpecialization) ~= "function" or type(GetSpecializationInfo) ~= "function" then
        return nil
    end

    local activeGroup = 1
    if type(GetActiveSpecGroup) == "function" then
        local okGroup, value = pcall(GetActiveSpecGroup)
        if okGroup and tonumber(value) then activeGroup = tonumber(value) end
    end

    local numGroups = 1
    if type(GetNumSpecGroups) == "function" then
        local okNum, value = pcall(GetNumSpecGroups, false)
        if okNum and tonumber(value) then numGroups = math.max(1, tonumber(value)) end
    end

    local primary = ReadSpecializationForGroup(1, activeGroup)
    local secondary = nil
    if numGroups >= 2 then
        secondary = ReadSpecializationForGroup(2, activeGroup)
    end

    if not primary and not secondary then
        return nil
    end

    return {
        primary = primary,
        secondary = secondary,
        activeGroup = activeGroup,
        numGroups = numGroups,
        scannedAt = time(),
    }
end

local function ReadCurrentSpecialization()
    local specs = ReadCurrentSpecializations()
    if not specs then return nil end
    if tonumber(specs.activeGroup) == 2 then
        return specs.secondary or specs.primary
    end
    return specs.primary or specs.secondary
end

function AA:CaptureCurrentCharacterMoney(allowZero)
    if not self.db or type(GetMoney) ~= "function" then
        return false
    end

    -- CurrentCharacterKey() is preferred while the player API is healthy. During
    -- PLAYER_LOGOUT UnitName/GetRealmName can already be partially unavailable,
    -- so fall back to the last known live key instead of writing to Unknown-*.
    local liveKey = CurrentCharacterKey()
    local key = liveKey
    local char = self.db.characters and self.db.characters[key]
    if type(char) ~= "table" and self.currentCharacterKey then
        key = self.currentCharacterKey
        char = self.db.characters and self.db.characters[key]
    end
    if type(char) ~= "table" then
        return false
    end

    local money = tonumber(GetMoney())
    if money == nil then
        return false
    end

    self.db.moneySnapshots = type(self.db.moneySnapshots) == "table" and self.db.moneySnapshots or {}
    self.db.moneySnapshotsByGUID = type(self.db.moneySnapshotsByGUID) == "table" and self.db.moneySnapshotsByGUID or {}

    local previous = self.db.moneySnapshots[key]
    if type(previous) ~= "table" and char.guid and type(self.db.moneySnapshotsByGUID[char.guid]) == "table" then
        previous = self.db.moneySnapshotsByGUID[char.guid]
    end
    local previousAmount = previous and tonumber(previous.amount) or tonumber(char.money)
    local hasReliablePrevious = (previous and previous.scannedAt) or char.moneyScannedAt

    -- A zero reported during login/logout/loading can be transient on 5.4.8.
    -- Only PLAYER_MONEY passes allowZero=true, because that event represents an
    -- actual wallet change and is therefore allowed to persist a genuine zero.
    if money <= 0 and not allowZero and hasReliablePrevious and (tonumber(previousAmount) or 0) > 0 then
        return false
    end

    local stamp = time()
    char.money = money
    char.moneyScannedAt = stamp
    local snap = { amount = money, scannedAt = stamp, guid = char.guid }
    self.db.moneySnapshots[key] = snap
    if char.guid and char.guid ~= "" then
        self.db.moneySnapshotsByGUID[char.guid] = snap
    end
    return true
end

function AA:GetStoredCharacterMoney(char)
    if type(char) ~= "table" then return 0 end
    local db = self.db
    if db and type(db.moneySnapshots) == "table" then
        local key = char.key or ((char.name or "Unknown") .. "-" .. (char.realm or "UnknownRealm"))
        local snap = db.moneySnapshots[key]
        if type(snap) ~= "table" and char.guid and type(db.moneySnapshotsByGUID) == "table" then
            snap = db.moneySnapshotsByGUID[char.guid]
        end
        if type(snap) == "table" and snap.amount ~= nil then
            return tonumber(snap.amount) or 0
        end
    end
    return tonumber(char.money) or 0
end

function AA:ScheduleMoneySnapshot(delay, retries)
    self.moneyScanAt = GetTime() + (tonumber(delay) or 0.5)
    self.moneyScanRetryCount = math.max(1, tonumber(retries) or 8)
end

function AA:UpdateCurrentCharacterMetadata()
    if not self.db then
        return
    end

    local key = CurrentCharacterKey()
    local name = UnitName("player") or "Unknown"
    local realm = SafeRealmName()
    local _, classFile = UnitClass("player")
    local raceName, raceFile
    if type(UnitRace) == "function" then
        raceName, raceFile = UnitRace("player")
    end
    local sex = type(UnitSex) == "function" and tonumber(UnitSex("player")) or nil

    local char = self.db.characters[key]
    if type(char) ~= "table" then
        char = {
            achievements = {},
            scanned = false,
        }
        self.db.characters[key] = char
    end

    char.key = key
    char.name = name
    char.realm = realm
    char.class = classFile or char.class or "UNKNOWN"
    char.level = UnitLevel("player") or char.level or 0
    if raceName and raceName ~= "" then char.race = raceName end
    if raceFile and raceFile ~= "" then char.raceFile = raceFile end
    if sex then
        char.sex = sex
        if sex == 2 then
            char.gender = "Male"
        elseif sex == 3 then
            char.gender = "Female"
        else
            char.gender = char.gender or "Unknown"
        end
    end
    char.faction = UnitFactionGroup and UnitFactionGroup("player") or char.faction
    char.guid = UnitGUID and UnitGUID("player") or char.guid
    char.achievements = type(char.achievements) == "table" and char.achievements or {}
    char.achievementDates = type(char.achievementDates) == "table" and char.achievementDates or {}

    local specializations = ReadCurrentSpecializations()
    if specializations then
        char.specializations = specializations
        char.specialization = tonumber(specializations.activeGroup) == 2
            and (specializations.secondary or specializations.primary)
            or (specializations.primary or specializations.secondary)
    elseif char.level and tonumber(char.level) and tonumber(char.level) < 10 then
        char.specializations = nil
        char.specialization = nil
    end

    if type(GetTotalAchievementPoints) == "function" then
        local totalAP = tonumber(GetTotalAchievementPoints())
        if totalAP then
            char.totalAchievementPoints = totalAP
            char.totalAchievementPointsAt = time()
        end
    end

    -- Generic metadata/profile refreshes must never validate a zero wallet value.
    -- Only PLAYER_MONEY is trusted to persist a genuine zero balance.
    self:CaptureCurrentCharacterMoney(false)
    if type(GetZoneText) == "function" then
        local zone = GetZoneText()
        if zone and zone ~= "" then char.zone = zone end
    end
    if type(GetSubZoneText) == "function" then
        local subzone = GetSubZoneText()
        if subzone and subzone ~= "" then char.subzone = subzone else char.subzone = nil end
    end
    char.currencies = type(char.currencies) == "table" and char.currencies or {}
    if type(GetCurrencyInfo) == "function" then
        for _, currency in ipairs(TRACKED_CURRENCIES) do
            local name, amount, texture, earnedThisWeek, weeklyMax, totalMax, isDiscovered = GetCurrencyInfo(currency.id)
            char.currencies[tostring(currency.id)] = {
                id = currency.id,
                name = name or currency.name,
                amount = tonumber(amount) or 0,
                texture = texture,
                earnedThisWeek = tonumber(earnedThisWeek),
                weeklyMax = tonumber(weeklyMax),
                totalMax = ((tonumber(totalMax) or 0) > 0 and tonumber(totalMax)) or tonumber(currency.totalCap) or 0,
                discovered = isDiscovered and true or false,
            }
            if texture and self.db then
                self.db.currencyTextures = type(self.db.currencyTextures) == "table" and self.db.currencyTextures or {}
                self.db.currencyTextures[tostring(currency.id)] = texture
            end
        end
    end
    char.resourcesScannedAt = time()

    self.currentCharacterKey = key
end


local function ReadProfession(index)
    if not index or not GetProfessionInfo then
        return nil
    end

    local name, icon, skillLevel, maxSkillLevel, numAbilities, spellOffset, skillLine, skillModifier = GetProfessionInfo(index)
    if not name then
        return nil
    end

    return {
        name = name,
        icon = icon,
        skill = tonumber(skillLevel) or 0,
        max = tonumber(maxSkillLevel) or 0,
        skillLine = tonumber(skillLine),
        modifier = tonumber(skillModifier) or 0,
        short = PROFESSION_ABBREVIATIONS[tonumber(skillLine)] or name,
    }
end

local function ProfessionSnapshotHasData(snapshot)
    if type(snapshot) ~= "table" then
        return false
    end
    return snapshot.primary1 ~= nil
        or snapshot.primary2 ~= nil
        or snapshot.archaeology ~= nil
        or snapshot.fishing ~= nil
        or snapshot.cooking ~= nil
        or snapshot.firstAid ~= nil
end

local function ParseItemIDFromLink(link)
    if not link then return nil end
    return tonumber(string.match(link, "item:(%d+)"))
end

local GEAR_ENCHANT_REQUIRED = {
    shoulder=true, back=true, chest=true, wrist=true,
    hands=true, legs=true, feet=true, mainhand=true,
}

-- MoP profession-only gear enhancements. Engineering tinkers can coexist with
-- regular enchants in the MoP era, while Blacksmithing adds extra sockets to
-- bracers/gloves and belt buckles add an extra socket to belts for everyone.
AA.GEAR_TINKER_BY_ENCHANT_ID = {
    [3599] = "EMP Generator",
    [3601] = "Frag Belt",
    [3603] = "Hand-Mounted Pyro Rocket",
    [3604] = "Hyperspeed Accelerators",
    [3605] = "Flexweave Underlay",
    [3860] = "Reticulated Armor Webbing",
    [4180] = "Quickflip Deflection Plates",
    [4181] = "Tazik Shocker",
    [4187] = "Invisibility Field",
    [4188] = "Grounded Plasma Shield",
    [4214] = "Cardboard Assassin",
    [4222] = "Mind Amplification Dish",
    [4223] = "Nitro Boosts",
    [4697] = "Phase Fingers",
    [4698] = "Incendiary Fireworks Launcher",
    [4750] = "Spinal Healing Injector",
    [4897] = "Goblin Glider",
    [4898] = "Synapse Springs",
    [5000] = "Watergliding Jets",
}

AA.GEAR_TINKER_PATTERNS = {
    { "goblin glider", "Goblin Glider" },
    { "incendiary fireworks launcher", "Incendiary Fireworks Launcher" },
    { "incindiary fireworks launcher", "Incendiary Fireworks Launcher" },
    { "phase fingers", "Phase Fingers" },
    { "synapse springs", "Synapse Springs" },
    { "watergliding jets", "Watergliding Jets" },
    { "cardboard assassin", "Cardboard Assassin" },
    { "grounded plasma shield", "Grounded Plasma Shield" },
    { "invisibility field", "Invisibility Field" },
    { "quickflip deflection plates", "Quickflip Deflection Plates" },
    { "spinal healing injector", "Spinal Healing Injector" },
    { "tazik shocker", "Tazik Shocker" },
    { "mind amplification dish", "Mind Amplification Dish" },
    { "nitro boosts", "Nitro Boosts" },
    { "hand-mounted pyro rocket", "Hand-Mounted Pyro Rocket" },
    { "hyperspeed accelerators", "Hyperspeed Accelerators" },
    { "reticulated armor webbing", "Reticulated Armor Webbing" },
    { "electromagnetic pulse generator", "EMP Generator" },
    { "emp generator", "EMP Generator" },
    { "flexweave underlay", "Flexweave Underlay" },
    { "frag belt", "Frag Belt" },
}

-- TwinStar's 5.4.8 tooltips often show only the tinker effect and not the
-- tinker recipe/name itself.  These English effect fragments are therefore a
-- second, server-friendly detection path after the locale-independent IDs and
-- explicit names above.
AA.GEAR_TINKER_EFFECT_PATTERNS = {
    { "highest stat is always chosen", "Synapse Springs" },
    { "increases your intellect, agility, or strength", "Synapse Springs" },
    { "increase your highest primary statistic", "Synapse Springs" },
    { "increase dodge", "Phase Fingers" },
    { "fire damage over 3 sec", "Incendiary Fireworks Launcher" },
    { "reduces your falling speed", "Goblin Glider" },
    { "deploy a goblin glider", "Goblin Glider" },
    { "walk on water and swim quickly", "Watergliding Jets" },
    { "greatly increase your run speed", "Nitro Boosts" },
    { "increases your run speed", "Nitro Boosts" },
    { "throw a cobalt frag bomb", "Frag Belt" },
    { "confuse nearby mechanical", "EMP Generator" },
    { "become invisible", "Invisibility Field" },
    { "inject", "Spinal Healing Injector" },
    { "increase your armor", "Quickflip Deflection Plates" },
}

AA.GEAR_SOCKET_ENHANCEMENT_IDS = {
    wrist = 3717,
    hands = 3723,
    waist = 3729,
}

function AA:CharacterHasProfessionSkillLine(char, skillLine)
    if not char or type(char.professions) ~= "table" then return false end
    local target = tonumber(skillLine)
    local expectedName = target and PROFESSION_NAMES_BY_SKILLLINE[target] or nil
    expectedName = expectedName and string.lower(expectedName) or nil
    for _, key in ipairs({ "primary1", "primary2" }) do
        local prof = char.professions[key]
        if prof then
            if tonumber(prof.skillLine) == target then return true end
            -- Older snapshots/private-server profession APIs may omit the
            -- skill-line id while still returning a usable profession name.
            if expectedName and string.lower(tostring(prof.name or "")) == expectedName then return true end
        end
    end
    return false
end

function AA:ItemLinkNumericFields(link)
    local values = {}
    if not link then return values end
    local payload = string.match(link, "item:([^|]+)")
    if not payload then return values end
    local index = 0
    for field in string.gmatch(payload .. ":", "([^:]*):") do
        index = index + 1
        -- Enhancement data may live in the regular enchant field or in the
        -- later MoP item-link fields. Skip the item ID and the four gem IDs so
        -- a coincidentally matching item/gem ID cannot be mistaken for a
        -- profession enhancement.
        if index == 2 or index >= 7 then
            local n = tonumber(field)
            if n then table.insert(values, n) end
        end
    end
    return values
end

function AA:ItemLinkContainsEnhancementID(link, enhancementID)
    local wanted = tonumber(enhancementID)
    if not wanted or wanted <= 0 then return false end
    for _, value in ipairs(AA:ItemLinkNumericFields(link)) do
        if value == wanted then return true end
    end
    return false
end

local function ParseItemLinkEnhancements(link)
    local result = { enchantID = 0, gemIDs = {}, gemSlots = {} }
    if not link then return result end
    local payload = string.match(link, "item:([^|]+)")
    if not payload then return result end
    local fields = {}
    for value in string.gmatch(payload .. ":", "([^:]*):") do
        table.insert(fields, value)
    end
    result.enchantID = tonumber(fields[2]) or 0
    for i=3,6 do
        local gemID = tonumber(fields[i]) or 0
        result.gemSlots[i-2] = gemID
        if gemID > 0 then table.insert(result.gemIDs, gemID) end
    end
    return result
end

-- GetItemInfo() on the 5.4.8 client returns the base item level. Item upgrades
-- are already reflected in the equipped-item tooltip, so scan that tooltip and
-- store the effective item level plus the visible upgrade/enchant/reforge data.
function AA:GetGearSnapshotTooltip()
    local tooltip = _G["AlternatorGearSnapshotTooltip"]
    if not tooltip then
        tooltip = CreateFrame("GameTooltip", "AlternatorGearSnapshotTooltip", UIParent, "GameTooltipTemplate")
        tooltip:SetOwner(UIParent, "ANCHOR_NONE")
    end
    return tooltip
end

function AA:GearTooltipTextLines(slotID, link)
    local result = {}
    local tooltip = self:GetGearSnapshotTooltip()
    tooltip:ClearLines()
    tooltip:SetOwner(UIParent, "ANCHOR_NONE")

    -- The exact equipped item link carries the MoP upgrade/reforge data.  On
    -- some 5.4.8 clients SetInventoryItem() exposes the base item to a hidden
    -- scanner, while SetHyperlink() renders the same final tooltip the player
    -- sees on hover.  Prefer the hyperlink and only fall back to the slot.
    local ok = false
    if link and type(tooltip.SetHyperlink) == "function" then
        ok = pcall(tooltip.SetHyperlink, tooltip, link)
    end
    if (not ok) and slotID then
        ok = pcall(tooltip.SetInventoryItem, tooltip, "player", slotID)
    end
    if not ok then tooltip:Hide(); return result end

    tooltip:Show()
    local count = tonumber(tooltip:NumLines()) or 0
    for i=1,count do
        local left = _G["AlternatorGearSnapshotTooltipTextLeft" .. tostring(i)]
        local right = _G["AlternatorGearSnapshotTooltipTextRight" .. tostring(i)]
        local lt = left and left:GetText() or nil
        local rt = right and right:GetText() or nil
        if lt and lt ~= "" then table.insert(result, tostring(lt)) end
        if rt and rt ~= "" then table.insert(result, tostring(rt)) end
    end
    tooltip:Hide()
    return result
end

function AA:GearInventoryTooltipTextLines(slotID)
    local result = {}
    local slot = tonumber(slotID)
    if not slot then return result end

    local tooltip = self:GetGearSnapshotTooltip()
    tooltip:ClearLines()
    tooltip:SetOwner(UIParent, "ANCHOR_NONE")

    local ok = pcall(tooltip.SetInventoryItem, tooltip, "player", slot)
    if not ok then tooltip:Hide(); return result end

    tooltip:Show()
    local count = tonumber(tooltip:NumLines()) or 0
    for i=1,count do
        local left = _G["AlternatorGearSnapshotTooltipTextLeft" .. tostring(i)]
        local right = _G["AlternatorGearSnapshotTooltipTextRight" .. tostring(i)]
        local lt = left and left:GetText() or nil
        local rt = right and right:GetText() or nil
        if lt and lt ~= "" then table.insert(result, tostring(lt)) end
        if rt and rt ~= "" then table.insert(result, tostring(rt)) end
    end
    tooltip:Hide()
    return result
end

function AA:GearTooltipItemDetails(slotID, baseItemLevel, link, includeInventoryTinker)
    local details = { effectiveItemLevel = tonumber(baseItemLevel) }
    local canHaveTinker = tonumber(slotID) == 6 or tonumber(slotID) == 10 or tonumber(slotID) == 15
    local itemLevelPrefix = tostring(_G.ITEM_LEVEL or "Item Level %d")
    itemLevelPrefix = string.gsub(itemLevelPrefix, "%%d", "")
    itemLevelPrefix = string.gsub(itemLevelPrefix, "%s+$", "")

    for _, raw in ipairs(self:GearTooltipTextLines(slotID, link)) do
        local text = tostring(raw or "")
        local lower = string.lower(text)
        if itemLevelPrefix ~= "" and string.find(text, itemLevelPrefix, 1, true) then
            local value = tonumber(string.match(text, "(%d+)"))
            if value then details.effectiveItemLevel = value end
        elseif string.find(lower, "item level", 1, true) then
            local value = tonumber(string.match(text, "(%d+)"))
            if value then details.effectiveItemLevel = value end
        end

        if string.find(lower, "upgrade", 1, true) then
            local current, maximum = string.match(text, "(%d+)%s*/%s*(%d+)")
            if current and maximum then
                details.upgradeCurrent = tonumber(current)
                details.upgradeMax = tonumber(maximum)
                details.upgradeText = tostring(current) .. "/" .. tostring(maximum)
            end
        end

        if string.find(lower, "enchanted", 1, true) or string.find(lower, "enchant:", 1, true) then
            details.enchantText = text
        elseif string.find(lower, "reforg", 1, true) then
            details.reforgeText = text
        end

        if canHaveTinker and not details.tinkerText then
            for _, entry in ipairs(AA.GEAR_TINKER_PATTERNS) do
                if string.find(lower, entry[1], 1, true) then
                    details.tinkerText = entry[2]
                    break
                end
            end
        end
        if canHaveTinker and not details.tinkerText then
            for _, entry in ipairs(AA.GEAR_TINKER_EFFECT_PATTERNS) do
                if string.find(lower, entry[1], 1, true) then
                    details.tinkerText = entry[2]
                    break
                end
            end
        end
    end

    -- SetHyperlink() is ideal for upgraded ilvl/reforge data, but TwinStar's
    -- 5.4.8 client does not always include Engineering tinker Use: lines in a
    -- hyperlink tooltip.  While scanning the currently logged-in character,
    -- read the real equipped-slot tooltip as a second source.  Never do this
    -- while merely displaying an offline snapshot, otherwise another
    -- character's equipped item could contaminate the stored data.
    if includeInventoryTinker and canHaveTinker and not details.tinkerText then
        for _, raw in ipairs(self:GearInventoryTooltipTextLines(slotID)) do
            local lower = string.lower(tostring(raw or ""))
            for _, entry in ipairs(AA.GEAR_TINKER_PATTERNS) do
                if string.find(lower, entry[1], 1, true) then
                    details.tinkerText = entry[2]
                    break
                end
            end
            if not details.tinkerText then
                for _, entry in ipairs(AA.GEAR_TINKER_EFFECT_PATTERNS) do
                    if string.find(lower, entry[1], 1, true) then
                        details.tinkerText = entry[2]
                        break
                    end
                end
            end
            if details.tinkerText then break end
        end
    end

    -- Prefer the locale-independent enhancement id when it is present in the
    -- item link; tooltip-name detection above remains the private-server fallback.
    if canHaveTinker and link then
        for _, value in ipairs(AA:ItemLinkNumericFields(link)) do
            local tinkerName = AA.GEAR_TINKER_BY_ENCHANT_ID[value]
            if tinkerName then
                details.tinkerID = value
                details.tinkerText = tinkerName
                break
            end
        end
    end

    -- MoP item upgrades add four item levels per upgrade step.  Keep this as a
    -- fallback only; the tooltip value above is authoritative when available.
    if (not details.effectiveItemLevel or details.effectiveItemLevel == tonumber(baseItemLevel))
        and tonumber(details.upgradeCurrent) and tonumber(baseItemLevel) then
        details.effectiveItemLevel = tonumber(baseItemLevel) + (tonumber(details.upgradeCurrent) * 4)
    end
    return details
end

function AA:GearCleanEnchantText(text)
    text = tostring(text or "")
    text = string.gsub(text, "^[Ee]nchanted:%s*", "")
    text = string.gsub(text, "^[Ee]nchant:%s*", "")
    return text
end

function AA:GearCleanReforgeText(text)
    text = tostring(text or "")
    -- Keep the compact Gear table readable: the column header already says
    -- Reforge, so repeating "Reforged" on every row is unnecessary.
    text = string.gsub(text, "^[Rr]eforged:?%s*", "")
    text = string.gsub(text, "%([Rr]eforged%s+[Ff]rom%s+([^%)]+)%)", "(from %1)")
    text = string.gsub(text, "[Rr]eforged%s+[Ff]rom%s+", "from ")
    text = string.gsub(text, "^%((.*)%)$", "%1")
    text = string.gsub(text, "%s+[Tt][Oo]%s+", " -> ")
    return text
end

function AA:BuildGearGemSnapshot(link)
    local gems = {}
    if not link then return gems end
    local parsed = ParseItemLinkEnhancements(link)
    for index=1,4 do
        local gemName, gemLink
        if type(GetItemGem) == "function" then
            local ok, n, l = pcall(GetItemGem, link, index)
            if ok then gemName, gemLink = n, l end
        end
        local gemID = parsed.gemSlots and tonumber(parsed.gemSlots[index]) or nil
        if (gemName or gemLink or (gemID and gemID > 0)) then
            local query = gemLink or (gemID and ("item:" .. tostring(gemID))) or gemName
            local name, cachedLink, quality, _, _, _, _, _, _, icon
            if query and type(GetItemInfo) == "function" then
                name, cachedLink, quality, _, _, _, _, _, _, icon = GetItemInfo(query)
            end
            if not icon and gemID and type(GetItemIcon) == "function" then
                icon = GetItemIcon(gemID)
            end
            table.insert(gems, {
                index = index,
                itemID = gemID or ParseItemIDFromLink(gemLink),
                name = gemName or name or (gemID and ("Gem " .. tostring(gemID))) or "Gem",
                link = gemLink or cachedLink,
                icon = icon,
                quality = tonumber(quality),
            })
        end
    end
    return gems
end

local function CountItemSockets(link)
    if not link or type(GetItemStats) ~= "function" then return 0 end
    local ok, stats = pcall(GetItemStats, link)
    if not ok or type(stats) ~= "table" then return 0 end
    local total = 0
    for key, value in pairs(stats) do
        if type(key) == "string" and string.find(key, "EMPTY_SOCKET_", 1, true) == 1 then
            total = total + (tonumber(value) or 0)
        end
    end
    return total
end

local function CountItemGems(link)
    if not link then return 0 end
    local count = 0
    if type(GetItemGem) == "function" then
        for i=1,4 do
            local ok, gemName, gemLink = pcall(GetItemGem, link, i)
            if ok and (gemName or gemLink) then count = count + 1 end
        end
        if count > 0 then return count end
    end
    local parsed = ParseItemLinkEnhancements(link)
    return #(parsed.gemIDs or {})
end

-- GetItemStats() on old/private-server clients is not reliable for profession
-- sockets.  The item tooltip, however, still renders empty sockets using the
-- classic UI-EmptySocket-* textures.  Count those and combine them with filled
-- gem positions so an empty Blacksmithing/buckle socket is detectable too.
function AA:GearTooltipEmptySocketCount(link)
    if not link then return 0 end
    local tooltip = self:GetGearSnapshotTooltip()
    tooltip:ClearLines()
    tooltip:SetOwner(UIParent, "ANCHOR_NONE")
    local ok = pcall(tooltip.SetHyperlink, tooltip, link)
    if not ok then tooltip:Hide(); return 0 end
    tooltip:Show()
    local count = 0
    for i=1,20 do
        local tex = _G["AlternatorGearSnapshotTooltipTexture" .. tostring(i)]
        if tex and (not tex.IsShown or tex:IsShown()) then
            local texture = tex.GetTexture and tex:GetTexture() or nil
            if texture and string.find(string.lower(tostring(texture)), "emptysocket", 1, true) then
                count = count + 1
            end
        end
    end
    tooltip:Hide()
    return count
end

function AA:GearGetSocketCounts(item)
    if not item or not item.link then return 0, 0, 0 end
    local native = CountItemSockets(item.link)
    local filled = CountItemGems(item.link)
    local tooltipEmpty = AA:GearTooltipEmptySocketCount(item.link)
    local current = math.max(native, filled + tooltipEmpty)

    local base = 0
    if tonumber(item.itemID) then
        local baseLink = "item:" .. tostring(item.itemID)
        base = math.max(CountItemSockets(baseLink), AA:GearTooltipEmptySocketCount(baseLink))
    end
    if base <= 0 and current > 0 then
        -- Do not blindly copy current when a known profession enhancement is
        -- present: the whole point is to preserve current-base as the extra.
        local enhancementID = AA.GEAR_SOCKET_ENHANCEMENT_IDS[item.key]
        if not (enhancementID and AA:ItemLinkContainsEnhancementID(item.link, enhancementID)) then
            base = native
        end
    end

    -- Gem positions in the item link are another strong lower bound and work
    -- even when the tooltip has no empty-socket texture because every socket is filled.
    local parsed = ParseItemLinkEnhancements(item.link)
    local highestFilledGemSlot = 0
    for i=1,4 do
        if parsed.gemSlots and (tonumber(parsed.gemSlots[i]) or 0) > 0 then
            highestFilledGemSlot = i
        end
    end
    if highestFilledGemSlot > current then current = highestFilledGemSlot end

    local extra = math.max(0, current - base)
    local enhancementID = AA.GEAR_SOCKET_ENHANCEMENT_IDS[item.key]
    if extra < 1 and enhancementID and AA:ItemLinkContainsEnhancementID(item.link, enhancementID) then
        extra = 1
        current = math.max(current, base + 1)
    end
    return current, base, extra
end

function AA:GearGetExtraSocketDisplay(item, char, slotKey)
    if not item or not item.link then return nil, nil end
    local current, base, extra = AA:GearGetSocketCounts(item)
    if extra < 1 then return nil, nil end
    local key = slotKey or item.key
    if key == "waist" then
        return math.max(1, (tonumber(base) or 0) + 1), "Belt buckle socket"
    end
    if (key == "wrist" or key == "hands") and AA:CharacterHasProfessionSkillLine(char, 164) then
        return math.max(1, (tonumber(base) or 0) + 1), "Blacksmithing extra socket"
    end
    return nil, nil
end

local function GearItemShouldHaveEnchant(slotKey, item)
    if not GEAR_ENCHANT_REQUIRED[slotKey] or not item or not item.link then return false end
    if slotKey == "mainhand" then
        local equipLoc = tostring(item.equipLoc or "")
        return equipLoc == "INVTYPE_WEAPON"
            or equipLoc == "INVTYPE_2HWEAPON"
            or equipLoc == "INVTYPE_WEAPONMAINHAND"
            or equipLoc == "INVTYPE_RANGED"
            or equipLoc == "INVTYPE_RANGEDRIGHT"
    end
    return true
end

local function BuildGearAudit(snapshot, char)
    local audit = {
        slots = {}, issueCount = 0,
        missingEnchants = 0, emptySockets = 0, emptySlots = 0, missingExtraSockets = 0,
    }
    local isBlacksmith = AA:CharacterHasProfessionSkillLine(char, 164)
    if type(snapshot) ~= "table" or type(snapshot.slots) ~= "table" then return audit end

    local function addIssue(slotAudit, text, kind, severity)
        table.insert(slotAudit.issues, { text=text, kind=kind, severity=severity or "warning" })
        audit.issueCount = audit.issueCount + 1
        if kind == "enchant" then audit.missingEnchants = audit.missingEnchants + 1 end
        if kind == "socket" then audit.emptySockets = audit.emptySockets + 1 end
        if kind == "extraSocket" then audit.missingExtraSockets = audit.missingExtraSockets + 1 end
        if kind == "empty" then audit.emptySlots = audit.emptySlots + 1 end
        if severity == "error" then slotAudit.severity = "error"
        elseif slotAudit.severity ~= "error" then slotAudit.severity = "warning" end
    end

    for _, slotDef in ipairs(GEAR_SLOTS) do
        local item = snapshot.slots[slotDef.key]
        local slotAudit = { issues = {}, severity = "ok" }
        audit.slots[slotDef.key] = slotAudit

        if (not item or not item.link) and slotDef.key ~= "offhand" then
            addIssue(slotAudit, "No item equipped", "empty", "error")
        elseif item and item.link then
            if GearItemShouldHaveEnchant(slotDef.key, item) then
                local parsed = ParseItemLinkEnhancements(item.link)
                if (tonumber(parsed.enchantID) or 0) <= 0 then
                    addIssue(slotAudit, "Missing enchant", "enchant", "warning")
                end
            end

            local sockets, baseSockets, extraSockets = AA:GearGetSocketCounts(item)
            item.socketCount = sockets
            item.baseSocketCount = baseSockets
            item.extraSocketCount = extraSockets

            -- Belt buckles are available to every character. Blacksmiths also
            -- receive one profession socket on bracers and gloves.
            if slotDef.key == "waist" and extraSockets < 1 then
                addIssue(slotAudit, "Missing belt buckle socket", "extraSocket", "warning")
            elseif isBlacksmith and (slotDef.key == "wrist" or slotDef.key == "hands") and extraSockets < 1 then
                addIssue(slotAudit, "Missing Blacksmithing socket", "extraSocket", "warning")
            end

            if sockets > 0 then
                local gems = CountItemGems(item.link)
                local missing = math.max(0, sockets - gems)
                if missing > 0 then
                    addIssue(slotAudit, string.format("%d empty socket%s", missing, missing == 1 and "" or "s"), "socket", "warning")
                end
                slotAudit.socketCount = sockets
                slotAudit.baseSocketCount = baseSockets
                slotAudit.extraSocketCount = extraSockets
                slotAudit.gemCount = gems
            end
        end
    end

    audit.ok = audit.issueCount == 0
    return audit
end

local function BuildCurrentGearSnapshot(char)
    local snapshot = {
        slots = {},
        scannedAt = time(),
    }

    if type(GetAverageItemLevel) == "function" then
        local overall, equipped = GetAverageItemLevel()
        snapshot.overallItemLevel = tonumber(overall)
        snapshot.equippedItemLevel = tonumber(equipped) or tonumber(overall)
    end

    for _, slot in ipairs(GEAR_SLOTS) do
        local link = type(GetInventoryItemLink) == "function" and GetInventoryItemLink("player", slot.id) or nil
        local icon = type(GetInventoryItemTexture) == "function" and GetInventoryItemTexture("player", slot.id) or nil
        local data = {
            slotID = slot.id,
            key = slot.key,
            label = slot.label,
            link = link,
            icon = icon,
            itemID = ParseItemIDFromLink(link),
        }
        if link and type(GetItemInfo) == "function" then
            local name, itemLink, quality, itemLevel, requiredLevel, itemType, itemSubType, stackCount, equipLoc, texture = GetItemInfo(link)
            data.name = name
            -- Preserve the exact equipped link: it carries upgrade/reforge state.
            data.link = link
            data.quality = tonumber(quality)
            data.baseItemLevel = tonumber(itemLevel)
            data.itemLevel = tonumber(itemLevel)
            data.requiredLevel = tonumber(requiredLevel)
            data.itemType = itemType
            data.itemSubType = itemSubType
            data.equipLoc = equipLoc
            data.icon = texture or icon

            local tooltipDetails = AA:GearTooltipItemDetails(slot.id, data.baseItemLevel, data.link, true)
            data.effectiveItemLevel = tonumber(tooltipDetails.effectiveItemLevel) or data.baseItemLevel
            data.itemLevel = data.effectiveItemLevel or data.baseItemLevel
            data.upgradeCurrent = tooltipDetails.upgradeCurrent
            data.upgradeMax = tooltipDetails.upgradeMax
            data.upgradeText = tooltipDetails.upgradeText
            data.enchantText = tooltipDetails.enchantText
            data.reforgeText = tooltipDetails.reforgeText
            data.tinkerText = tooltipDetails.tinkerText
            data.tinkerID = tooltipDetails.tinkerID
            data.gems = AA:BuildGearGemSnapshot(data.link)
            data.socketCount, data.baseSocketCount, data.extraSocketCount = AA:GearGetSocketCounts(data)

            local parsed = ParseItemLinkEnhancements(data.link)
            data.enchantID = tonumber(parsed.enchantID) or 0
            if data.enchantID > 0 and (not data.enchantText or data.enchantText == "") then
                data.enchantText = "Enchant ID " .. tostring(data.enchantID)
            end
        end
        snapshot.slots[slot.key] = data
    end

    snapshot.audit = BuildGearAudit(snapshot, char)

    return snapshot
end

local function BuildCurrentReputationSnapshot()
    if type(GetNumFactions) ~= "function" or type(GetFactionInfo) ~= "function" then
        return nil
    end

    -- Expanding/collapsing reputation headers can itself fire UPDATE_FACTION.
    -- Suppress those synthetic events so a reputation scan cannot schedule an
    -- endless sequence of profile rescans.
    AA.reputationScanInProgress = true
    AA.reputationEventSuppressUntil = GetTime() + 1.0

    local collapsedNames = {}
    local safety = 0
    while safety < 20 do
        safety = safety + 1
        local expandedAny = false
        local count = tonumber(GetNumFactions()) or 0
        for i = count, 1, -1 do
            local name, _, _, _, _, _, _, _, isHeader, isCollapsed = GetFactionInfo(i)
            if isHeader and isCollapsed and name and type(ExpandFactionHeader) == "function" then
                collapsedNames[name] = true
                ExpandFactionHeader(i)
                expandedAny = true
            end
        end
        if not expandedAny then break end
    end

    local snapshot = { factions = {}, scannedAt = time() }
    local count = tonumber(GetNumFactions()) or 0
    for i = 1, count do
        local name, description, standingID, barMin, barMax, barValue, atWarWith, canToggleAtWar, isHeader, isCollapsed, hasRep, isWatched, isChild, factionID = GetFactionInfo(i)
        if name and ((not isHeader) or hasRep) then
            local minValue = tonumber(barMin) or 0
            local maxValue = tonumber(barMax) or 0
            local value = tonumber(barValue) or minValue
            table.insert(snapshot.factions, {
                name = name,
                description = description,
                standingID = tonumber(standingID) or 4,
                standing = REPUTATION_STANDING_NAMES[tonumber(standingID) or 4] or "Unknown",
                barMin = minValue,
                barMax = maxValue,
                barValue = value,
                progress = math.max(0, value - minValue),
                needed = math.max(0, maxValue - minValue),
                atWar = atWarWith and true or false,
                watched = isWatched and true or false,
                child = isChild and true or false,
                factionID = tonumber(factionID),
            })
        end
    end

    -- Restore the player's collapsed reputation headers as closely as the old
    -- API permits. Collapsing changes indices, so keep searching by name.
    if next(collapsedNames) and type(CollapseFactionHeader) == "function" then
        local pending = {}
        for name in pairs(collapsedNames) do pending[name] = true end
        local loops = 0
        while next(pending) and loops < 40 do
            loops = loops + 1
            local changed = false
            local n = tonumber(GetNumFactions()) or 0
            for i = n, 1, -1 do
                local name, _, _, _, _, _, _, _, isHeader, isCollapsed = GetFactionInfo(i)
                if isHeader and not isCollapsed and name and pending[name] then
                    CollapseFactionHeader(i)
                    pending[name] = nil
                    changed = true
                    break
                end
            end
            if not changed then break end
        end
    end

    table.sort(snapshot.factions, function(a, b)
        return Lower(a.name or "") < Lower(b.name or "")
    end)
    AA.reputationScanInProgress = false
    AA.reputationEventSuppressUntil = GetTime() + 0.75
    return snapshot
end

local function BuildProfessionSnapshot()
    local prof1, prof2, archaeology, fishing, cooking, firstAid
    if type(GetProfessions) == "function" then
        prof1, prof2, archaeology, fishing, cooking, firstAid = GetProfessions()
    end

    local anyIndex = prof1 or prof2 or archaeology or fishing or cooking or firstAid
    local snapshot = {
        primary1 = ReadProfession(prof1),
        primary2 = ReadProfession(prof2),
        archaeology = ReadProfession(archaeology),
        fishing = ReadProfession(fishing),
        cooking = ReadProfession(cooking),
        firstAid = ReadProfession(firstAid),
    }

    return snapshot, anyIndex and true or false
end

local function BuildMountDetailSnapshot()
    local details = {}
    local expectedCount = 0
    local capturedCount = 0

    if type(GetNumCompanions) ~= "function" or type(GetCompanionInfo) ~= "function" then
        return details, capturedCount, expectedCount
    end

    local okCount, count = pcall(GetNumCompanions, "MOUNT")
    expectedCount = okCount and (tonumber(count) or 0) or 0

    for i = 1, expectedCount do
        local ok, creatureID, creatureName, creatureSpellID, icon = pcall(GetCompanionInfo, "MOUNT", i)
        if ok and creatureName and creatureName ~= "" then
            capturedCount = capturedCount + 1

            -- Spell IDs are normally stable, but private-server implementations
            -- can occasionally expose faction/class variants differently. Keep a
            -- stable storage key while also storing a normalized display-name key
            -- used by the comparison code below.
            local storageKey
            if tonumber(creatureSpellID) and tonumber(creatureSpellID) > 0 then
                storageKey = "spell:" .. tostring(creatureSpellID)
            elseif tonumber(creatureID) and tonumber(creatureID) > 0 then
                storageKey = "creature:" .. tostring(creatureID)
            else
                storageKey = "name:" .. Lower(creatureName)
            end

            -- Defensive duplicate suffix: the journal can theoretically contain
            -- two entries with the same spell/creature identity during loading.
            if details[storageKey] then
                storageKey = storageKey .. ":slot:" .. tostring(i)
            end

            details[storageKey] = {
                name = creatureName,
                matchKey = Lower(creatureName),
                spellID = tonumber(creatureSpellID),
                creatureID = tonumber(creatureID),
                icon = icon,
            }
        end
    end

    return details, capturedCount, expectedCount
end

local function BuildPetDetailSnapshot()
    local details = {}
    local capturedOwned = 0
    local expectedOwned = 0

    if not C_PetJournal or type(C_PetJournal.GetNumPets) ~= "function" or type(C_PetJournal.GetPetInfoByIndex) ~= "function" then
        return details, capturedOwned, expectedOwned
    end

    local okCount, total, ownedTotal = pcall(C_PetJournal.GetNumPets)
    total = okCount and (tonumber(total) or 0) or 0
    expectedOwned = okCount and (tonumber(ownedTotal) or 0) or 0

    -- MoP 5.4.8's GetPetInfoByIndex() exposes the individual journal entries,
    -- including duplicate copies of the same species. Count every owned entry
    -- directly and aggregate those entries by speciesID. Do NOT use
    -- C_PetJournal.GetNumPetsInJournal(): that API did not exist in original
    -- MoP and caused older Alternator builds to collapse every species to one
    -- copy (for example 510 captured species vs 823 owned pets).
    for i = 1, total do
        local ok, petID, speciesID, owned, customName, level, favorite, isRevoked, speciesName, icon, petType, companionID = pcall(C_PetJournal.GetPetInfoByIndex, i)
        if ok and owned and speciesID then
            local key = tostring(speciesID)
            capturedOwned = capturedOwned + 1

            local entry = details[key]
            if entry then
                entry.count = (tonumber(entry.count) or 1) + 1
                if (not entry.name or entry.name == "") and (speciesName or customName) then
                    entry.name = speciesName or customName
                end
                if not entry.icon and icon then
                    entry.icon = icon
                end
            else
                details[key] = {
                    name = speciesName or customName or ("Species " .. key),
                    speciesID = tonumber(speciesID),
                    companionID = tonumber(companionID),
                    icon = icon,
                    count = 1,
                }
            end
        end
    end

    return details, capturedOwned, expectedOwned
end

local function BuildCollectionSnapshot(scanDetails, previous)
    local snapshot = {
        mounts = 0,
        companions = 0,
        petJournalAvailable = false,
        scannedAt = time(),
    }

    if type(GetNumCompanions) == "function" then
        local ok, count = pcall(GetNumCompanions, "MOUNT")
        if ok then
            snapshot.mounts = tonumber(count) or 0
        end
    end

    if C_PetJournal and type(C_PetJournal.GetNumPets) == "function" then
        local ok, total, owned = pcall(C_PetJournal.GetNumPets)
        if ok then
            snapshot.companions = tonumber(owned) or 0
            snapshot.petJournalAvailable = true
        end
    elseif type(GetNumCompanions) == "function" then
        local ok, count = pcall(GetNumCompanions, "CRITTER")
        if ok then
            snapshot.companions = tonumber(count) or 0
        end
    end

    if scanDetails then
        local mountDetails, mountCaptured, mountExpected = BuildMountDetailSnapshot()
        local petDetails, petCaptured, petExpected = BuildPetDetailSnapshot()

        snapshot.mountDetails = mountDetails
        snapshot.petDetails = petDetails
        snapshot.mountDetailCaptured = tonumber(mountCaptured) or 0
        snapshot.mountDetailExpected = tonumber(mountExpected) or snapshot.mounts or 0
        snapshot.petDetailCaptured = tonumber(petCaptured) or 0
        snapshot.petDetailExpected = tonumber(petExpected) or snapshot.companions or 0
        snapshot.mountDetailsComplete = snapshot.mountDetailCaptured == snapshot.mountDetailExpected
        snapshot.petDetailsComplete = (not snapshot.petJournalAvailable) or (snapshot.petDetailCaptured == snapshot.petDetailExpected)
        snapshot.detailsVersion = COLLECTION_DETAIL_VERSION
        snapshot.detailsScannedAt = time()
    elseif type(previous) == "table" then
        -- Counts are cheap to refresh on every profile update. Preserve the
        -- detailed set only when it was captured by the current comparison
        -- format; older formats are intentionally forced through a fresh scan.
        snapshot.mountDetails = previous.mountDetails
        snapshot.petDetails = previous.petDetails
        snapshot.mountDetailCaptured = previous.mountDetailCaptured
        snapshot.mountDetailExpected = previous.mountDetailExpected
        snapshot.petDetailCaptured = previous.petDetailCaptured
        snapshot.petDetailExpected = previous.petDetailExpected
        snapshot.mountDetailsComplete = previous.mountDetailsComplete
        snapshot.petDetailsComplete = previous.petDetailsComplete
        snapshot.detailsVersion = previous.detailsVersion
        snapshot.detailsScannedAt = previous.detailsScannedAt
    end

    return snapshot
end

local function QuestIsCompleted(questID)
    if not questID or type(IsQuestFlaggedCompleted) ~= "function" then
        return false
    end
    local ok, result = pcall(IsQuestFlaggedCompleted, questID)
    return ok and result and true or false
end

local function BuildQuestLogIndexMap()
    local map = {}
    if type(GetNumQuestLogEntries) ~= "function" or type(GetQuestLogTitle) ~= "function" then
        return map
    end

    local count = GetNumQuestLogEntries() or 0
    for i = 1, count do
        local title, level, tag, suggestedGroup, isHeader, isCollapsed, isComplete, frequency, questID = GetQuestLogTitle(i)
        if questID and not isHeader then
            map[questID] = i
        end
    end
    return map
end

local function ResolveMilestoneTitle(milestone, faction)
    if milestone and milestone.titles and faction and milestone.titles[faction] then
        return milestone.titles[faction]
    end
    return milestone and milestone.title or "Legendary quest"
end

local function ResolveMilestoneQuestID(milestone, faction, questLogMap)
    if milestone.questID then
        return milestone.questID
    end

    if milestone.questIDs then
        if faction and milestone.questIDs[faction] then
            return milestone.questIDs[faction]
        end

        -- Defensive fallback for unusual faction values/private-server behavior:
        -- prefer whichever faction variant is currently active/completed.
        for _, questID in pairs(milestone.questIDs) do
            if (questLogMap and questLogMap[questID]) or QuestIsCompleted(questID) then
                return questID
            end
        end

        return milestone.questIDs.Alliance or milestone.questIDs.Horde
    end

    if milestone.questAlternatives then
        for _, questID in ipairs(milestone.questAlternatives) do
            if (questLogMap and questLogMap[questID]) or QuestIsCompleted(questID) then
                return questID
            end
        end
        return milestone.questAlternatives[1]
    end
    return nil
end

local function ParseObjectiveNumbers(description)
    if not description then
        return nil, nil
    end
    local current, needed = string.match(description, "([%d,]+)%s*/%s*([%d,]+)")
    if not current or not needed then
        return nil, nil
    end
    current = tonumber((string.gsub(current, ",", "")))
    needed = tonumber((string.gsub(needed, ",", "")))
    return current, needed
end

local function ReadActiveQuestProgress(questLogIndex, milestone, questID, faction)
    if not questLogIndex then
        return "active"
    end

    local numObjectives = 0
    if type(GetNumQuestLeaderBoards) == "function" then
        -- The original 5.4.8 quest-log API expects a QuestLogIndex here,
        -- matching GetQuestLogLeaderBoard(objectiveIndex, questLogIndex).
        local ok, value = pcall(GetNumQuestLeaderBoards, questLogIndex)
        if ok then
            numObjectives = tonumber(value) or 0
        end
    end

    if milestone.progressMode == "valorAchievement" and milestone.achievementIDs and type(GetAchievementCriteriaInfo) == "function" then
        local achievementID = milestone.achievementIDs[faction] or milestone.achievementIDs.Alliance or milestone.achievementIDs.Horde
        if achievementID then
            local ok, criteriaString, criteriaType, completed, quantity, reqQuantity = pcall(GetAchievementCriteriaInfo, achievementID, 1)
            if ok then
                quantity = tonumber(quantity)
                reqQuantity = tonumber(reqQuantity)
                if quantity and reqQuantity and reqQuantity > 0 then
                    -- Original MoP stores Valor criteria in hundredths internally
                    -- (3000 displayed Valor = 300000 criterion quantity).
                    if reqQuantity >= 10000 then
                        quantity = math.floor(quantity / 100)
                        reqQuantity = math.floor(reqQuantity / 100)
                    end
                    return tostring(quantity) .. "/" .. tostring(reqQuantity)
                end
            end
        end
        return "active"
    end

    if milestone.progressMode == "binary" then
        local current, needed = 0, 0
        for objectiveIndex = 1, numObjectives do
            local description, objectiveType, isCompleted = GetQuestLogLeaderBoard(objectiveIndex, questLogIndex)
            local value, maxValue = ParseObjectiveNumbers(description)
            if value and maxValue then
                current = current + value
                needed = needed + maxValue
            else
                needed = needed + 1
                if isCompleted then
                    current = current + 1
                end
            end
        end
        if needed > 0 then
            return tostring(current) .. "/" .. tostring(needed)
        end
        return "active"
    end

    if milestone.progressMode == "multiObjective" then
        local parts = {}
        local indices = milestone.objectiveIndices or {}
        for _, objectiveIndex in ipairs(indices) do
            if objectiveIndex <= numObjectives or numObjectives == 0 then
                local description = GetQuestLogLeaderBoard(objectiveIndex, questLogIndex)
                local current, needed = ParseObjectiveNumbers(description)
                if current and needed then
                    table.insert(parts, tostring(current) .. "/" .. tostring(needed))
                end
            end
        end
        if #parts > 0 then
            return table.concat(parts, " + ")
        end
        return "active"
    end

    if milestone.progressMode == "objective" then
        local objectiveIndex = milestone.objectiveIndex or 1
        if objectiveIndex <= numObjectives or numObjectives == 0 then
            local description = GetQuestLogLeaderBoard(objectiveIndex, questLogIndex)
            local current, needed = ParseObjectiveNumbers(description)
            if current and needed then
                return tostring(current) .. "/" .. tostring(needed)
            end
        end
        return "active"
    end

    return "active"
end

function AA:GetCurrentStatisticCounters()
    if type(GetStatistic) ~= "function" then return nil end
    local result = {}
    local found = 0
    for key, def in pairs(CHARACTER_STATISTIC_DEFS) do
        local value = nil
        for _, statisticID in ipairs(GetStatisticCandidateIDs(def)) do
            local ok, raw = pcall(GetStatistic, statisticID)
            if ok then
                value = ParseStatisticNumber(raw, def.money)
                if value ~= nil then break end
            end
        end
        if value ~= nil then
            result[key] = value
            found = found + 1
        end
    end
    if found == 0 then return nil end
    return result
end

function AA:ScanCurrentCharacterStatistics()
    if not self.db or not self:IsEnabled() then return false end
    local key = self.currentCharacterKey or CurrentCharacterKey()
    local char = self.db.characters and self.db.characters[key]
    if not char then return false end

    local current = self:GetCurrentStatisticCounters()
    if type(current) ~= "table" then return false end

    local now = time()
    char.statistics = type(char.statistics) == "table" and char.statistics or {}
    local stats = char.statistics
    stats.history = type(stats.history) == "table" and stats.history or {}
    stats.lastCounters = type(stats.lastCounters) == "table" and stats.lastCounters or {}
    stats.lifetime = type(stats.lifetime) == "table" and stats.lifetime or {}
    stats.firstTrackedAt = tonumber(stats.firstTrackedAt) or now

    local bucket = nil
    local dayKey = StatisticsDayKey(now)
    for statKey, currentValue in pairs(current) do
        local previousValue = stats.lastCounters[statKey]
        if previousValue ~= nil then
            local delta = CounterDelta(previousValue, currentValue)
            if delta > 0 then
                if not bucket then
                    bucket = stats.history[dayKey]
                    if type(bucket) ~= "table" then
                        bucket = { timestamp = StartOfLocalDay(now) }
                        stats.history[dayKey] = bucket
                    end
                end
                bucket[statKey] = (tonumber(bucket[statKey]) or 0) + delta
            end
        end
        stats.lastCounters[statKey] = currentValue
        stats.lifetime[statKey] = currentValue
    end

    stats.scannedAt = now
    char.statisticsScannedAt = now
    return true
end

function AA:GetStatisticsPeriodBounds()
    local settings = self.db and self.db.settings or {}
    local mode = settings.statisticsPeriod or "all"
    local now = time()
    if mode == "all" then return nil, nil end
    if mode == "today" then return StartOfLocalDay(now), nil end
    if mode == "7d" then return now - (7 * 86400), nil end
    if mode == "30d" then return now - (30 * 86400), nil end
    if mode == "month" then return StartOfLocalMonth(now), nil end
    if mode == "custom" then
        local fromStamp = ParseStatisticsDate(settings.statisticsCustomFrom or "")
        local toStamp = ParseStatisticsDate(settings.statisticsCustomTo or "")
        if not fromStamp or not toStamp then
            local defaultFrom, defaultTo = DefaultStatisticsCustomRange()
            settings.statisticsCustomFrom = defaultFrom
            settings.statisticsCustomTo = defaultTo
            fromStamp = ParseStatisticsDate(defaultFrom)
            toStamp = ParseStatisticsDate(defaultTo)
        end
        if fromStamp > toStamp then
            fromStamp, toStamp = toStamp, fromStamp
            settings.statisticsCustomFrom = FormatStatisticsDate(fromStamp)
            settings.statisticsCustomTo = FormatStatisticsDate(toStamp)
        end
        return fromStamp, StartOfLocalDay(toStamp + (36 * 3600))
    end
    return nil, nil
end

function AA:GetCharacterStatisticValues(char)
    local stats = char and char.statistics
    local lifetime = stats and stats.lifetime or {}
    local settings = self.db and self.db.settings or {}
    local includeRepeatables = settings.includeRepeatableQuests ~= false
    local startAt, endAt = self:GetStatisticsPeriodBounds()
    local values = {}

    if not startAt then
        for key in pairs(CHARACTER_STATISTIC_DEFS) do values[key] = tonumber(lifetime[key]) end
        values.tracked = false
    else
        for key in pairs(CHARACTER_STATISTIC_DEFS) do values[key] = 0 end
        values.tracked = true
        if stats and type(stats.history) == "table" then
            for _, bucket in pairs(stats.history) do
                local bucketAt = type(bucket) == "table" and (tonumber(bucket.timestamp) or 0) or 0
                if type(bucket) == "table" and bucketAt >= startAt and (not endAt or bucketAt < endAt) then
                    for key in pairs(CHARACTER_STATISTIC_DEFS) do
                        values[key] = (tonumber(values[key]) or 0) + (tonumber(bucket[key]) or 0)
                    end
                end
            end
        end
    end

    local total = tonumber(values.questTotal)
    local daily = tonumber(values.questDaily) or 0
    if total ~= nil then
        values.questDisplay = includeRepeatables and total or math.max(0, total - daily)
    end
    values.includeRepeatables = includeRepeatables
    values.available = stats and stats.scannedAt and true or false
    values.firstTrackedAt = stats and stats.firstTrackedAt
    values.scannedAt = stats and stats.scannedAt
    values.periodStart = startAt
    values.periodEnd = endAt
    return values
end

function AA:GetStatisticsPeriodLabel()
    local settings = self.db and self.db.settings or {}
    return StatisticPeriodLabel(settings.statisticsPeriod or "all")
end

function AA:RefreshStatisticsCustomRangeControls()
    local frame = self.dashboardFrame
    if not frame then return end
    local custom = self.db and self.db.settings and self.db.settings.statisticsPeriod == "custom"
    local controls = {
        frame.statisticsCustomFromLabel, frame.statisticsCustomFromBox,
        frame.statisticsCustomToLabel, frame.statisticsCustomToBox,
    }
    for _, control in ipairs(controls) do
        if control then
            if custom then control:Show() else control:Hide() end
        end
    end
end

function AA:CommitStatisticsCustomRange()
    if not self.db then self:InitializeDatabase() end
    local frame = self.dashboardFrame
    if not frame then return end
    local fromText = frame.statisticsCustomFromBox and frame.statisticsCustomFromBox:GetText() or self.db.settings.statisticsCustomFrom
    local toText = frame.statisticsCustomToBox and frame.statisticsCustomToBox:GetText() or self.db.settings.statisticsCustomTo
    local fromStamp = ParseStatisticsDate(fromText or "")
    local toStamp = ParseStatisticsDate(toText or "")
    if not fromStamp or not toStamp then
        if frame.statisticsCustomFromBox then frame.statisticsCustomFromBox:SetText(self.db.settings.statisticsCustomFrom or "") end
        if frame.statisticsCustomToBox then frame.statisticsCustomToBox:SetText(self.db.settings.statisticsCustomTo or "") end
        return false
    end
    if fromStamp > toStamp then
        fromStamp, toStamp = toStamp, fromStamp
    end
    self.db.settings.statisticsCustomFrom = FormatStatisticsDate(fromStamp)
    self.db.settings.statisticsCustomTo = FormatStatisticsDate(toStamp)
    if frame.statisticsCustomFromBox then frame.statisticsCustomFromBox:SetText(self.db.settings.statisticsCustomFrom) end
    if frame.statisticsCustomToBox then frame.statisticsCustomToBox:SetText(self.db.settings.statisticsCustomTo) end
    if self.dashboardFrame and self.dashboardFrame:IsShown() then self:RefreshDashboard(false) end
    return true
end

function AA:SetStatisticsPeriod(value)
    if not self.db then self:InitializeDatabase() end
    local valid = false
    for _, option in ipairs(STATISTICS_PERIOD_OPTIONS) do if option.value == value then valid = true break end end
    if not valid then value = "all" end
    self.db.settings.statisticsPeriod = value
    if self.dashboardFrame and self.dashboardFrame.statisticsPeriodDropDown then
        UIDropDownMenu_SetText(self.dashboardFrame.statisticsPeriodDropDown, self:GetStatisticsPeriodLabel())
    end
    self:RefreshStatisticsCustomRangeControls()
    if self.dashboardFrame and self.dashboardFrame:IsShown() then self:RefreshDashboard(false) end
end

function AA:SetupStatisticsPeriodDropDown(dropdown)
    UIDropDownMenu_SetWidth(dropdown, 122)
    UIDropDownMenu_SetText(dropdown, self:GetStatisticsPeriodLabel())
    UIDropDownMenu_Initialize(dropdown, function(selfDrop, level)
        for _, option in ipairs(STATISTICS_PERIOD_OPTIONS) do
            local value = option.value
            local info = UIDropDownMenu_CreateInfo()
            info.text = option.text
            info.value = value
            info.checked = function() return AA.db.settings.statisticsPeriod == value end
            info.func = function() AA:SetStatisticsPeriod(value) end
            UIDropDownMenu_AddButton(info, level)
        end
    end)
end

function AA:ScheduleStatisticsScan(delay)
    if not self:IsEnabled() then self.statisticsScanAt = nil return end
    self.statisticsScanAt = GetTime() + (tonumber(delay) or 0.25)
end

function AA:RequestCurrentPlayedTime()
    if type(RequestTimePlayed) ~= "function" or not self:IsEnabled() then
        return
    end

    local now = GetTime and GetTime() or 0
    if self.playedRequestAt and now > 0 and (now - self.playedRequestAt) < 1.0 then
        return
    end

    self:UpdateCurrentCharacterMetadata()
    self.playedRequestAt = now
    self.playedRequestCharacterKey = self.currentCharacterKey or CurrentCharacterKey()
    RequestTimePlayed()
end

function AA:StoreCurrentPlayedTime(totalTime, levelTime)
    if not self.db or not self.db.characters then
        return
    end

    local total = tonumber(totalTime)
    local level = tonumber(levelTime)
    if not total or total < 0 then
        return
    end

    self:UpdateCurrentCharacterMetadata()
    local key = self.playedRequestCharacterKey or self.currentCharacterKey or CurrentCharacterKey()
    local char = self.db.characters[key] or self.db.characters[self.currentCharacterKey]
    if not char then
        self.playedRequestCharacterKey = nil
        return
    end

    char.playedTotal = math.floor(total)
    if level and level >= 0 then
        char.playedLevel = math.floor(level)
    end
    char.playedScannedAt = time()
    char.addonVersion = VERSION
    self.playedRequestCharacterKey = nil

    if self.dashboardFrame and self.dashboardFrame:IsShown() then
        self:RefreshDashboard(false)
    end
end

function AA:ScanCurrentCharacterProfile(quiet)
    if not self.db or not self:IsEnabled() then
        return
    end

    self:UpdateCurrentCharacterMetadata()
    local char = self.db.characters[self.currentCharacterKey]
    if not char then
        return
    end

    local professionSnapshot, professionAPIHasData = BuildProfessionSnapshot()
    local hadStoredProfessionData = ProfessionSnapshotHasData(char.professions)

    -- GetProfessions() can briefly return all nil during login/loading and, most
    -- importantly, while PLAYER_LOGOUT is tearing the character API down.
    -- Never destroy a valid stored snapshot because of that transient state.
    -- A fresh character with no stored snapshot is still allowed to store an
    -- empty profession set; later SKILL_LINES_CHANGED scans will fill it in.
    if professionAPIHasData or not hadStoredProfessionData then
        char.professions = professionSnapshot
        char.professionsScannedAt = time()
        char.professionsSnapshotValid = professionAPIHasData and true or nil
    else
        char.professionsSnapshotPreservedAt = time()
    end

    -- Gear and reputations are lightweight live snapshots and remain available
    -- while browsing the character offline later.
    char.gear = BuildCurrentGearSnapshot(char)
    char.gearScannedAt = time()
    local reputationSnapshot = BuildCurrentReputationSnapshot()
    if reputationSnapshot then
        char.reputations = reputationSnapshot
        char.reputationsScannedAt = time()
    end

    local previousCollections = char.collections
    local needCollectionDetails = char.collectionsForceDetailScan
        or type(previousCollections) ~= "table"
        or type(previousCollections.mountDetails) ~= "table"
        or type(previousCollections.petDetails) ~= "table"
        or previousCollections.detailsVersion ~= COLLECTION_DETAIL_VERSION
        or previousCollections.mountDetailsComplete ~= true
        or (previousCollections.petJournalAvailable and previousCollections.petDetailsComplete ~= true)
    char.collections = BuildCollectionSnapshot(needCollectionDetails, previousCollections)
    char.collectionsScannedAt = time()
    char.collectionsForceDetailScan = nil

    local questLogMap = BuildQuestLogIndexMap()
    local faction = UnitFactionGroup and UnitFactionGroup("player") or char.faction
    local legendary = {}

    for _, milestone in ipairs(LEGENDARY_MILESTONES) do
        local questID = ResolveMilestoneQuestID(milestone, faction, questLogMap)
        local state = {
            questID = questID,
            state = "none",
            text = "",
            title = ResolveMilestoneTitle(milestone, faction),
        }

        if questID and QuestIsCompleted(questID) then
            state.state = "done"
            state.text = "done"
        elseif questID and questLogMap[questID] then
            state.state = "active"
            state.text = ReadActiveQuestProgress(questLogMap[questID], milestone, questID, faction)
        end

        legendary[milestone.key] = state
    end

    -- Some breadcrumb quests were only offered while their patch was current,
    -- and 5.4 catch-up characters can legitimately skip them. Do not leave those
    -- rows permanently red once a later step proves that the player moved on.
    for i, milestone in ipairs(LEGENDARY_MILESTONES) do
        local state = legendary[milestone.key]
        if state and state.state == "none" and (milestone.optional or milestone.inferCompleteFromLater) then
            local laterProgress = false
            for j = i + 1, #LEGENDARY_MILESTONES do
                local laterState = legendary[LEGENDARY_MILESTONES[j].key]
                if laterState and (laterState.state == "done" or laterState.state == "active") then
                    laterProgress = true
                    break
                end
            end
            if laterProgress then
                if milestone.inferCompleteFromLater then
                    state.state = "done"
                    state.text = "done"
                else
                    state.state = "skipped"
                    state.text = "skipped"
                end
            end
        end
    end

    char.legendary = legendary
    self:ScanCurrentCharacterStatistics()
    char.legendaryChainVersion = 2
    char.legendaryScannedAt = time()
    char.profileScanned = true
    char.profileScanAt = time()
    char.lastSeen = time()
    char.addonVersion = VERSION

    self:RefreshRealmDropDowns()
    if self.dashboardFrame and self.dashboardFrame:IsShown() then
        self:RefreshDashboard(false)
    end
    if self.recipeGuideFrame and self.recipeGuideFrame:IsShown() then
        self:RefreshRecipeGuide()
    end

    if not quiet then
        self:RequestCurrentPlayedTime()
        Print("Character overview updated for " .. self:CharacterDisplayName(char) .. ".")
    end
end

function AA:ScheduleProfileScan(delay)
    if not self:IsEnabled() then
        self.profileScanAt = nil
        return
    end
    self.profileScanAt = GetTime() + (tonumber(delay) or 0.25)
end

function AA:GetScannedCharactersSorted()
    local result = {}
    if not self.db or not self.db.characters then
        return result
    end

    for key, char in pairs(self.db.characters) do
        if type(char) == "table" and char.scanned and type(char.achievements) == "table" then
            char.key = char.key or key
            table.insert(result, char)
        end
    end

    local mode = self:GetCharacterSortMode()
    table.sort(result, function(a, b)
        local aName = Lower(a.name)
        local bName = Lower(b.name)
        local aRealm = Lower(a.realm)
        local bRealm = Lower(b.realm)

        if mode == "class_asc" then
            local aClass = Lower((LOCALIZED_CLASS_NAMES_MALE and a.class and LOCALIZED_CLASS_NAMES_MALE[a.class]) or a.class or "Unknown")
            local bClass = Lower((LOCALIZED_CLASS_NAMES_MALE and b.class and LOCALIZED_CLASS_NAMES_MALE[b.class]) or b.class or "Unknown")
            if aClass ~= bClass then return aClass < bClass end
            if aName ~= bName then return aName < bName end
            return aRealm < bRealm
        end

        if mode == "last_seen_desc" or mode == "last_seen_asc" then
            local aSeen = tonumber(a.lastSeen or a.lastScan) or 0
            local bSeen = tonumber(b.lastSeen or b.lastScan) or 0
            if aSeen ~= bSeen then
                if mode == "last_seen_desc" then
                    return aSeen > bSeen
                else
                    return aSeen < bSeen
                end
            end
            -- Stable, predictable tie breaker.
            if aName ~= bName then
                return aName < bName
            end
            return aRealm < bRealm
        end

        if aName ~= bName then
            if mode == "name_desc" then
                return aName > bName
            else
                return aName < bName
            end
        end

        if mode == "name_desc" then
            return aRealm > bRealm
        end
        return aRealm < bRealm
    end)

    return result
end

function AA:GetVisibleScannedCharactersSorted()
    local all = self:GetScannedCharactersSorted()
    if self:IsRealmFilterAll() then
        return all
    end

    local visible = {}
    for _, char in ipairs(all) do
        if self:IsRealmSelected(char.realm or "UnknownRealm") then
            table.insert(visible, char)
        end
    end
    return visible
end


function AA:GetDashboardCharactersSorted()
    local result = {}
    if not self.db or not self.db.characters then
        return result
    end

    for key, char in pairs(self.db.characters) do
        if type(char) == "table" and (char.profileScanned or char.scanned) then
            char.key = char.key or key
            if self:IsRealmFilterAll() or self:IsRealmSelected(char.realm or "UnknownRealm") then
                table.insert(result, char)
            end
        end
    end

    local mode = self:GetCharacterSortMode()
    table.sort(result, function(a, b)
        local aName = Lower(a.name)
        local bName = Lower(b.name)
        local aRealm = Lower(a.realm)
        local bRealm = Lower(b.realm)

        if mode == "class_asc" then
            local aClass = Lower((LOCALIZED_CLASS_NAMES_MALE and a.class and LOCALIZED_CLASS_NAMES_MALE[a.class]) or a.class or "Unknown")
            local bClass = Lower((LOCALIZED_CLASS_NAMES_MALE and b.class and LOCALIZED_CLASS_NAMES_MALE[b.class]) or b.class or "Unknown")
            if aClass ~= bClass then return aClass < bClass end
            if aName ~= bName then return aName < bName end
            return aRealm < bRealm
        end

        if mode == "last_seen_desc" or mode == "last_seen_asc" then
            local aSeen = tonumber(a.lastSeen or a.profileScanAt or a.lastScan) or 0
            local bSeen = tonumber(b.lastSeen or b.profileScanAt or b.lastScan) or 0
            if aSeen ~= bSeen then
                if mode == "last_seen_desc" then
                    return aSeen > bSeen
                else
                    return aSeen < bSeen
                end
            end
        end

        if aName ~= bName then
            if mode == "name_desc" then
                return aName > bName
            else
                return aName < bName
            end
        end

        if mode == "name_desc" then
            return aRealm > bRealm
        end
        return aRealm < bRealm
    end)

    return result
end

function AA:CharacterDisplayName(char)
    if not char then
        return "Unknown"
    end

    local name = char.name or "Unknown"
    if char.realm and char.realm ~= "" and char.realm ~= SafeRealmName() then
        return name .. "-" .. char.realm
    end
    return name
end

function AA:TouchCurrentCharacterLastSeen()
    if not self.db then
        return
    end
    self:UpdateCurrentCharacterMetadata()
    local char = self.db.characters[self.currentCharacterKey]
    if char then
        char.lastSeen = time()
    end
end

function AA:InvalidateIndex()
    self.indexDirty = true
end

function AA:BuildOwnershipIndex()
    if not self.indexDirty and self.ownershipIndex and self.uniqueCounts and self.uniqueLists and self.oldestCounts and self.oldestLists and self.oldestPendingCounts and self.oldestIndex then
        return
    end

    local ownership = {}
    local uniqueCounts = {}
    local uniqueLists = {}
    local oldestCounts = {}
    local oldestLists = {}
    local oldestPendingCounts = {}
    local oldestIndex = {}
    local oldestSharedKnownCount = 0
    local oldestSharedUnknownCount = 0
    local chars = self:GetVisibleScannedCharactersSorted()

    for _, char in ipairs(chars) do
        uniqueCounts[char.key] = 0
        uniqueLists[char.key] = {}
        oldestCounts[char.key] = 0
        oldestLists[char.key] = {}
        oldestPendingCounts[char.key] = 0

        for achievementID, earned in pairs(char.achievements) do
            if earned then
                local entry = ownership[achievementID]
                if not entry then
                    entry = { count = 0, ownerKey = nil, owners = {} }
                    ownership[achievementID] = entry
                end
                entry.count = entry.count + 1
                table.insert(entry.owners, char.key)
                if entry.count == 1 then
                    entry.ownerKey = char.key
                else
                    entry.ownerKey = nil
                end
            end
        end
    end

    for achievementID, entry in pairs(ownership) do
        if entry.count == 1 and entry.ownerKey then
            uniqueCounts[entry.ownerKey] = (uniqueCounts[entry.ownerKey] or 0) + 1
            table.insert(uniqueLists[entry.ownerKey], achievementID)
        elseif entry.count > 1 then
            -- Only declare an oldest holder when every scanned owner has a stored
            -- character-specific completion date. This is intentionally strict:
            -- a missing date must never make a newer character look artificially old.
            local minDate = nil
            local oldestOwners = {}
            local datesComplete = true

            for _, charKey in ipairs(entry.owners) do
                local char = self.db.characters[charKey]
                local dateKey = char and char.achievementDates and tonumber(char.achievementDates[achievementID]) or nil
                if not dateKey then
                    datesComplete = false
                    break
                end

                if not minDate or dateKey < minDate then
                    minDate = dateKey
                    oldestOwners = { charKey }
                elseif dateKey == minDate then
                    table.insert(oldestOwners, charKey)
                end
            end

            if datesComplete and minDate then
                oldestSharedKnownCount = oldestSharedKnownCount + 1
                local oldestEntry = {
                    date = minDate,
                    owners = oldestOwners,
                    tie = (#oldestOwners > 1),
                    holderCount = entry.count,
                }
                oldestIndex[achievementID] = oldestEntry

                for _, charKey in ipairs(oldestOwners) do
                    oldestCounts[charKey] = (oldestCounts[charKey] or 0) + 1
                    table.insert(oldestLists[charKey], {
                        id = achievementID,
                        date = minDate,
                        tie = oldestEntry.tie,
                        holderCount = entry.count,
                    })
                end
            else
                oldestSharedUnknownCount = oldestSharedUnknownCount + 1
                for _, charKey in ipairs(entry.owners) do
                    oldestPendingCounts[charKey] = (oldestPendingCounts[charKey] or 0) + 1
                end
            end
        end
    end

    for key, list in pairs(uniqueLists) do
        table.sort(list, function(a, b)
            local aName = AchievementName(a)
            local bName = AchievementName(b)
            if aName == bName then
                return a < b
            end
            return aName < bName
        end)
    end

    for key, list in pairs(oldestLists) do
        table.sort(list, function(a, b)
            if a.date ~= b.date then
                return a.date < b.date
            end
            local aName = AchievementName(a.id)
            local bName = AchievementName(b.id)
            if aName == bName then
                return a.id < b.id
            end
            return aName < bName
        end)
    end

    self.ownershipIndex = ownership
    self.uniqueCounts = uniqueCounts
    self.uniqueLists = uniqueLists
    self.oldestCounts = oldestCounts
    self.oldestLists = oldestLists
    self.oldestPendingCounts = oldestPendingCounts
    self.oldestIndex = oldestIndex
    self.oldestSharedKnownCount = oldestSharedKnownCount
    self.oldestSharedUnknownCount = oldestSharedUnknownCount
    self.indexDirty = false
end

function AA:GetOwnershipEntry(achievementID)
    self:BuildOwnershipIndex()
    return self.ownershipIndex and self.ownershipIndex[achievementID]
end

function AA:GetOldestEntry(achievementID)
    self:BuildOwnershipIndex()
    return self.oldestIndex and self.oldestIndex[achievementID]
end

local function TableContains(list, value)
    if type(list) ~= "table" then
        return false
    end
    for _, item in ipairs(list) do
        if item == value then
            return true
        end
    end
    return false
end

function AA:GetCharacterByKey(key)
    if not self.db or not self.db.characters then
        return nil
    end
    return self.db.characters[key]
end

function AA:ResolveCharacter(query)
    query = Trim(query)
    if query == "" then
        return nil, "missing"
    end

    local wanted = Lower(query)
    local exactKey = self.db and self.db.characters and self.db.characters[query]
    if exactKey then
        return exactKey
    end

    local matches = {}
    for key, char in pairs(self.db.characters or {}) do
        local display = self:CharacterDisplayName(char)
        if Lower(key) == wanted or Lower(char.name) == wanted or Lower(display) == wanted then
            char.key = char.key or key
            table.insert(matches, char)
        end
    end

    if #matches == 1 then
        return matches[1]
    elseif #matches > 1 then
        return nil, "ambiguous", matches
    end

    return nil, "notfound"
end

function AA:StartScan(manual)
    if not self:IsEnabled() then
        if manual then
            Print("Alternator is disabled. Enable it in Interface > AddOns > Alternator.")
        end
        return
    end

    if self.scan then
        if manual then
            Print("A scan is already running.")
        end
        return
    end

    if not self.db then
        return
    end

    self:UpdateCurrentCharacterMetadata()

    local categories = GetCategoryList and GetCategoryList()
    if type(categories) ~= "table" or #categories == 0 then
        if manual then
            Print("Achievement categories are not available yet. Try again in a few seconds.")
        else
            self.autoScanAt = GetTime() + 3
        end
        return
    end

    -- Feats of Strength (category 81) are special: on some 5.4.8 clients the
    -- category can be omitted from GetCategoryList even though the character
    -- owns Feats. Explicitly include it so earned Feats are persisted in the
    -- per-character achievement snapshot and Missing can subtract them.
    local scanCategorySeen = {}
    for _, categoryID in ipairs(categories) do
        scanCategorySeen[tonumber(categoryID) or categoryID] = true
    end
    if not scanCategorySeen[81] and type(GetCategoryInfo) == "function" then
        local featTitle = GetCategoryInfo(81)
        if featTitle and featTitle ~= "" then
            table.insert(categories, 81)
        end
    end

    self.scan = {
        charKey = self.currentCharacterKey,
        categories = categories,
        categoryIndex = 1,
        achievementIndex = 1,
        categoryCount = 0,
        seen = {},
        achievements = {},
        achievementDates = {},
        total = 0,
        earned = 0,
        points = 0,
        wasEarnedFieldSeen = false,
        fallbackUsed = false,
        startedAt = GetTime(),
        manual = manual and true or false,
    }

    if manual then
        Print("Scanning achievements for " .. self.currentCharacterKey .. "...")
    end
end

function AA:EarnedByCurrentCharacter(completed, flags, wasEarnedByMe, earnedBy)
    if wasEarnedByMe ~= nil then
        return wasEarnedByMe and true or false, true, false
    end

    -- Compatibility fallback for cores that do not expose return value #13 correctly.
    local currentName = UnitName("player") or ""
    if earnedBy and earnedBy ~= "" and Lower(earnedBy) == Lower(currentName) then
        return true, false, true
    end

    -- For non-account-wide achievements, 'completed' necessarily belongs to this character.
    if completed and not IsAccountWide(flags) then
        return true, false, true
    end

    return false, false, true
end

function AA:ProcessScan()
    local scan = self.scan
    if not scan then
        return
    end

    local processed = 0

    while processed < SCAN_PER_FRAME and scan.categoryIndex <= #scan.categories do
        local categoryID = scan.categories[scan.categoryIndex]

        if scan.categoryCount == 0 then
            local count = GetCategoryNumAchievements(categoryID, true)
            scan.categoryCount = count or 0
            scan.achievementIndex = 1
        end

        if scan.achievementIndex > scan.categoryCount then
            scan.categoryIndex = scan.categoryIndex + 1
            scan.categoryCount = 0
            scan.achievementIndex = 1
        else
            local index = scan.achievementIndex
            scan.achievementIndex = scan.achievementIndex + 1
            processed = processed + 1

            local id, name, points, completed, month, day, year, description, flags, icon, rewardText, isGuild, wasEarnedByMe, earnedBy, isStatistic = GetAchievementInfo(categoryID, index)

            if id and not scan.seen[id] and not isGuild and not isStatistic then
                scan.seen[id] = true
                scan.total = scan.total + 1

                local earned, fieldSeen, fallbackUsed = self:EarnedByCurrentCharacter(completed, flags, wasEarnedByMe, earnedBy)
                if fieldSeen then
                    scan.wasEarnedFieldSeen = true
                end
                if fallbackUsed then
                    scan.fallbackUsed = true
                end

                if earned then
                    scan.achievements[id] = true
                    local dateKey = PackAchievementDate(month, day, year)
                    if dateKey then
                        scan.achievementDates[id] = dateKey
                    end
                    scan.earned = scan.earned + 1
                    scan.points = scan.points + (tonumber(points) or 0)
                end
            end
        end
    end

    if scan.categoryIndex > #scan.categories then
        self:FinishScan()
    end
end

function AA:FinishScan()
    local scan = self.scan
    if not scan then
        return
    end

    local char = self.db.characters[scan.charKey]
    if not char then
        self.scan = nil
        return
    end

    -- Replace old data only after a complete scan.
    char.achievements = scan.achievements
    char.achievementDates = scan.achievementDates
    char.dateScanComplete = true
    char.dateScanAt = time()
    char.scanned = true
    char.lastScan = time()
    char.lastSeen = time()
    char.totalScanned = scan.total
    char.earnedCount = scan.earned
    char.achievementPoints = scan.points or 0
    if type(GetTotalAchievementPoints) == "function" then
        local totalAP = tonumber(GetTotalAchievementPoints())
        if totalAP then
            char.totalAchievementPoints = totalAP
            char.totalAchievementPointsAt = time()
        end
    end
    char.apiFallbackUsed = scan.fallbackUsed and true or nil
    char.addonVersion = VERSION

    self.scan = nil
    self:InvalidateIndex()
    self:RefreshRealmDropDowns()
    if self.uniqueFrame and self.uniqueFrame:IsShown() then
        self:RefreshUniqueTab(false)
    end
    if self.missingFrame and self.missingFrame:IsShown() then
        self:RefreshMissingTab(false)
    end
    if self.dashboardFrame and self.dashboardFrame:IsShown() then
        self:RefreshDashboard(false)
    end

    Print(string.format("Scan complete for %s: %d earned achievements found (%d achievement IDs checked).", self:CharacterDisplayName(char), char.earnedCount or 0, char.totalScanned or 0))

    if char.apiFallbackUsed then
        Print("Warning: this core did not consistently expose wasEarnedByMe. Compatibility fallback was used; account-wide ownership may be less precise.")
    end
end

function AA:MarkAchievementEarned(achievementID)
    if not self:IsEnabled() then
        return
    end
    if not achievementID or not self.db then
        return
    end

    self:UpdateCurrentCharacterMetadata()
    local char = self.db.characters[self.currentCharacterKey]
    local _, _, _, _, month, day, year = GetAchievementInfo(achievementID)
    local dateKey = PackAchievementDate(month, day, year)

    if char then
        char.achievements = char.achievements or {}
        char.achievementDates = char.achievementDates or {}
        if not char.achievements[achievementID] then
            char.achievements[achievementID] = true
            char.earnedCount = (char.earnedCount or 0) + 1
            if char.achievementPoints ~= nil then
                local _, _, points = GetAchievementInfo(achievementID)
                char.achievementPoints = (tonumber(char.achievementPoints) or 0) + (tonumber(points) or 0)
            end
        end
        if dateKey then
            char.achievementDates[achievementID] = dateKey
        end
        if type(GetTotalAchievementPoints) == "function" then
            local totalAP = tonumber(GetTotalAchievementPoints())
            if totalAP then
                char.totalAchievementPoints = totalAP
                char.totalAchievementPointsAt = time()
            end
        end
        self:InvalidateIndex()
        if self.uniqueFrame and self.uniqueFrame:IsShown() then
            self:RefreshUniqueTab(false)
        end
        if self.missingFrame and self.missingFrame:IsShown() then
            self:RefreshMissingTab(false)
        end
    end

    if self.scan and self.scan.charKey == self.currentCharacterKey then
        if not self.scan.achievements[achievementID] then
            self.scan.achievements[achievementID] = true
        end
        if dateKey then
            self.scan.achievementDates[achievementID] = dateKey
        end
    end
end

function AA:AddAchievementStatusLines(tooltip, achievementID)
    if not self:IsEnabled() then
        return
    end
    if not tooltip or not achievementID then
        return
    end

    self:BuildOwnershipIndex()
    local chars = self:GetVisibleScannedCharactersSorted()
    local allChars = self:GetScannedCharactersSorted()
    local ownershipEntry = self.ownershipIndex and self.ownershipIndex[achievementID]
    local oldestEntry = self.oldestIndex and self.oldestIndex[achievementID]
    tooltip:AddLine(" ")
    tooltip:AddLine("Alternator - selected characters", 0.65, 0.34, 0.88)

    if #chars == 0 then
        if #allChars > 0 then
            tooltip:AddLine("No scanned characters are included by the active realm filter.", GREY[1], GREY[2], GREY[3], true)
            tooltip:AddLine("Choose one or more realms in the Unique tab or addon options.", GREY[1], GREY[2], GREY[3], true)
        else
            tooltip:AddLine("No characters have completed an Alternator scan yet.", GREY[1], GREY[2], GREY[3], true)
            tooltip:AddLine("Log each character once or use /alt scan.", GREY[1], GREY[2], GREY[3], true)
        end
        return
    end

    local earnedCount = 0

    for _, char in ipairs(chars) do
        local earned = char.achievements and char.achievements[achievementID]
        local display = self:CharacterDisplayName(char)
        if char.key == self.currentCharacterKey then
            display = display .. " (you)"
        end

        if earned then
            earnedCount = earnedCount + 1
            local dateKey = char.achievementDates and char.achievementDates[achievementID]
            local rightText = dateKey and FormatAchievementDate(dateKey) or "Earned"
            local rr, rg, rb = GREEN[1], GREEN[2], GREEN[3]

            if oldestEntry and TableContains(oldestEntry.owners, char.key) then
                rightText = rightText .. (oldestEntry.tie and "  OLDEST (tie)" or "  OLDEST")
                rr, rg, rb = GOLD[1], GOLD[2], GOLD[3]
            elseif not dateKey then
                rightText = "Earned - date not scanned"
                rr, rg, rb = GREY[1], GREY[2], GREY[3]
            end

            tooltip:AddDoubleLine(display, rightText, GREEN[1], GREEN[2], GREEN[3], rr, rg, rb)
        else
            tooltip:AddDoubleLine(display, "Missing", RED[1], RED[2], RED[3], RED[1], RED[2], RED[3])
        end
    end

    tooltip:AddLine(" ")
    tooltip:AddDoubleLine("Scanned characters", tostring(#chars), GREY[1], GREY[2], GREY[3], WHITE[1], WHITE[2], WHITE[3])
    tooltip:AddDoubleLine("Characters with achievement", string.format("%d / %d", earnedCount, #chars), GREY[1], GREY[2], GREY[3], WHITE[1], WHITE[2], WHITE[3])
    if not self:IsRealmFilterAll() then
        tooltip:AddDoubleLine("Realm scope", self:GetRealmFilterLabel(), GREY[1], GREY[2], GREY[3], WHITE[1], WHITE[2], WHITE[3])
    end

    local selectedHolderCount = ownershipEntry and ownershipEntry.count or 0
    if selectedHolderCount == 1 and ownershipEntry.ownerKey then
        local soleOwner = self:GetCharacterByKey(ownershipEntry.ownerKey)
        if soleOwner then
            tooltip:AddLine("Only " .. self:CharacterDisplayName(soleOwner) .. " has this achievement in the selected realm set.", GOLD[1], GOLD[2], GOLD[3], true)
        end
    elseif selectedHolderCount == 0 then
        tooltip:AddLine("No selected-realm character has this achievement.", GREY[1], GREY[2], GREY[3], true)
    elseif selectedHolderCount > 1 then
        if oldestEntry then
            local names = {}
            for _, charKey in ipairs(oldestEntry.owners) do
                local char = self:GetCharacterByKey(charKey)
                if char then
                    table.insert(names, self:CharacterDisplayName(char))
                end
            end
            local label = oldestEntry.tie and "Oldest completion (same-day tie)" or "Oldest completion"
            local value = table.concat(names, ", ") .. " - " .. FormatAchievementDate(oldestEntry.date)
            tooltip:AddDoubleLine(label, value, GREY[1], GREY[2], GREY[3], GOLD[1], GOLD[2], GOLD[3])
        else
            tooltip:AddLine("Oldest completion is not known yet for all selected-realm holders. Rescan those characters with Alternator v0.1.0+.", 0.70, 0.70, 0.70, true)
        end
    end

    if #chars < #allChars then
        tooltip:AddLine("Comparisons use selected realms only; unselected realms are ignored.", 0.50, 0.50, 0.50, true)
    else
        tooltip:AddLine("Based on all characters scanned by this addon.", 0.50, 0.50, 0.50, true)
    end
end

function AA:ShowAchievementTooltip(owner, achievementID)
    if not owner or not achievementID or not GameTooltip then
        return
    end

    local id, name = GetAchievementInfo(achievementID)
    if not id then
        return
    end

    GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
    GameTooltip:ClearLines()
    GameTooltip:AddLine(name or ("Achievement #" .. tostring(achievementID)), 1, 0.82, 0, true)
    self:AddAchievementStatusLines(GameTooltip, achievementID)
    GameTooltip.__AlternatorID = achievementID
    GameTooltip.__AlternatorOwnBase = true
    GameTooltip:Show()
end

function AA:AppendAchievementTooltip(tooltip, achievementID)
    if not tooltip or not achievementID then
        return
    end

    -- Do not ClearLines here. Another addon may already be using GameTooltip for
    -- the same achievement. Alternator deliberately appends its section.
    self:AddAchievementStatusLines(tooltip, achievementID)
    tooltip.__AlternatorID = achievementID
    tooltip.__AlternatorOwnBase = nil
    tooltip:Show()
end

function AA:QueueAchievementTooltip(owner, achievementID)
    if not self:IsEnabled() then
        return
    end
    if not owner or not achievementID then
        return
    end

    self.pendingTooltipOwner = owner
    self.pendingTooltipID = achievementID
    -- Defer until the next frame. This is important when another addon also has
    -- an OnEnter hook and creates/clears GameTooltip after our hook fires.
    self.pendingTooltipAt = GetTime() + 0.01
end

function AA:CancelQueuedAchievementTooltip(owner)
    if not owner or self.pendingTooltipOwner == owner then
        self.pendingTooltipOwner = nil
        self.pendingTooltipID = nil
        self.pendingTooltipAt = nil
    end
end

function AA:ProcessQueuedAchievementTooltip()
    if not self:IsEnabled() then
        self.pendingTooltipOwner = nil
        self.pendingTooltipID = nil
        self.pendingTooltipAt = nil
        return
    end
    if not self.pendingTooltipOwner or not self.pendingTooltipID then
        return
    end

    if self.pendingTooltipAt and GetTime() < self.pendingTooltipAt then
        return
    end

    local owner = self.pendingTooltipOwner
    local achievementID = self.pendingTooltipID
    self.pendingTooltipOwner = nil
    self.pendingTooltipID = nil
    self.pendingTooltipAt = nil

    if not owner.IsMouseOver or not owner:IsMouseOver() then
        return
    end

    -- Hybrid-scroll achievement buttons are recycled. Always read the current
    -- button id after the delay instead of trusting a stale id from before a scroll.
    if owner.id then
        achievementID = owner.id
    end

    local id = GetAchievementInfo(achievementID)
    if not id then
        return
    end

    if GameTooltip and GameTooltip:IsShown() then
        -- Coexist with tooltip addons (for example one showing "Earned by").
        -- Their OnEnter has already run, so append our block below theirs.
        self:AppendAchievementTooltip(GameTooltip, achievementID)
    else
        -- Vanilla 5.4.8 normally has no tooltip for the achievement row itself.
        -- If nobody else created one, create the normal GameTooltip ourselves.
        self:ShowAchievementTooltip(owner, achievementID)
    end
end

function AA:HookAchievementButton(button)
    if not button or button.__AlternatorHooked or not button.HookScript then
        return false
    end

    button.__AlternatorHooked = true
    self.hookedAchievementButtons = (self.hookedAchievementButtons or 0) + 1

    button:HookScript("OnEnter", function(self)
        if self.id then
            AA:QueueAchievementTooltip(self, self.id)
        end
    end)

    button:HookScript("OnLeave", function(self)
        AA:CancelQueuedAchievementTooltip(self)
        if GameTooltip and GameTooltip.__AlternatorOwnBase and GameTooltip:IsOwned(self) then
            GameTooltip:Hide()
        end
    end)

    -- The shield is a mouse-enabled child on some achievement templates. Queue
    -- the parent button too so hovering the points/date area cannot miss our hook.
    if button.shield and button.shield.HookScript and not button.shield.__AlternatorHooked then
        button.shield.__AlternatorHooked = true
        button.shield:HookScript("OnEnter", function(self)
            local parent = self:GetParent()
            if parent and parent.id then
                AA:QueueAchievementTooltip(parent, parent.id)
            end
        end)
    end

    return true
end

function AA:HookAchievementButtonTable(buttons)
    if type(buttons) ~= "table" then
        return 0
    end

    local hookedNow = 0
    for _, button in pairs(buttons) do
        if self:HookAchievementButton(button) then
            hookedNow = hookedNow + 1
        end
    end
    return hookedNow
end

function AA:HookVisibleAchievementButtons()
    local hookedNow = 0

    -- This is the authoritative button table used by Blizzard 5.4.8's
    -- HybridScrollFrame. The buttons are created once and then recycled while
    -- scrolling; their .id field is refreshed by AchievementButton_DisplayAchievement.
    if AchievementFrameAchievementsContainer then
        hookedNow = hookedNow + self:HookAchievementButtonTable(AchievementFrameAchievementsContainer.buttons)
    end

    -- Search results use another HybridScrollFrame but the result buttons also
    -- carry an achievement id, so support those when the frame exists.
    if AchievementFrame and AchievementFrame.searchResults and AchievementFrame.searchResults.scrollFrame then
        hookedNow = hookedNow + self:HookAchievementButtonTable(AchievementFrame.searchResults.scrollFrame.buttons)
    end

    return hookedNow
end

-- Kept as a compatibility entry point for older prototype calls. In 0.1.1 we
-- no longer try to identify achievement rows by child fields such as .label;
-- that was the reason 0.1.0 missed the real 5.4.8 AchievementTemplate buttons.
function AA:HookAchievementButtonsRecursive(frame, depth)
    return self:HookVisibleAchievementButtons()
end

function AA:ShowUniqueSummaryTooltip(owner)
    if not self:IsEnabled() then
        return
    end
    if not owner or not GameTooltip then
        return
    end

    self:BuildOwnershipIndex()
    local chars = self:GetVisibleScannedCharactersSorted()
    local allChars = self:GetScannedCharactersSorted()

    GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
    GameTooltip:ClearLines()
    GameTooltip:AddLine("Alternator - unique achievements", 0.65, 0.34, 0.88)
    GameTooltip:AddLine("Achievements owned by exactly one character in the selected realm set.", 0.90, 0.90, 0.90, true)
    GameTooltip:AddLine(" ")

    if #chars == 0 then
        if #allChars > 0 then
            GameTooltip:AddLine("No scanned characters are included by the active realm filter.", GREY[1], GREY[2], GREY[3])
            GameTooltip:AddLine("Choose one or more realms, or select All realms.", GREY[1], GREY[2], GREY[3], true)
        else
            GameTooltip:AddLine("No scanned characters yet.", GREY[1], GREY[2], GREY[3])
            GameTooltip:AddLine("Log each character once or use /alt scan.", GREY[1], GREY[2], GREY[3], true)
        end
        GameTooltip:Show()
        return
    end

    local totalUnique = 0
    for _, char in ipairs(chars) do
        local count = self.uniqueCounts[char.key] or 0
        totalUnique = totalUnique + count
        GameTooltip:AddDoubleLine(self:CharacterDisplayName(char), tostring(count), WHITE[1], WHITE[2], WHITE[3], GOLD[1], GOLD[2], GOLD[3])
    end

    GameTooltip:AddLine(" ")
    GameTooltip:AddDoubleLine("Total unique achievements", tostring(totalUnique), GREY[1], GREY[2], GREY[3], GOLD[1], GOLD[2], GOLD[3])
    GameTooltip:AddLine("Use /alt unique <character> to list them in chat.", 0.50, 0.50, 0.50, true)
    if not self:IsRealmFilterAll() then
        GameTooltip:AddLine(string.format("Realm comparison set: %d scanned characters.", #chars), 0.55, 0.55, 0.55, true)
        GameTooltip:AddLine("Selected realms: " .. self:GetRealmFilterLabel() .. ".", 0.55, 0.55, 0.55, true)
        GameTooltip:AddLine("Unselected realms are ignored by Unique/Oldest comparisons.", 0.55, 0.55, 0.55, true)
    else
        GameTooltip:AddLine("Based on all scanned characters.", 0.50, 0.50, 0.50, true)
    end
    GameTooltip:Show()
end


-- -----------------------------------------------------------------------------
-- Embedded "Unique" tab
-- -----------------------------------------------------------------------------
-- This panel is deliberately built inside Blizzard's AchievementFrame instead of
-- being a standalone addon window. It uses the same tab template used by the
-- Blizzard UI (and by Overachiever_Tabs), so it can coexist with extra Search /
-- Suggestions / Watch tabs without hard-coding a tab number.

local function UniqueClassColor(char)
    if char and RAID_CLASS_COLORS and char.class and RAID_CLASS_COLORS[char.class] then
        local c = RAID_CLASS_COLORS[char.class]
        return c.r or 1, c.g or 1, c.b or 1
    end
    return 1, 1, 1
end

function AA:BuildUniqueDisplayRows()
    self:BuildOwnershipIndex()

    local rows = {}
    local chars = self:GetVisibleScannedCharactersSorted()
    local mode = self:GetUniqueViewMode()
    local counts = mode == "oldest" and self.oldestCounts or self.uniqueCounts
    local lists = mode == "oldest" and self.oldestLists or self.uniqueLists

    for _, char in ipairs(chars) do
        local count = counts[char.key] or 0
        table.insert(rows, {
            kind = "character",
            charKey = char.key,
            char = char,
            count = count,
            pending = mode == "oldest" and (self.oldestPendingCounts[char.key] or 0) or 0,
            mode = mode,
        })

        if not self.uniqueCollapsed[char.key] then
            local list = lists[char.key] or {}
            for _, item in ipairs(list) do
                if mode == "oldest" then
                    table.insert(rows, {
                        kind = "achievement",
                        charKey = char.key,
                        char = char,
                        achievementID = item.id,
                        dateKey = item.date,
                        oldestTie = item.tie,
                        holderCount = item.holderCount,
                        mode = mode,
                    })
                else
                    table.insert(rows, {
                        kind = "achievement",
                        charKey = char.key,
                        char = char,
                        achievementID = item,
                        mode = mode,
                    })
                end
            end
        end
    end

    self.uniqueDisplayRows = rows
    return rows, chars
end

function AA:UpdateUniqueTabRows()
    local frame = self.uniqueFrame
    if not frame or not frame.rows or not frame.scrollFrame then
        return
    end

    local rows = self.uniqueDisplayRows or {}
    FauxScrollFrame_Update(frame.scrollFrame, #rows, UNIQUE_VISIBLE_ROWS, UNIQUE_ROW_HEIGHT)
    local offset = FauxScrollFrame_GetOffset(frame.scrollFrame) or 0

    for i = 1, UNIQUE_VISIBLE_ROWS do
        local row = frame.rows[i]
        local data = rows[offset + i]
        row.data = data

        if not data then
            row:Hide()
        else
            row:Show()
            row.icon:Hide()
            row.removeButton:Hide()
            row.mainText:ClearAllPoints()
            row.countText:ClearAllPoints()
            row.rightText:ClearAllPoints()

            -- Fixed columns keep character summaries aligned instead of pushing
            -- all numeric information against the far-right edge.
            row.mainText:SetPoint("LEFT", row, "LEFT", 8, 0)
            row.mainText:SetPoint("RIGHT", row, "RIGHT", -365, 0)
            row.countText:SetPoint("RIGHT", row, "RIGHT", -240, 0)
            row.countText:SetWidth(120)
            row.rightText:SetPoint("RIGHT", row, "RIGHT", -34, 0)
            row.rightText:SetWidth(200)

            row.countText:SetText("")
            row.rightText:SetText("")
            row.mainText:SetTextColor(1, 1, 1)
            row.countText:SetTextColor(0.82, 0.82, 0.82)
            row.rightText:SetTextColor(0.82, 0.82, 0.82)
            row.groupBG:Hide()

            if data.kind == "character" then
                local char = data.char
                local r, g, b = UniqueClassColor(char)
                local collapsed = self.uniqueCollapsed[data.charKey] and true or false
                local marker = collapsed and "[+] " or "[-] "
                local display = self:CharacterDisplayName(char)
                if char.key == self.currentCharacterKey then
                    display = display .. " (you)"
                end

                row.groupBG:Show()
                row.mainText:SetText(marker .. display)
                row.mainText:SetTextColor(r, g, b)

                -- Always reserve the delete-button column so all AP values line
                -- up, even on the currently logged-in character where X is hidden.
                if char.key ~= self.currentCharacterKey then
                    row.removeButton:Show()
                end

                local charAP = char.achievementPoints ~= nil and tostring(tonumber(char.achievementPoints) or 0) or "?"
                local totalAP = char.totalAchievementPoints ~= nil and tostring(tonumber(char.totalAchievementPoints) or 0) or "?"
                row.rightText:SetText(charAP .. " / " .. totalAP .. " AP")

                if data.mode == "oldest" then
                    if (data.pending or 0) > 0 then
                        row.countText:SetText(string.format("%d (+%d?)", data.count or 0, data.pending or 0))
                    else
                        row.countText:SetText(tostring(data.count or 0))
                    end
                else
                    row.countText:SetText(tostring(data.count or 0))
                end
                row.countText:SetTextColor(GOLD[1], GOLD[2], GOLD[3])
                row.rightText:SetTextColor(GOLD[1], GOLD[2], GOLD[3])
            else
                local achievementID = data.achievementID
                local id, name, points, completed, month, day, year, description, flags, icon = GetAchievementInfo(achievementID)

                row.icon:SetTexture(icon or "Interface\\Icons\\INV_Misc_QuestionMark")
                row.icon:Show()
                row.mainText:ClearAllPoints()
                row.mainText:SetPoint("LEFT", row.icon, "RIGHT", 7, 0)
                row.mainText:SetPoint("RIGHT", row, "RIGHT", -365, 0)
                row.mainText:SetText(name or ("Achievement #" .. tostring(achievementID)))
                row.mainText:SetTextColor(0.95, 0.95, 0.95)

                if data.mode == "oldest" then
                    local dateText = FormatAchievementDate(data.dateKey)
                    if data.oldestTie then
                        dateText = dateText .. " *"
                    end
                    row.countText:SetText(dateText)
                    row.rightText:SetText(tostring(points or 0) .. " pts")
                else
                    -- The Unique count only applies to the character summary row;
                    -- an expanded achievement shows its own points in the AP column.
                    row.rightText:SetText(tostring(points or 0) .. " pts")
                end
                row.countText:SetTextColor(1.00, 0.82, 0.00)
                row.rightText:SetTextColor(1.00, 0.82, 0.00)
            end
        end
    end

end

function AA:RefreshUniqueTab(resetScroll)
    local frame = self.uniqueFrame
    if not frame then
        return
    end

    self:BuildUniqueDisplayRows()
    local chars = self:GetVisibleScannedCharactersSorted()
    local allChars = self:GetScannedCharactersSorted()
    local mode = self:GetUniqueViewMode()

    if frame.modeButton then
        frame.modeButton:SetText(mode == "oldest" and "Show unique" or "Show oldest")
    end

    local status
    if mode == "oldest" then
        if frame.title then frame.title:SetText("Oldest Shared Achievements") end
        if frame.headerLeft then frame.headerLeft:SetText("Character / achievement") end
        if frame.headerCount then frame.headerCount:SetText("Oldest") end
        if frame.headerRight then frame.headerRight:SetText("Achievement points") end

        local dateReady = 0
        for _, char in ipairs(chars) do
            if char.dateScanComplete then
                dateReady = dateReady + 1
            end
        end
        local visibleOldest = 0
        for _, char in ipairs(chars) do
            visibleOldest = visibleOldest + (self.oldestCounts[char.key] or 0)
        end
        if not self:IsRealmFilterAll() then
            status = string.format("%d scanned characters compared in selected realms  -  %d oldest result(s)", #chars, visibleOldest)
        else
            status = string.format("%d characters  -  %d shared achievement(s) compared by date", #chars, self.oldestSharedKnownCount or 0)
        end
        if dateReady < #chars then
            status = status .. string.format("  -  date scans %d/%d compared", dateReady, #chars)
        elseif (self.oldestSharedUnknownCount or 0) > 0 then
            status = status .. string.format("  -  %d shared date(s) unavailable", self.oldestSharedUnknownCount or 0)
        end
    else
        if frame.title then frame.title:SetText("Unique Achievements") end
        if frame.headerLeft then frame.headerLeft:SetText("Character / achievement") end
        if frame.headerCount then frame.headerCount:SetText("Unique") end
        if frame.headerRight then frame.headerRight:SetText("Achievement points") end

        local totalUnique = 0
        for _, char in ipairs(chars) do
            totalUnique = totalUnique + (self.uniqueCounts[char.key] or 0)
        end
        if not self:IsRealmFilterAll() then
            status = string.format("%d scanned characters compared in selected realms  -  %d achievement(s) unique within selected realms", #chars, totalUnique)
        else
            status = string.format("%d scanned character(s)  -  %d achievement(s) unique to exactly one character", #chars, totalUnique)
        end
    end

    if self.scan then
        status = status .. "  -  scan in progress"
    end
    frame.summary:SetText(status)

    if #chars == 0 then
        if #allChars > 0 then
            frame.emptyText:SetText("No scanned characters are included by the active realm filter. Choose another realm or select All realms.")
        else
            frame.emptyText:SetText("No scanned characters yet. Log each character once or run /alt scan.")
        end
        frame.emptyText:Show()
    elseif mode == "oldest" and (self.oldestSharedKnownCount or 0) == 0 and (self.oldestSharedUnknownCount or 0) > 0 then
        frame.emptyText:SetText("Achievement dates have not been captured for all holders yet. Log/rescan each character once with Alternator v0.1.0+.")
        frame.emptyText:Show()
    else
        frame.emptyText:Hide()
    end

    if resetScroll and frame.scrollFrame then
        FauxScrollFrame_SetOffset(frame.scrollFrame, 0)
        if frame.scrollFrame.ScrollBar then
            frame.scrollFrame.ScrollBar:SetValue(0)
        elseif _G[frame.scrollFrame:GetName() .. "ScrollBar"] then
            _G[frame.scrollFrame:GetName() .. "ScrollBar"]:SetValue(0)
        end
    end

    self:UpdateUniqueTabRows()
end

function AA:SetAllUniqueGroupsCollapsed(collapsed)
    local chars = self:GetVisibleScannedCharactersSorted()
    for _, char in ipairs(chars) do
        self.uniqueCollapsed[char.key] = collapsed and true or nil
    end
    self:RefreshUniqueTab(true)
end

function AA:ShowUniqueRowTooltip(row)
    if not self:IsEnabled() then
        return
    end
    local data = row and row.data
    if not data or not GameTooltip then
        return
    end

    if data.kind == "character" and data.char then
        GameTooltip:SetOwner(row, "ANCHOR_RIGHT")
        GameTooltip:ClearLines()
        local display = self:CharacterDisplayName(data.char)
        GameTooltip:AddLine(display, UniqueClassColor(data.char))
        self:BuildOwnershipIndex()
        GameTooltip:AddDoubleLine("Unique achievements", tostring(self.uniqueCounts[data.char.key] or 0), GREY[1], GREY[2], GREY[3], GOLD[1], GOLD[2], GOLD[3])
        GameTooltip:AddDoubleLine("Character achievement points", data.char.achievementPoints ~= nil and tostring(data.char.achievementPoints) or "rescan needed", GREY[1], GREY[2], GREY[3], GOLD[1], GOLD[2], GOLD[3])
        GameTooltip:AddDoubleLine("Account AP at last login", data.char.totalAchievementPoints ~= nil and tostring(data.char.totalAchievementPoints) or "rescan needed", GREY[1], GREY[2], GREY[3], GOLD[1], GOLD[2], GOLD[3])
        GameTooltip:AddDoubleLine("Oldest shared completions", tostring(self.oldestCounts[data.char.key] or 0), GREY[1], GREY[2], GREY[3], GOLD[1], GOLD[2], GOLD[3])
        local pendingOldest = self.oldestPendingCounts[data.char.key] or 0
        if pendingOldest > 0 then
            GameTooltip:AddDoubleLine("Oldest comparisons pending", tostring(pendingOldest), GREY[1], GREY[2], GREY[3], GREY[1], GREY[2], GREY[3])
        end
        GameTooltip:AddDoubleLine("Achievement date data", data.char.dateScanComplete and "captured" or "rescan needed", GREY[1], GREY[2], GREY[3], data.char.dateScanComplete and GREEN[1] or GREY[1], data.char.dateScanComplete and GREEN[2] or GREY[2], data.char.dateScanComplete and GREEN[3] or GREY[3])
        GameTooltip:AddDoubleLine("Last online", FormatTimestamp(data.char.lastSeen or data.char.lastScan), GREY[1], GREY[2], GREY[3], WHITE[1], WHITE[2], WHITE[3])
        GameTooltip:AddDoubleLine("Last achievement scan", FormatTimestamp(data.char.lastScan), GREY[1], GREY[2], GREY[3], WHITE[1], WHITE[2], WHITE[3])
        GameTooltip:AddLine("Last online is the last time Alternator saw this character online.", 0.55, 0.55, 0.55, true)
        if data.char.key ~= self.currentCharacterKey then
            GameTooltip:AddLine("Use the X on the right to remove this stored character.", 0.85, 0.35, 0.35, true)
        end
        GameTooltip:Show()
        return
    end

    if data.kind ~= "achievement" or not data.achievementID then
        return
    end

    local link = GetAchievementLink and GetAchievementLink(data.achievementID)
    GameTooltip:SetOwner(row, "ANCHOR_RIGHT")
    GameTooltip:ClearLines()

    if link and GameTooltip.SetHyperlink then
        GameTooltip:SetHyperlink(link)
        self:AddAchievementStatusLines(GameTooltip, data.achievementID)
        GameTooltip:Show()
    else
        self:ShowAchievementTooltip(row, data.achievementID)
    end
end

function AA:OpenAchievementFromUniqueTab(achievementID)
    if not achievementID or not AchievementFrame then
        return
    end

    -- Force the normal personal achievement view before selecting the entry.
    if IN_GUILD_VIEW and type(AchievementFrame_ToggleView) == "function" then
        AchievementFrame_ToggleView()
    end

    if type(AchievementFrameBaseTab_OnClick) == "function" then
        AchievementFrameBaseTab_OnClick(1)
    elseif type(AchievementFrameTab_OnClick) == "function" then
        AchievementFrameTab_OnClick(1)
    end

    if type(AchievementFrame_SelectAchievement) == "function" then
        AchievementFrame_SelectAchievement(achievementID, true)
    end
end

function AA:OnUniqueRowClick(row)
    local data = row and row.data
    if not data then
        return
    end

    if data.kind == "character" then
        if self.uniqueCollapsed[data.charKey] then
            self.uniqueCollapsed[data.charKey] = nil
        else
            self.uniqueCollapsed[data.charKey] = true
        end
        self:RefreshUniqueTab(false)
        return
    end

    if data.kind == "achievement" and data.achievementID then
        local link = GetAchievementLink and GetAchievementLink(data.achievementID)
        if IsModifiedClick and IsModifiedClick("CHATLINK") and ChatEdit_GetActiveWindow and ChatEdit_GetActiveWindow() then
            if link and ChatEdit_InsertLink then
                ChatEdit_InsertLink(link)
            end
            return
        end

        self:OpenAchievementFromUniqueTab(data.achievementID)
    end
end

function AA:UpdateAchievementTabTextOffsets(selectedID)
    for i = 1, 99 do
        local tab = _G["AchievementFrameTab" .. i]
        if not tab then
            break
        end
        local text = tab.text or tab.Text
        if text and text.SetPoint then
            if i == selectedID then
                text:SetPoint("CENTER", 0, -5)
            else
                text:SetPoint("CENTER", 0, -3)
            end
        end
    end
end

function AA:ShowUniqueTab()
    if not self:IsEnabled() then
        Print("Alternator is disabled. Enable it in Interface > AddOns > Alternator.")
        return
    end

    local frame = self.uniqueFrame
    local tab = self.uniqueTab
    if not frame or not tab or not AchievementFrame then
        return
    end

    -- Default view: every character group starts collapsed each time the Unique
    -- tab is opened. Users can expand individual groups or use Expand while the
    -- panel remains open.
    local chars = self:GetVisibleScannedCharactersSorted()
    for _, char in ipairs(chars) do
        self.uniqueCollapsed[char.key] = true
    end

    if IN_GUILD_VIEW and type(AchievementFrame_ToggleView) == "function" then
        AchievementFrame_ToggleView()
    end

    if AchievementFrame.searchResults then
        AchievementFrame.searchResults:Hide()
    end
    if type(AchievementFrame_HideSearchPreview) == "function" then
        AchievementFrame_HideSearchPreview()
    end

    if PanelTemplates_Tab_OnClick then
        PanelTemplates_Tab_OnClick(tab, AchievementFrame)
    end
    self:UpdateAchievementTabTextOffsets(tab:GetID())

    if type(AchievementFrame_ShowSubFrame) == "function" then
        AchievementFrame_ShowSubFrame(frame)
    else
        frame:Show()
    end

    if AchievementFrameCategories then
        AchievementFrameCategories:Hide()
    end
    if AchievementFrameFilterDropDown then
        AchievementFrameFilterDropDown:Hide()
    end
    if AchievementFrameHeaderLeftDDLInset then
        AchievementFrameHeaderLeftDDLInset:Hide()
    end
    if AchievementFrameHeaderRightDDLInset then
        AchievementFrameHeaderRightDDLInset:Hide()
    end
    if AchievementFrameGuildEmblemLeft then
        AchievementFrameGuildEmblemLeft:Hide()
    end
    if AchievementFrameGuildEmblemRight then
        AchievementFrameGuildEmblemRight:Hide()
    end

    self:RefreshUniqueTab(true)
end


local function RecipeBookKey(name)
    return Lower(Trim(name or ""))
end

local function IsKnownProfessionCooldownRecipe(name)
    return KNOWN_PROFESSION_COOLDOWN_RECIPES[RecipeBookKey(name)] and true or false
end

local function FormatCooldownRemaining(seconds)
    seconds = math.max(0, math.floor(tonumber(seconds) or 0))
    if seconds <= 0 then return "Ready" end
    local days = math.floor(seconds / 86400)
    seconds = seconds % 86400
    local hours = math.floor(seconds / 3600)
    local minutes = math.floor((seconds % 3600) / 60)
    if days > 0 then return string.format("%dd %dh", days, hours) end
    if hours > 0 then return string.format("%dh %dm", hours, minutes) end
    if minutes > 0 then return string.format("%dm", minutes) end
    return "<1m"
end

function AA:GetProfessionCooldownEntries(char, professionName)
    local results = {}
    if not char or type(char.recipeBooks) ~= "table" then return results end
    local wanted = professionName and RecipeBookKey(professionName) or nil
    local now = time()
    for bookKey, book in pairs(char.recipeBooks) do
        if type(book) == "table" and (not wanted or bookKey == wanted or RecipeBookKey(book.name) == wanted) then
            for _, recipe in pairs(type(book.recipes) == "table" and book.recipes or {}) do
                if type(recipe) == "table" and recipe.cooldownTracked then
                    local readyAt = tonumber(recipe.cooldownReadyAt) or 0
                    local remaining = readyAt > 0 and math.max(0, readyAt - now) or 0
                    table.insert(results, {
                        profession = book.name or professionName or "Profession",
                        name = recipe.name or "Cooldown recipe",
                        icon = recipe.icon,
                        recipeID = recipe.recipeID,
                        remaining = remaining,
                        readyAt = readyAt,
                        ready = remaining <= 0,
                        scannedAt = recipe.cooldownScannedAt or recipe.lastSeen or book.lastScan,
                    })
                end
            end
        end
    end
    table.sort(results, function(a, b)
        if a.ready ~= b.ready then return a.ready end
        if a.remaining ~= b.remaining then return a.remaining < b.remaining end
        return Lower(a.name or "") < Lower(b.name or "")
    end)
    return results
end

local function ParseRecipeSpellID(link)
    if not link then
        return nil
    end
    local id = string.match(link, "enchant:(%d+)") or string.match(link, "spell:(%d+)")
    return tonumber(id)
end

function AA:ScanOpenTradeSkillRecipes(quiet)
    if not self.db or not self:IsEnabled() or type(GetTradeSkillLine) ~= "function" or type(GetNumTradeSkills) ~= "function" or type(GetTradeSkillInfo) ~= "function" then
        return false
    end

    local professionName, currentLevel, maxLevel = GetTradeSkillLine()
    if not professionName or professionName == "" or professionName == "UNKNOWN" then
        return false
    end

    -- The 5.4.8 TradeSkill list can take a few frames to populate after the
    -- profession window opens.  Do not mark a snapshot as refreshed until at
    -- least one real recipe row is exposed; the retry queue will try again.
    if type(IsTradeSkillLinked) == "function" and IsTradeSkillLinked() then
        return false
    end

    local count = tonumber(GetNumTradeSkills()) or 0
    if count <= 0 then
        return false
    end

    self:UpdateCurrentCharacterMetadata()
    local char = self.db.characters[self.currentCharacterKey]
    if not char then
        return false
    end

    char.recipeBooks = type(char.recipeBooks) == "table" and char.recipeBooks or {}
    local key = RecipeBookKey(professionName)
    if key == "" then
        return false
    end

    local pendingEntries = {}
    local seenNow = 0
    for i = 1, count do
        local recipeName, skillType = GetTradeSkillInfo(i)
        if recipeName and skillType ~= "header" and skillType ~= "subheader" then
            local recipeLink = type(GetTradeSkillRecipeLink) == "function" and GetTradeSkillRecipeLink(i) or nil
            local itemLink = type(GetTradeSkillItemLink) == "function" and GetTradeSkillItemLink(i) or nil
            local icon = type(GetTradeSkillIcon) == "function" and GetTradeSkillIcon(i) or nil
            local recipeID = ParseRecipeSpellID(recipeLink)
            local recipeKey = recipeID and ("id:" .. tostring(recipeID)) or ("name:" .. Lower(recipeName))
            local cooldownSeconds = nil
            if type(GetTradeSkillCooldown) == "function" then
                local okCooldown, value = pcall(GetTradeSkillCooldown, i)
                if okCooldown and value ~= nil then cooldownSeconds = tonumber(value) or 0 end
            end
            pendingEntries[recipeKey] = {
                name = recipeName,
                recipeID = recipeID,
                recipeLink = recipeLink,
                itemLink = itemLink,
                icon = icon,
                skillType = skillType,
                cooldownSeconds = cooldownSeconds,
                knownCooldown = IsKnownProfessionCooldownRecipe(recipeName),
            }
            seenNow = seenNow + 1
        end
    end

    if seenNow <= 0 then
        return false
    end

    -- Merge with the existing book. This intentionally does not delete recipes:
    -- the client may currently have a filter active or a category collapsed.
    local book = char.recipeBooks[key]
    if type(book) ~= "table" then
        book = { name = professionName, recipes = {} }
    end
    book.name = professionName
    book.tradeLink = type(GetTradeSkillListLink) == "function" and (GetTradeSkillListLink() or book.tradeLink) or book.tradeLink
    book.skill = tonumber(currentLevel) or book.skill or 0
    book.max = tonumber(maxLevel) or book.max or 0
    book.recipes = type(book.recipes) == "table" and book.recipes or {}

    for recipeKey, data in pairs(pendingEntries) do
        local existing = book.recipes[recipeKey] or {}
        existing.name = data.name or existing.name
        existing.recipeID = data.recipeID or existing.recipeID
        existing.recipeLink = data.recipeLink or existing.recipeLink
        existing.itemLink = data.itemLink or existing.itemLink
        existing.icon = data.icon or existing.icon
        existing.skillType = data.skillType or existing.skillType
        existing.lastSeen = time()

        -- Keep cooldown-capable recipes even when currently ready. The 5.4.8
        -- API reports the remaining seconds only while the profession is open.
        if data.knownCooldown or existing.cooldownTracked or (data.cooldownSeconds and data.cooldownSeconds > 0) then
            existing.cooldownTracked = true
            if data.cooldownSeconds ~= nil then
                existing.cooldownRemaining = math.max(0, tonumber(data.cooldownSeconds) or 0)
                existing.cooldownReadyAt = time() + existing.cooldownRemaining
                existing.cooldownScannedAt = time()
            elseif data.knownCooldown and not existing.cooldownReadyAt then
                -- Known daily recipe with no active cooldown means it is ready.
                existing.cooldownRemaining = 0
                existing.cooldownReadyAt = time()
                existing.cooldownScannedAt = time()
            end
        end

        book.recipes[recipeKey] = existing
    end

    book.lastScan = time()
    book.lastVisibleCount = seenNow
    char.recipeBooks[key] = book
    char.recipeScanAt = time()

    if self.recipeGuideFrame and self.recipeGuideFrame.pendingProfession and Lower(self.recipeGuideFrame.pendingProfession) == Lower(professionName) then
        self.recipeGuideFrame.pendingProfession = nil
    end
    if not self.recipeScanInSecurePreClick then
        if self.recipeFrame and self.recipeFrame:IsShown() then
            self:RefreshRecipeFrame()
        end
        if self.recipeGuideFrame and self.recipeGuideFrame:IsShown() then
            self:RefreshRecipeGuide()
        end
        if self.dashboardFrame and self.dashboardFrame:IsShown() then
            self:RefreshDashboard(false)
        end
    end

    if not quiet then
        Print(string.format("Stored %d visible recipe(s) from %s for %s. Recipe snapshots are merged, so reopening the profession can only add/update recipes.", seenNow, professionName, self:CharacterDisplayName(char)))
    end
    return true, professionName, seenNow
end

function AA:QueueRecipeCapture(attempts, initialDelay, professionName)
    self.recipeScanRetryCount = math.max(tonumber(self.recipeScanRetryCount) or 0, tonumber(attempts) or 4)
    self.recipeScanRetryProfession = professionName or self.recipeScanRetryProfession
    local delay = tonumber(initialDelay) or 0.15
    local target = GetTime() + delay
    if not self.recipeScanAt or target < self.recipeScanAt then
        self.recipeScanAt = target
    end
end

function AA:RescanOpenRecipeProfession()
    if type(GetTradeSkillLine) ~= "function" then return false end
    local professionName = GetTradeSkillLine()
    if not professionName or professionName == "" or professionName == "UNKNOWN" then
        if self.recipeGuideFrame and self.recipeGuideFrame.statusText then
            self.recipeGuideFrame.statusText:SetText("Open one of the professions above first, then use Rescan open to reread its recipe list.")
            self.recipeGuideFrame.statusText:SetTextColor(1.0, 0.62, 0.18)
        end
        return false
    end

    local ok = self:ScanOpenTradeSkillRecipes(true)
    self:QueueRecipeCapture(7, 0.12, professionName)
    if self.recipeGuideFrame and self.recipeGuideFrame.statusText then
        self.recipeGuideFrame.statusText:SetText("Rescanning " .. professionName .. "... several delayed passes are queued so the 5.4.8 TradeSkill list has time to finish loading.")
        self.recipeGuideFrame.statusText:SetTextColor(0.72, 0.82, 1.0)
    end
    return ok and true or false
end

function AA:GetRecipeBook(char, professionName)
    if not char or type(char.recipeBooks) ~= "table" then
        return nil
    end
    return char.recipeBooks[RecipeBookKey(professionName)]
end

local function SortedRecipeEntries(book)
    local result = {}
    if book and type(book.recipes) == "table" then
        for _, recipe in pairs(book.recipes) do
            table.insert(result, recipe)
        end
    end
    table.sort(result, function(a, b)
        return Lower(a.name) < Lower(b.name)
    end)
    return result
end

function AA:BuildRecipeResultsForProfession(charKey, professionName)
    local result = {}
    local char = self:GetCharacterByKey(charKey)
    local book = self:GetRecipeBook(char, professionName)
    for _, recipe in ipairs(SortedRecipeEntries(book)) do
        table.insert(result, {
            char = char,
            profession = book and book.name or professionName,
            recipe = recipe,
        })
    end
    self.recipeContext = { mode = "profession", charKey = charKey, professionName = professionName }
    self.recipeResults = result
    return result, char, book
end

function AA:BuildRecipeSearchResults(query)
    query = Lower(Trim(query))
    local result = {}
    if query == "" then
        self.recipeContext = { mode = "search", query = "" }
        self.recipeResults = result
        return result
    end

    for _, char in ipairs(self:GetDashboardCharactersSorted()) do
        if type(char.recipeBooks) == "table" then
            for _, book in pairs(char.recipeBooks) do
                for _, recipe in ipairs(SortedRecipeEntries(book)) do
                    local haystack = Lower((recipe.name or "") .. " " .. (recipe.itemLink or "") .. " " .. (recipe.recipeLink or ""))
                    if string.find(haystack, query, 1, true) then
                        table.insert(result, { char = char, profession = book.name or "Profession", recipe = recipe })
                    end
                end
            end
        end
    end

    table.sort(result, function(a, b)
        local an, bn = Lower(a.recipe and a.recipe.name), Lower(b.recipe and b.recipe.name)
        if an ~= bn then return an < bn end
        local ac = a.char and Lower(a.char.name) or ""
        local bc = b.char and Lower(b.char.name) or ""
        return ac < bc
    end)
    self.recipeContext = { mode = "search", query = query }
    self.recipeResults = result
    return result
end


local function RecipeCount(book)
    local count = 0
    if book and type(book.recipes) == "table" then
        for _ in pairs(book.recipes) do count = count + 1 end
    end
    return count
end

local function IsRecipeProfession(prof)
    if not prof then return false end
    local skillLine = tonumber(prof.skillLine)
    if skillLine and RECIPE_PROFESSION_SKILL_LINES[skillLine] then return true end
    return RECIPE_PROFESSION_NAMES[Lower(Trim(prof.name or ""))] and true or false
end

function AA:FindCurrentProfessionInfo(prof)
    if not prof or type(GetProfessions) ~= "function" or type(GetProfessionInfo) ~= "function" then
        return nil
    end
    local wantedSkillLine = tonumber(prof.skillLine)
    local wantedName = Lower(Trim(prof.name or ""))
    local indices = { GetProfessions() }
    for _, index in ipairs(indices) do
        if index then
            local name, icon, skillLevel, maxSkillLevel, numAbilities, spellOffset, skillLine, skillModifier = GetProfessionInfo(index)
            if name and ((wantedSkillLine and tonumber(skillLine) == wantedSkillLine) or Lower(Trim(name)) == wantedName) then
                return {
                    index = index,
                    name = name,
                    icon = icon,
                    skill = tonumber(skillLevel) or 0,
                    max = tonumber(maxSkillLevel) or 0,
                    numAbilities = tonumber(numAbilities) or 0,
                    spellOffset = tonumber(spellOffset),
                    skillLine = tonumber(skillLine),
                    modifier = tonumber(skillModifier) or 0,
                }
            end
        end
    end
    return nil
end

local function ProfessionHasNativeWindow(prof)
    if not prof then return false end
    local skillLine = tonumber(prof.skillLine)
    -- Herbalism, Skinning and Fishing do not have a browseable profession panel.
    -- Mining/Smelting, Archaeology, Cooking, First Aid and crafting professions do.
    if skillLine == 182 or skillLine == 393 or skillLine == 356 then
        return false
    end
    return true
end

function AA:OpenStoredProfessionForCharacter(charKey, prof)
    if not prof then return false end
    local professionName = Trim(prof.name or "")
    if professionName == "" then
        professionName = PROFESSION_NAMES_BY_SKILLLINE[tonumber(prof.skillLine)] or Trim(prof.short or "")
    end
    if not professionName or professionName == "" then return false end

    -- Backfill the name into old snapshots so the next redraw is complete too.
    if not prof.name or prof.name == "" then prof.name = professionName end

    if IsRecipeProfession(prof) then
        self:OpenProfessionSnapshot(charKey, professionName)
        return true
    end

    local char = self:GetCharacterByKey(charKey)
    if self:ToggleProfessionRecipeWindow("professionInfo", charKey, professionName) then return true end
    self.recipeResults = {}
    self.recipeContext = {
        mode = "professionInfo",
        charKey = charKey,
        professionName = professionName,
        skill = tonumber(prof.skill) or 0,
        max = tonumber(prof.max) or 0,
    }
    local frame = self:CreateRecipeFrame()
    frame:Show()
    self:RefreshRecipeFrame()
    return true
end

local function IsArchaeologyProfession(prof)
    if not prof then return false end
    return tonumber(prof.skillLine) == 794 or Lower(Trim(prof.name or "")) == "archaeology"
end

function AA:GetSecureProfessionSpellName(prof)
    if not prof then return nil end
    local live = self:FindCurrentProfessionInfo(prof)
    local skillLine = tonumber((live and live.skillLine) or prof.skillLine)

    -- The user-visible profession name is intentionally the primary opener: on
    -- the target 5.4.8 client typing /cast Engineering, /cast Tailoring, etc.
    -- reliably opens the Blizzard profession UI. Mining is the one common case
    -- where the actual opener is named Smelting.
    if skillLine == 186 then
        return "Smelting"
    end

    local name = Trim((live and live.name) or prof.name or "")
    if name ~= "" then return name end
    return PROFESSION_NAMES_BY_SKILLLINE[skillLine]
end

function AA:ConfigureSecureProfessionButton(button, prof)
    if not button or not prof then return false end
    if type(InCombatLockdown) == "function" and InCombatLockdown() then
        return false
    end

    -- Use the actual spellbook opener when available (for example Smelting for
    -- Mining), otherwise fall back to the profession name itself. On the target
    -- 5.4.8 client this is deliberately executed as the exact equivalent of a
    -- player typing /cast <profession> in chat.
    local professionName = self:GetSecureProfessionSpellName(prof) or prof.name
    if not professionName or professionName == "" then return false end

    local macroText = "/cast " .. professionName
    button:EnableMouse(true)
    -- Register both phases. SecureActionButtonTemplate itself executes only on
    -- the phase selected by ActionButtonUseKeyDown, so this avoids the silent
    -- no-op seen when a client is configured for key-down actions.
    button:RegisterForClicks("AnyDown", "AnyUp")
    button:SetAttribute("spell", nil)
    button:SetAttribute("type", "macro")
    button:SetAttribute("macrotext", macroText)
    button:SetAttribute("type1", "macro")
    button:SetAttribute("macrotext1", macroText)
    button.professionName = prof.name or professionName
    button.professionSpellName = professionName
    return true
end

function AA:ClearSecureProfessionButton(button)
    if not button then return end
    if type(InCombatLockdown) == "function" and InCombatLockdown() then return end
    button:SetAttribute("type", nil)
    button:SetAttribute("type1", nil)
    button:SetAttribute("spell", nil)
    button:SetAttribute("macrotext", nil)
    button:SetAttribute("macrotext1", nil)
    button.professionName = nil
    button.professionSpellName = nil
end

function AA:OpenNativeProfessionForCharacter(charKey, prof)
    if not prof or not prof.name then return false end

    if charKey ~= self.currentCharacterKey then
        return self:OpenStoredProfessionForCharacter(charKey, prof)
    end

    if not ProfessionHasNativeWindow(prof) then
        Print((prof.name or "This profession") .. " does not have a browseable profession window in MoP 5.4.8.")
        return false
    end

    -- Archaeology is not a trade-skill spell action; it owns a dedicated Blizzard
    -- frame, so it can be opened directly without a protected spell cast.
    if IsArchaeologyProfession(prof) then
        if type(IsAddOnLoaded) == "function" and type(LoadAddOn) == "function" and not IsAddOnLoaded("Blizzard_ArchaeologyUI") then
            pcall(LoadAddOn, "Blizzard_ArchaeologyUI")
        end
        if type(ArchaeologyFrame_Show) == "function" then
            ArchaeologyFrame_Show()
            return true
        elseif ArchaeologyFrame then
            if type(ShowUIPanel) == "function" then ShowUIPanel(ArchaeologyFrame) else ArchaeologyFrame:Show() end
            return true
        end
        Print("Could not open Archaeology UI on this client.")
        return false
    end

    -- Crafting/trade-skill windows are opened by the SecureActionButtonTemplate
    -- overlay attached to the visible profession row.  The secure button runs
    -- the equivalent of a player /cast profession macro on the hardware click.
    return false
end

function AA:GetCurrentRecipeProfessions()
    local result = {}
    if not self.db or not self.currentCharacterKey then return result end
    local char = self.db.characters and self.db.characters[self.currentCharacterKey]
    local profs = char and char.professions or nil
    if type(profs) ~= "table" then return result end
    local candidates = { profs.primary1, profs.primary2, profs.cooking, profs.firstAid }
    local seen = {}
    for _, prof in ipairs(candidates) do
        if IsRecipeProfession(prof) then
            local key = RecipeBookKey(prof.name)
            if key ~= "" and not seen[key] then
                seen[key] = true
                table.insert(result, prof)
            end
        end
    end
    table.sort(result, function(a, b) return Lower(a.name or "") < Lower(b.name or "") end)
    return result
end

function AA:OpenProfessionForRecipeScan(professionName)
    professionName = Trim(professionName or "")
    if professionName == "" then return false end

    local live = self:FindCurrentProfessionInfo({ name = professionName })
    local opened = false
    if live and live.spellOffset and type(CastSpell) == "function" then
        local ok = pcall(CastSpell, live.spellOffset + 1, BOOKTYPE_SPELL or "spell")
        opened = ok and true or false
    end
    if not opened and type(CastSpellByName) == "function" then
        local ok = pcall(CastSpellByName, live and live.name or professionName)
        opened = ok and true or false
    end

    if opened then
        if self.recipeGuideFrame and self.recipeGuideFrame.statusText then
            self.recipeGuideFrame.pendingProfession = professionName
            self.recipeGuideFrame.statusText:SetText("Opening " .. professionName .. "... recipes will be captured when the TradeSkill list loads.")
            self.recipeGuideFrame.statusText:SetTextColor(0.72, 0.82, 1.0)
        end
        return true
    end

    Print("Could not open " .. professionName .. " automatically. Open it manually once and Alternator will still capture it.")
    return false
end

function AA:OpenNextMissingRecipeProfession()
    local char = self.db and self.db.characters and self.db.characters[self.currentCharacterKey]
    if not char then return end
    for _, prof in ipairs(self:GetCurrentRecipeProfessions()) do
        local book = self:GetRecipeBook(char, prof.name)
        if not (book and book.lastScan) then
            self:OpenProfessionForRecipeScan(prof.name)
            return
        end
    end
    Print("All recipe-capable professions on this character have been scanned at least once.")
    if self.recipeGuideFrame then self:RefreshRecipeGuide() end
end

function AA:CreateRecipeGuideFrame()
    if self.recipeGuideFrame then return self.recipeGuideFrame end
    local frame = CreateFrame("Frame", "AlternatorRecipeGuideFrame", UIParent)
    frame:SetSize(455, 285)
    frame:SetPoint("CENTER", UIParent, "CENTER", 70, 50)
    frame:SetFrameStrata("FULLSCREEN_DIALOG")
    frame:SetFrameLevel(100)
    if frame.SetToplevel then frame:SetToplevel(true) end
    frame:SetClampedToScreen(true)
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", function(self) self:StartMoving() end)
    frame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
    frame:SetScript("OnMouseDown", function(self) if self.Raise then self:Raise() end end)
    -- Same visual skin as the main Alternator Character Overview window.
    frame:SetBackdrop({
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true,
        tileSize = 32,
        edgeSize = 32,
        insets = { left = 11, right = 12, top = 12, bottom = 11 },
    })
    local solidBG = frame:CreateTexture(nil, "BACKGROUND")
    solidBG:SetPoint("TOPLEFT", frame, "TOPLEFT", 11, -12)
    solidBG:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -12, 11)
    solidBG:SetTexture(0.025, 0.025, 0.025, 1)
    frame.solidBG = solidBG

    local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOPLEFT", frame, "TOPLEFT", 15, -14)
    title:SetText("Alternator - Recipe Scan")
    local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -3, -3)
    local subtitle = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    subtitle:SetPoint("TOPLEFT", frame, "TOPLEFT", 15, -38)
    subtitle:SetWidth(420); subtitle:SetJustifyH("LEFT"); frame.subtitle = subtitle

    local header = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    header:SetPoint("TOPLEFT", frame, "TOPLEFT", 20, -73); header:SetText("Profession")
    local headerStatus = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    headerStatus:SetPoint("TOPLEFT", frame, "TOPLEFT", 175, -73); headerStatus:SetText("Stored snapshot")

    frame.rows = {}
    for i = 1, 4 do
        local row = CreateFrame("Frame", nil, frame)
        row:SetSize(420, 31); row:SetPoint("TOPLEFT", frame, "TOPLEFT", 15, -88 - ((i - 1) * 32))
        local bg = row:CreateTexture(nil, "BACKGROUND"); bg:SetAllPoints(row); bg:SetTexture(0.10, 0.10, 0.10, (i % 2 == 0) and 0.75 or 0.55)
        local name = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        name:SetPoint("LEFT", row, "LEFT", 8, 0); name:SetWidth(145); name:SetJustifyH("LEFT"); row.nameText = name
        local status = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        status:SetPoint("LEFT", row, "LEFT", 160, 0); status:SetWidth(160); status:SetJustifyH("LEFT"); row.statusText = status
        local open = CreateFrame("Button", nil, row, "UIPanelButtonTemplate,SecureActionButtonTemplate")
        open:SetSize(82, 22); open:SetPoint("RIGHT", row, "RIGHT", -3, 0); row.openButton = open
        open:RegisterForClicks("LeftButtonUp")
        open:HookScript("PreClick", function(self)
            if self.rescanOnly then return end
            -- If another profession is currently open, capture it before the
            -- protected /cast action changes the Blizzard TradeSkill window.
            AA.recipeScanInSecurePreClick = true
            AA:ScanOpenTradeSkillRecipes(true)
            AA.recipeScanInSecurePreClick = false
        end)
        open:HookScript("OnClick", function(self)
            local parent = self:GetParent()
            if self.rescanOnly then
                AA:RescanOpenRecipeProfession()
                return
            end
            if parent and parent.professionName then
                AA:QueueRecipeCapture(7, 0.12, parent.professionName)
                if AA.recipeGuideFrame and AA.recipeGuideFrame.statusText then
                    AA.recipeGuideFrame.pendingProfession = parent.professionName
                    AA.recipeGuideFrame.statusText:SetText("Opening " .. parent.professionName .. "... Alternator will retry the capture several times while the TradeSkill list loads.")
                    AA.recipeGuideFrame.statusText:SetTextColor(0.72, 0.82, 1.0)
                end
            end
        end)
        frame.rows[i] = row
    end

    local statusText = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    statusText:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 15, 47); statusText:SetWidth(420); statusText:SetJustifyH("LEFT")
    statusText:SetTextColor(0.72, 0.72, 0.72); frame.statusText = statusText
    local nextButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate,SecureActionButtonTemplate")
    nextButton:SetSize(130, 23); nextButton:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 15, 14); nextButton:SetText("Open next missing")
    nextButton:RegisterForClicks("LeftButtonUp")
    nextButton:HookScript("PreClick", function()
        AA.recipeScanInSecurePreClick = true
        AA:ScanOpenTradeSkillRecipes(true)
        AA.recipeScanInSecurePreClick = false
    end)
    nextButton:HookScript("OnClick", function(self)
        if self.rescanOnly then
            AA:RescanOpenRecipeProfession()
            return
        end
        if self.professionName then
            AA:QueueRecipeCapture(7, 0.12, self.professionName)
            if AA.recipeGuideFrame and AA.recipeGuideFrame.statusText then
                AA.recipeGuideFrame.pendingProfession = self.professionName
                AA.recipeGuideFrame.statusText:SetText("Opening " .. self.professionName .. "... Alternator will retry the capture several times while the TradeSkill list loads.")
                AA.recipeGuideFrame.statusText:SetTextColor(0.72, 0.82, 1.0)
            end
        end
    end)
    frame.nextButton = nextButton
    local refreshButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    refreshButton:SetSize(105, 23); refreshButton:SetPoint("LEFT", nextButton, "RIGHT", 8, 0); refreshButton:SetText("Rescan open")
    refreshButton:SetScript("OnClick", function() AA:RescanOpenRecipeProfession() end)
    frame.refreshButton = refreshButton
    frame:SetScript("OnShow", function(self)
        if self.Raise then self:Raise() end
        AA:ScanCurrentCharacterProfile(true)
        AA:RefreshRecipeGuide()
    end)
    if UISpecialFrames then table.insert(UISpecialFrames, "AlternatorRecipeGuideFrame") end
    self.recipeGuideFrame = frame
    return frame
end

function AA:RefreshRecipeGuide()
    local frame = self.recipeGuideFrame
    if not frame then return end
    local char = self.db and self.db.characters and self.db.characters[self.currentCharacterKey]
    local professions = self:GetCurrentRecipeProfessions()
    local charName = char and self:CharacterDisplayName(char) or "current character"
    frame.subtitle:SetText(charName .. " - open each profession once so the 5.4.8 TradeSkill API can expose its recipe list.")

    local openProfession
    if type(GetTradeSkillLine) == "function" then
        local candidate = GetTradeSkillLine()
        if candidate and candidate ~= "" and candidate ~= "UNKNOWN" then openProfession = candidate end
    end
    local inCombat = type(InCombatLockdown) == "function" and InCombatLockdown()
    local scanned = 0

    for i = 1, 4 do
        local row = frame.rows[i]
        local prof = professions[i]
        if prof then
            row:Show()
            row.professionName = prof.name
            row.nameText:SetText(prof.name or "Profession")

            local isOpen = openProfession and Lower(Trim(openProfession)) == Lower(Trim(prof.name or ""))
            if row.openButton and not inCombat then
                row.openButton.rescanOnly = false
                if isOpen then
                    -- When this profession is already open, Refresh/Rescan should
                    -- read it, not toggle the Blizzard TradeSkill frame closed.
                    self:ClearSecureProfessionButton(row.openButton)
                    row.openButton:RegisterForClicks("LeftButtonUp")
                    row.openButton.rescanOnly = true
                else
                    self:ConfigureSecureProfessionButton(row.openButton, prof)
                end
            end

            local book = char and self:GetRecipeBook(char, prof.name) or nil
            if book and book.lastScan then
                row.statusText:SetText(tostring(RecipeCount(book)) .. " recipes stored")
                row.statusText:SetTextColor(0.35, 1.0, 0.35)
                row.openButton:SetText(isOpen and "Rescan" or "Refresh")
                scanned = scanned + 1
            else
                row.statusText:SetText("not scanned")
                row.statusText:SetTextColor(1.0, 0.62, 0.18)
                row.openButton:SetText(isOpen and "Scan now" or "Open")
            end
        else
            row:Hide()
            row.professionName = nil
            if row.openButton then row.openButton.rescanOnly = false end
        end
    end

    local nextMissing
    for _, prof in ipairs(professions) do
        local book = char and self:GetRecipeBook(char, prof.name) or nil
        if not (book and book.lastScan) then nextMissing = prof break end
    end

    if frame.nextButton and not inCombat then
        frame.nextButton.rescanOnly = false
        if nextMissing then
            local missingIsOpen = openProfession and Lower(Trim(openProfession)) == Lower(Trim(nextMissing.name or ""))
            if missingIsOpen then
                self:ClearSecureProfessionButton(frame.nextButton)
                frame.nextButton:RegisterForClicks("LeftButtonUp")
                frame.nextButton.rescanOnly = true
            else
                self:ConfigureSecureProfessionButton(frame.nextButton, nextMissing)
            end
            frame.nextButton.professionName = nextMissing.name
        else
            self:ClearSecureProfessionButton(frame.nextButton)
            frame.nextButton.professionName = nil
        end
    end

    if #professions == 0 then
        frame.statusText:SetText("No recipe-capable profession was detected on this character.")
        frame.statusText:SetTextColor(0.72,0.72,0.72)
        frame.nextButton:Disable()
    elseif scanned >= #professions then
        frame.statusText:SetText(string.format("Complete: %d / %d profession recipe snapshots captured.", scanned, #professions))
        frame.statusText:SetTextColor(0.35,1.0,0.35)
        frame.nextButton:Disable()
    else
        frame.statusText:SetText(string.format("Progress: %d / %d profession recipe snapshots captured.", scanned, #professions))
        frame.statusText:SetTextColor(0.72,0.72,0.72)
        frame.nextButton:Enable()
    end
end

function AA:ShowRecipeGuide()
    if not self:IsEnabled() then return end
    local frame = self:CreateRecipeGuideFrame(); frame:Show(); if frame.Raise then frame:Raise() end; self:RefreshRecipeGuide()
end

function AA:CreateRecipeFrame()
    if self.recipeFrame then
        return self.recipeFrame
    end

    local frame = CreateFrame("Frame", "AlternatorRecipeFrame", UIParent)
    frame:SetSize(RECIPE_WIDTH, RECIPE_HEIGHT)
    frame:SetPoint("CENTER", UIParent, "CENTER", 0, 10)
    frame:SetFrameStrata("FULLSCREEN_DIALOG")
    frame:SetFrameLevel(100)
    if frame.SetToplevel then frame:SetToplevel(true) end
    frame:SetClampedToScreen(true)
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", function(self) self:StartMoving() end)
    frame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
    frame:SetBackdrop({
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 32, edgeSize = 32,
        insets = { left = 11, right = 12, top = 12, bottom = 11 },
    })
    local solidBG = frame:CreateTexture(nil, "BACKGROUND")
    solidBG:SetPoint("TOPLEFT", frame, "TOPLEFT", 11, -12)
    solidBG:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -12, 11)
    solidBG:SetTexture(0.025, 0.025, 0.025, 1)
    frame.solidBG = solidBG

    local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOPLEFT", frame, "TOPLEFT", 18, -15)
    title:SetText("Alternator - Recipes")
    frame.title = title

    local subtitle = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    subtitle:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -3)
    subtitle:SetPoint("RIGHT", frame, "RIGHT", -42, 0)
    subtitle:SetJustifyH("LEFT")
    frame.subtitle = subtitle

    local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -5, -5)

    local header = frame:CreateTexture(nil, "ARTWORK")
    frame.header = header
    header:SetPoint("TOPLEFT", frame, "TOPLEFT", 18, -56)
    header:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -18, -56)
    header:SetHeight(22)
    header:SetTexture(0.08, 0.08, 0.08, 0.95)

    local hRecipe = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    hRecipe:SetPoint("LEFT", header, "LEFT", 30, 0)
    hRecipe:SetText("Recipe")
    local hProf = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    hProf:SetPoint("LEFT", header, "LEFT", 365, 0)
    hProf:SetText("Profession")
    local hChar = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    hChar:SetPoint("RIGHT", header, "RIGHT", -8, 0)
    hChar:SetText("Character")

    local scroll = CreateFrame("ScrollFrame", "AlternatorRecipeScrollFrame", frame, "FauxScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, -2)
    scroll:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -30, 22)
    scroll:SetScript("OnVerticalScroll", function(self, offset)
        FauxScrollFrame_OnVerticalScroll(self, offset, RECIPE_ROW_HEIGHT, function() AA:RefreshRecipeFrame() end)
    end)
    frame.scroll = scroll

    frame.rows = {}
    for i = 1, RECIPE_VISIBLE_ROWS do
        local row = CreateFrame("Button", nil, frame)
        row:SetHeight(RECIPE_ROW_HEIGHT)
        row:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, -2 - ((i - 1) * RECIPE_ROW_HEIGHT))
        row:SetPoint("RIGHT", frame, "RIGHT", -32, 0)
        row:RegisterForClicks("LeftButtonUp")
        local bg = row:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints(); bg:SetTexture(1,1,1,1); bg:SetVertexColor(0.12,0.12,0.12,(i%2==0) and 0.35 or 0.18)
        local icon = row:CreateTexture(nil, "ARTWORK")
        icon:SetSize(17,17); icon:SetPoint("LEFT", row, "LEFT", 4,0); icon:SetTexCoord(0.08,0.92,0.08,0.92); row.icon=icon
        local recipeText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        recipeText:SetPoint("LEFT", icon, "RIGHT", 5,0); recipeText:SetWidth(305); recipeText:SetJustifyH("LEFT"); row.recipeText=recipeText
        local profText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        profText:SetPoint("LEFT", row, "LEFT", 365,0); profText:SetWidth(95); profText:SetJustifyH("LEFT"); row.profText=profText
        local charText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        charText:SetPoint("RIGHT", row, "RIGHT", -8,0); charText:SetWidth(110); charText:SetJustifyH("RIGHT"); row.charText=charText
        row:SetScript("OnEnter", function(self)
            local data=self.data
            if data and data.recipe then
                GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
                if data.recipe.recipeLink then
                    local ok=pcall(GameTooltip.SetHyperlink,GameTooltip,data.recipe.recipeLink)
                    if not ok then GameTooltip:AddLine(data.recipe.name or "Recipe",1,0.82,0) end
                else
                    GameTooltip:AddLine(data.recipe.name or "Recipe",1,0.82,0)
                end
                GameTooltip:AddLine((data.char and data.char.name or "?") .. " - " .. (data.profession or "Profession"),0.8,0.8,0.8)
                GameTooltip:Show()
            end
        end)
        row:SetScript("OnLeave", function() GameTooltip:Hide() end)
        row:SetScript("OnClick", function(self)
            local data=self.data
            if data and data.recipe and IsShiftKeyDown() and ChatEdit_GetActiveWindow and ChatEdit_InsertLink and ChatEdit_GetActiveWindow() then
                ChatEdit_InsertLink(data.recipe.recipeLink or data.recipe.itemLink or data.recipe.name or "")
            end
        end)
        frame.rows[i]=row
    end

    local empty = frame:CreateFontString(nil,"OVERLAY","GameFontHighlight")
    empty:SetPoint("CENTER",frame,"CENTER",0,-10); empty:SetWidth(520); empty:SetJustifyH("CENTER"); frame.emptyText=empty

    frame:SetScript("OnShow", function(self)
        if self.Raise then self:Raise() end
    end)
    frame:SetScript("OnMouseDown", function(self)
        if self.Raise then self:Raise() end
    end)
    frame:SetScript("OnHide", function()
        AA:HideCollectionTooltip()
        if GameTooltip then GameTooltip:Hide() end
    end)
    frame:Hide()
    if UISpecialFrames then table.insert(UISpecialFrames,"AlternatorRecipeFrame") end
    self.recipeFrame=frame
    return frame
end

function AA:RefreshRecipeFrame()
    local frame=self.recipeFrame
    if not frame then return end
    local results=self.recipeResults or {}
    local context=self.recipeContext or {}
    if frame.header then frame.header:Show() end
    if frame.scroll then frame.scroll:Show() end
    if context.mode=="profession" then
        local char=self:GetCharacterByKey(context.charKey)
        local book=char and self:GetRecipeBook(char,context.professionName)
        frame.title:SetText("Alternator - " .. (book and book.name or context.professionName or "Recipes"))
        frame.subtitle:SetText(string.format("%s - %d stored recipe(s). Open this profession on that character to refresh its recipe snapshot.", char and self:CharacterDisplayName(char) or "Unknown character", #results))
    elseif context.mode=="search" then
        frame.title:SetText("Alternator - Recipe Search")
        frame.subtitle:SetText(string.format("%d result(s) for '%s' in the currently selected realm scope.", #results, context.query or ""))
    elseif context.mode=="professionInfo" then
        local char=self:GetCharacterByKey(context.charKey)
        frame.title:SetText("Alternator - " .. (context.professionName or "Profession"))
        frame.subtitle:SetText(string.format("%s - stored skill %d / %d.", char and self:CharacterDisplayName(char) or "Unknown character", tonumber(context.skill) or 0, tonumber(context.max) or 0))
        if frame.header then frame.header:Hide() end
        if frame.scroll then frame.scroll:Hide() end
    else
        frame.title:SetText("Alternator - Recipes")
        frame.subtitle:SetText("")
    end

    if context.mode=="professionInfo" then
        for i=1,RECIPE_VISIBLE_ROWS do frame.rows[i]:Hide() end
        frame.emptyText:Show()
        frame.emptyText:SetText("This stored profession snapshot contains the skill level only. This profession does not expose a recipe list that Alternator can browse offline.")
        return
    end

    FauxScrollFrame_Update(frame.scroll,#results,RECIPE_VISIBLE_ROWS,RECIPE_ROW_HEIGHT)
    local offset=FauxScrollFrame_GetOffset(frame.scroll) or 0
    for i=1,RECIPE_VISIBLE_ROWS do
        local row=frame.rows[i]
        local data=results[offset+i]
        row.data=data
        if data then
            row:Show()
            row.icon:SetTexture((data.recipe and data.recipe.icon) or "Interface\\Icons\\INV_Misc_QuestionMark")
            row.recipeText:SetText(data.recipe and data.recipe.name or "Unknown recipe")
            row.profText:SetText(data.profession or "")
            local c=data.char and RAID_CLASS_COLORS and data.char.class and RAID_CLASS_COLORS[data.char.class]
            row.charText:SetText(data.char and data.char.name or "?")
            if c then row.charText:SetTextColor(c.r,c.g,c.b) else row.charText:SetTextColor(1,1,1) end
        else
            row:Hide()
        end
    end
    if #results==0 then
        frame.emptyText:Show()
        if context.mode=="profession" then
            frame.emptyText:SetText("No stored recipes for this profession yet. Log that character, open the profession window once, and Alternator will capture the visible recipe list.")
        else
            frame.emptyText:SetText("No stored recipe matched the search. Recipe data is learned when you open a profession on each character.")
        end
    else frame.emptyText:Hide() end
end

function AA:ToggleProfessionRecipeWindow(mode, charKey, professionName)
    local frame = self.recipeFrame
    if not frame or not frame:IsShown() then return false end
    local context = self.recipeContext or {}
    local wanted = RecipeBookKey(professionName)
    local current = RecipeBookKey(context.professionName)
    if context.mode == mode and context.charKey == charKey and wanted ~= "" and wanted == current then
        frame:Hide()
        return true
    end
    return false
end

function AA:OpenProfessionSnapshot(charKey, professionName)
    if not professionName or professionName=="" then return end
    if self:ToggleProfessionRecipeWindow("profession", charKey, professionName) then return true end
    self:BuildRecipeResultsForProfession(charKey,professionName)
    local frame=self:CreateRecipeFrame()
    frame:Show()
    self:RefreshRecipeFrame()
end

function AA:SearchRecipes(query)
    query=Trim(query or "")
    if query=="" then
        Print("Enter part of a recipe name to search stored profession snapshots.")
        return
    end
    self:BuildRecipeSearchResults(query)
    local frame=self:CreateRecipeFrame()
    frame:Show()
    self:RefreshRecipeFrame()
end

local DASHBOARD_COLUMNS = {
    { key = "name",           label = "Character", width = 112 },
    { key = "realm",          label = "Realm", width = 78 },
    { key = "level",          label = "Lvl", width = 34 },
    { key = "prof1",          label = "Profession 1", width = 125 },
    { key = "prof1skill",     label = "Skill", width = 42 },
    { key = "prof2",          label = "Profession 2", width = 125 },
    { key = "prof2skill",     label = "Skill", width = 42 },
    { key = "arch",           label = "Archaeology", width = 66 },
    { key = "fishing",        label = "Fishing", width = 54 },
    { key = "cooking",        label = "Cooking", width = 54 },
    { key = "firstAid",       label = "First Aid", width = 58 },
    { key = "valor",          label = "A Test of Valor", width = 100, milestone = "valor" },
    { key = "pvp",            label = "PvP", width = 60, milestone = "pvp" },
    { key = "secrets",        label = "Secrets", width = 72, milestone = "secrets" },
    { key = "meta",           label = "Lege Meta", width = 72, milestone = "meta" },
    { key = "runestones",     label = "Runestones", width = 82, milestone = "runestones" },
    { key = "cloak",          label = "Cloak", width = 66, milestone = "cloak" },
    { key = "legendaryCloak", label = "Lege Cloak", width = 80, milestone = "legendaryCloak" },
    { key = "mounts",         label = "Mounts", width = 90 },
    { key = "companions",     label = "Companions", width = 110 },
    { key = "remove",         label = "", width = 24 },
}

local DASHBOARD_COLUMN_LOOKUP = {}
for _, column in ipairs(DASHBOARD_COLUMNS) do
    DASHBOARD_COLUMN_LOOKUP[column.key] = column
end

local DASHBOARD_VIEW_COLUMN_KEYS = {
    professions = { "name", "realm", "level", "prof1", "prof1skill", "prof2", "prof2skill", "arch", "fishing", "cooking", "firstAid", "remove" },
    legendary = { "name", "realm", "level", "valor", "pvp", "secrets", "meta", "runestones", "cloak", "legendaryCloak", "remove" },
    collections = { "name", "realm", "level", "mounts", "companions", "remove" },
}

local function GetDashboardColumns(view)
    local columns = {}
    local keys = DASHBOARD_VIEW_COLUMN_KEYS[view] or DASHBOARD_VIEW_COLUMN_KEYS.professions
    for _, key in ipairs(keys) do
        local column = DASHBOARD_COLUMN_LOOKUP[key]
        if column then
            table.insert(columns, column)
        end
    end
    return columns
end

local function DashboardTotalWidth(view)
    local total = 0
    for _, column in ipairs(GetDashboardColumns(view)) do
        total = total + column.width
    end
    return total
end

local function FindMilestoneByKey(key)
    for _, milestone in ipairs(LEGENDARY_MILESTONES) do
        if milestone.key == key then
            return milestone
        end
    end
    return nil
end

local function SetCellBackground(cell, color)
    if not cell or not cell.bg then
        return
    end
    color = color or { 0.12, 0.12, 0.12, 0.45 }
    cell.bg:SetVertexColor(color[1], color[2], color[3], color[4] or 0.7)
end

local function ProfessionStateColor(prof, missingAsZero)
    if not prof then
        return missingAsZero and PROF_STATE_COLORS.low or PROF_STATE_COLORS.none
    end
    local skill = tonumber(prof.skill) or 0
    if skill >= 600 then
        return PROF_STATE_COLORS.max
    elseif skill >= 450 then
        return PROF_STATE_COLORS.partial
    elseif skill > 0 then
        return PROF_STATE_COLORS.low
    end
    return PROF_STATE_COLORS.low
end

local function ProfessionDisplayName(prof)
    if not prof then
        return "-"
    end
    local name = Trim(prof.name or "")
    if name ~= "" and name ~= "?" then
        return name
    end
    local skillLine = tonumber(prof.skillLine)
    if skillLine and PROFESSION_NAMES_BY_SKILLLINE[skillLine] then
        return PROFESSION_NAMES_BY_SKILLLINE[skillLine]
    end
    local short = Trim(prof.short or "")
    if short ~= "" then
        return short
    end
    return "Profession"
end

local function CollectionDetailTable(char, collectionType)
    local collections = char and char.collections
    if type(collections) ~= "table" then
        return nil
    end
    if collectionType == "mounts" then
        return collections.mountDetails
    end
    return collections.petDetails
end

local function CollectionSnapshotStatus(char, collectionType)
    local collections = char and char.collections
    if type(collections) ~= "table" then
        return nil, false, 0, 0
    end

    local details = CollectionDetailTable(char, collectionType)
    local complete, captured, expected
    if collectionType == "mounts" then
        complete = collections.mountDetailsComplete == true
        captured = tonumber(collections.mountDetailCaptured) or 0
        expected = tonumber(collections.mountDetailExpected) or tonumber(collections.mounts) or 0
    else
        complete = collections.petDetailsComplete == true
        captured = tonumber(collections.petDetailCaptured) or 0
        expected = tonumber(collections.petDetailExpected) or tonumber(collections.companions) or 0
    end

    if collections.detailsVersion ~= COLLECTION_DETAIL_VERSION then
        complete = false
    end
    if type(details) ~= "table" then
        complete = false
    end

    return details, complete, captured, expected
end

local function BuildCollectionMatchIndex(details, collectionType)
    local index = {}
    if type(details) ~= "table" then
        return index
    end

    for key, item in pairs(details) do
        if type(item) == "table" then
            local matchKey
            if collectionType == "mounts" then
                matchKey = item.matchKey or Lower(item.name or tostring(key))
            else
                matchKey = tostring(item.speciesID or key)
            end

            if matchKey and matchKey ~= "" then
                local quantity = collectionType == "companions" and (tonumber(item.count) or 1) or 1
                local existing = index[matchKey]
                if existing then
                    existing.count = (tonumber(existing.count) or 0) + quantity
                else
                    index[matchKey] = {
                        name = item.name or tostring(key),
                        icon = item.icon,
                        count = quantity,
                    }
                end
            end
        end
    end

    return index
end

local function CollectionValue(char, collectionType)
    local collections = char and char.collections or {}
    if collectionType == "mounts" then
        return tonumber(collections.mounts) or 0
    end
    return tonumber(collections.companions) or 0
end

local function BuildCollectionPairDiff(char, other, collectionType)
    local currentDetails, currentComplete = CollectionSnapshotStatus(char, collectionType)
    local otherDetails, otherComplete = CollectionSnapshotStatus(other, collectionType)
    if not currentComplete or not otherComplete then
        return nil
    end

    local currentIndex = BuildCollectionMatchIndex(currentDetails, collectionType)
    local otherIndex = BuildCollectionMatchIndex(otherDetails, collectionType)
    local onlyCurrent = {}
    local onlyOther = {}
    local onlyCurrentUnits = 0
    local onlyOtherUnits = 0

    for key, item in pairs(currentIndex) do
        local own = tonumber(item.count) or 1
        local theirs = otherIndex[key] and (tonumber(otherIndex[key].count) or 1) or 0
        if own > theirs then
            local delta = own - theirs
            onlyCurrentUnits = onlyCurrentUnits + delta
            table.insert(onlyCurrent, { name = item.name, icon = item.icon, count = delta })
        end
    end

    for key, item in pairs(otherIndex) do
        local theirs = tonumber(item.count) or 1
        local own = currentIndex[key] and (tonumber(currentIndex[key].count) or 1) or 0
        if theirs > own then
            local delta = theirs - own
            onlyOtherUnits = onlyOtherUnits + delta
            table.insert(onlyOther, { name = item.name, icon = item.icon, count = delta })
        end
    end

    table.sort(onlyCurrent, function(a, b) return Lower(a.name) < Lower(b.name) end)
    table.sort(onlyOther, function(a, b) return Lower(a.name) < Lower(b.name) end)

    local currentValue = CollectionValue(char, collectionType)
    local otherValue = CollectionValue(other, collectionType)
    local net = currentValue - otherValue

    return {
        other = other,
        currentValue = currentValue,
        otherValue = otherValue,
        net = net,
        onlyCurrent = onlyCurrent,
        onlyOther = onlyOther,
        onlyCurrentUnits = onlyCurrentUnits,
        onlyOtherUnits = onlyOtherUnits,
        symmetricUnits = onlyCurrentUnits + onlyOtherUnits,
        exactExtra = net > 0 and onlyOtherUnits == 0 and onlyCurrentUnits == net,
        exactMissing = net < 0 and onlyCurrentUnits == 0 and onlyOtherUnits == -net,
    }
end

function AA:GetBestCollectionComparison(char, collectionType)
    local best
    local incomplete = 0
    local currentDetails, currentComplete, currentCaptured, currentExpected = CollectionSnapshotStatus(char, collectionType)
    if not currentComplete then
        return nil, incomplete, currentCaptured, currentExpected
    end

    for _, other in ipairs(self:GetDashboardCharactersSorted()) do
        if other.key ~= char.key then
            local _, otherComplete = CollectionSnapshotStatus(other, collectionType)
            if otherComplete then
                local diff = BuildCollectionPairDiff(char, other, collectionType)
                if diff then
                    local sameFaction = char.faction and other.faction and char.faction == other.faction
                    diff.sameFaction = sameFaction and true or false
                    if not best
                        or (diff.sameFaction and not best.sameFaction)
                        or (diff.sameFaction == best.sameFaction and diff.symmetricUnits < best.symmetricUnits)
                        or (diff.sameFaction == best.sameFaction and diff.symmetricUnits == best.symmetricUnits and math.abs(diff.net) < math.abs(best.net))
                        or (diff.sameFaction == best.sameFaction and diff.symmetricUnits == best.symmetricUnits and math.abs(diff.net) == math.abs(best.net) and Lower(other.name) < Lower(best.other.name))
                    then
                        best = diff
                    end
                end
            else
                incomplete = incomplete + 1
            end
        end
    end

    return best, incomplete, currentCaptured, currentExpected
end

local function AddCollectionItemLines(items, collectionType, maxLines)
    maxLines = maxLines or 8
    local shown = math.min(#items, maxLines)
    for i = 1, shown do
        local item = items[i]
        local suffix = (collectionType == "companions" and (tonumber(item.count) or 1) > 1)
            and ("  x" .. tostring(item.count)) or ""
        GameTooltip:AddLine("- " .. tostring(item.name or "Unknown") .. suffix, 0.92, 0.92, 0.92)
    end
    if #items > shown then
        GameTooltip:AddLine("... and " .. tostring(#items - shown) .. " more", 0.65, 0.65, 0.65)
    end
end


local function SetCollectionTooltipFont(fs, size)
    local font, _, flags = fs:GetFont()
    if font then
        fs:SetFont(font, size or COLLECTION_TOOLTIP_FONT_SIZE, flags)
    end
end

local function CollectionItemLabel(item, collectionType)
    local suffix = (collectionType == "companions" and (tonumber(item.count) or 1) > 1)
        and ("  x" .. tostring(item.count)) or ""
    return "- " .. tostring(item.name or "Unknown") .. suffix
end

function AA:GetCollectionTooltipFrame()
    if self.collectionTooltip then
        return self.collectionTooltip
    end

    local frame = CreateFrame("Frame", "AlternatorCollectionDiffTooltip", UIParent)
    frame:SetFrameStrata("TOOLTIP")
    frame:SetFrameLevel(200)
    frame:SetClampedToScreen(true)
    -- Match the stock WoW item-tooltip frame as closely as possible.  On
    -- 5.4.8 GameTooltip already owns the canonical tooltip backdrop, so copy
    -- it when available instead of maintaining a visually-similar variant.
    local stockBackdrop = GameTooltip and GameTooltip.GetBackdrop and GameTooltip:GetBackdrop()
    if stockBackdrop then
        frame:SetBackdrop(stockBackdrop)
    else
        frame:SetBackdrop({
            bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
            tile = true,
            tileSize = 16,
            edgeSize = 16,
            insets = { left = 4, right = 4, top = 4, bottom = 4 },
        })
    end

    -- Keep Alternator's diff tooltip fully opaque for readability, while the
    -- border color itself follows the normal GameTooltip/item-tooltip style.
    frame:SetBackdropColor(0.025, 0.025, 0.025, 1)
    if GameTooltip and GameTooltip.GetBackdropBorderColor then
        local br, bg, bb, ba = GameTooltip:GetBackdropBorderColor()
        frame:SetBackdropBorderColor(br or 0.6, bg or 0.6, bb or 0.6, ba or 1)
    else
        frame:SetBackdropBorderColor(0.6, 0.6, 0.6, 1)
    end

    -- Some 5.4.8 clients/private-server UI builds keep the tooltip backdrop
    -- texture partially translucent even when SetBackdropColor alpha is 1.
    -- Put a solid black texture behind the contents so the diff is always
    -- readable over the world and over the Alternator dashboard.
    frame.opaqueBackground = frame:CreateTexture(nil, "BACKGROUND")
    frame.opaqueBackground:SetTexture(0, 0, 0, 1)
    frame.opaqueBackground:SetPoint("TOPLEFT", frame, "TOPLEFT", 5, -5)
    frame.opaqueBackground:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -5, 5)
    frame.opaqueBackground:SetAlpha(1)

    frame.textPool = {}
    frame:Hide()

    self.collectionTooltip = frame
    return frame
end

function AA:HideCollectionTooltip()
    if self.collectionTooltip then
        self.collectionTooltip:Hide()
    end
end

local function ResetCollectionTooltip(frame)
    for _, fs in ipairs(frame.textPool or {}) do
        fs:Hide()
        fs:ClearAllPoints()
        fs:SetText("")
    end
end

local function AcquireCollectionTooltipText(frame, index, size, r, g, b)
    local fs = frame.textPool[index]
    if not fs then
        fs = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        frame.textPool[index] = fs
    end
    fs:Show()
    fs:ClearAllPoints()
    fs:SetTextColor(r or 0.92, g or 0.92, b or 0.92)
    fs:SetJustifyH("LEFT")
    fs:SetJustifyV("TOP")
    SetCollectionTooltipFont(fs, size or COLLECTION_TOOLTIP_FONT_SIZE)
    return fs
end

function AA:ShowCollectionDiffTooltip(cell, data)
    local char = data and data.char
    local collectionType = data and data.collectionType
    if not char or not collectionType then
        return
    end

    if GameTooltip then GameTooltip:Hide() end

    local frame = self:GetCollectionTooltipFrame()
    ResetCollectionTooltip(frame)

    local details, complete, captured, expected = CollectionSnapshotStatus(char, collectionType)
    local diff, incomplete
    if complete then
        diff, incomplete = self:GetBestCollectionComparison(char, collectionType)
    end

    local items = diff and diff.onlyCurrent or {}
    local screenWidth = (UIParent and UIParent:GetWidth()) or 1280
    local maxColumns = math.max(1, math.floor((screenWidth - 40) / COLLECTION_TOOLTIP_COLUMN_WIDTH))
    maxColumns = math.min(maxColumns, 8)
    local desiredColumns = math.max(1, math.ceil(math.max(#items, 1) / COLLECTION_TOOLTIP_ITEMS_PER_COLUMN))
    local columns = math.min(desiredColumns, maxColumns)
    local rowsPerColumn = math.max(1, math.ceil(math.max(#items, 1) / columns))

    local frameWidth = math.max(430, 24 + (columns * COLLECTION_TOOLTIP_COLUMN_WIDTH))
    local summaryHeight = 132
    local gridHeadingHeight = (#items > 0) and 24 or 0
    local gridHeight = (#items > 0) and (rowsPerColumn * COLLECTION_TOOLTIP_ROW_HEIGHT) or 0
    local footerHeight = diff and 38 or 26
    local frameHeight = summaryHeight + gridHeadingHeight + gridHeight + footerHeight
    frame:SetSize(frameWidth, frameHeight)

    local poolIndex = 0
    local function text(size, r, g, b)
        poolIndex = poolIndex + 1
        return AcquireCollectionTooltipText(frame, poolIndex, size, r, g, b)
    end

    -- Use a fixed summary value column instead of TOPRIGHT-only anchors. This
    -- keeps values such as the comparison mount count from ever drawing over a
    -- character name on older 5.4.8 font-string implementations.
    local function placeRightValue(fs, yOffset)
        fs:SetPoint("TOPLEFT", frame, "TOPLEFT", frameWidth - 82, yOffset)
        fs:SetWidth(68)
        fs:SetJustifyH("RIGHT")
    end

    local left = 12
    local top = -10
    local lineH = 15

    local title = text(COLLECTION_TOOLTIP_TITLE_SIZE, 1, 0.82, 0)
    title:SetPoint("TOPLEFT", frame, "TOPLEFT", left, top)
    title:SetText(data.label or (collectionType == "mounts" and "Mounts" or "Companions / battle pets"))

    local storedL = text(COLLECTION_TOOLTIP_FONT_SIZE, 1, 1, 1)
    storedL:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -4)
    storedL:SetText("Stored count")
    local storedR = text(COLLECTION_TOOLTIP_FONT_SIZE, 1, 1, 1)
    placeRightValue(storedR, top - lineH)
    storedR:SetText(tostring(data.value or 0))

    if not complete then
        local warn = text(COLLECTION_TOOLTIP_FONT_SIZE, 1, 0.65, 0.2)
        warn:SetPoint("TOPLEFT", frame, "TOPLEFT", left, top - 42)
        warn:SetWidth(frameWidth - 24)
        warn:SetText("Detailed snapshot is incomplete or from an older Alternator version.")
        local cap = text(COLLECTION_TOOLTIP_FONT_SIZE, 0.82, 0.82, 0.82)
        cap:SetPoint("TOPLEFT", warn, "BOTTOMLEFT", 0, -6)
        cap:SetText("Captured / expected: " .. tostring(captured or 0) .. " / " .. tostring(expected or 0))
        local rescan = text(COLLECTION_TOOLTIP_FONT_SIZE, 0.72, 0.72, 0.72)
        rescan:SetPoint("TOPLEFT", cap, "BOTTOMLEFT", 0, -6)
        rescan:SetWidth(frameWidth - 24)
        rescan:SetText("Log this character once with Alternator 0.2.7+ to rebuild a verified snapshot.")
    elseif not diff then
        local no = text(COLLECTION_TOOLTIP_FONT_SIZE, 0.68, 0.68, 0.68)
        no:SetPoint("TOPLEFT", frame, "TOPLEFT", left, top - 42)
        no:SetWidth(frameWidth - 24)
        no:SetText("No other complete detailed snapshot is available in the selected realm scope.")
    else
        local other = diff.other
        local otherLabel = (other.name or "Unknown") .. "-" .. (other.realm or "UnknownRealm")

        local best = text(COLLECTION_TOOLTIP_FONT_SIZE, 0.35, 0.85, 1.0)
        best:SetPoint("TOPLEFT", frame, "TOPLEFT", left, top - 42)
        best:SetText("Compared with (closest snapshot)")

        local otherL = text(COLLECTION_TOOLTIP_FONT_SIZE, 0.92, 0.92, 0.92)
        otherL:SetPoint("TOPLEFT", best, "BOTTOMLEFT", 0, -2)
        otherL:SetWidth(frameWidth - 112)
        otherL:SetText(otherLabel)
        local otherR = text(COLLECTION_TOOLTIP_FONT_SIZE, 1, 1, 1)
        placeRightValue(otherR, top - 57)
        otherR:SetText(tostring(diff.otherValue))

        local netText = diff.net > 0 and ("+" .. tostring(diff.net)) or tostring(diff.net)
        local nr, ng, nb = 1, 1, 1
        if diff.net > 0 then nr, ng, nb = 0.3, 1, 0.3 elseif diff.net < 0 then nr, ng, nb = 1, 0.35, 0.35 end
        local netL = text(COLLECTION_TOOLTIP_FONT_SIZE, 1, 1, 1)
        netL:SetPoint("TOPLEFT", frame, "TOPLEFT", left, top - 72)
        netL:SetText("Net count difference")
        local netR = text(COLLECTION_TOOLTIP_FONT_SIZE, nr, ng, nb)
        placeRightValue(netR, top - 72)
        netR:SetText(netText)

        if (diff.onlyCurrentUnits or 0) == 0 and (diff.onlyOtherUnits or 0) == 0 then
            local identical = text(COLLECTION_TOOLTIP_FONT_SIZE, 0.55, 1.00, 0.55)
            identical:SetPoint("TOPLEFT", frame, "TOPLEFT", left, top - 87)
            identical:SetText("Collections are identical")
        else
            if (diff.onlyCurrentUnits or 0) > 0 then
                local onlyL = text(COLLECTION_TOOLTIP_FONT_SIZE, 1, 1, 1)
                onlyL:SetPoint("TOPLEFT", frame, "TOPLEFT", left, top - 87)
                onlyL:SetText("Only on " .. (char.name or "this character"))
                local onlyR = text(COLLECTION_TOOLTIP_FONT_SIZE, 1, 1, 1)
                placeRightValue(onlyR, top - 87)
                onlyR:SetText(tostring(diff.onlyCurrentUnits))
            end

            if (diff.onlyOtherUnits or 0) > 0 then
                local theirY = (diff.onlyCurrentUnits or 0) > 0 and (top - 102) or (top - 87)
                local theirL = text(COLLECTION_TOOLTIP_FONT_SIZE, 1, 1, 1)
                theirL:SetPoint("TOPLEFT", frame, "TOPLEFT", left, theirY)
                theirL:SetText("Only on " .. (other.name or "comparison"))
                local theirR = text(COLLECTION_TOOLTIP_FONT_SIZE, 1, 1, 1)
                placeRightValue(theirR, theirY)
                theirR:SetText(tostring(diff.onlyOtherUnits))
            end
        end

        if #items > 0 then
            local headingY = top - summaryHeight + 8
            local heading = text(COLLECTION_TOOLTIP_FONT_SIZE, 0.35, 0.85, 1.0)
            heading:SetPoint("TOPLEFT", frame, "TOPLEFT", left, headingY)
            if diff.exactExtra then
                heading:SetText("Confirmed extra " .. (collectionType == "mounts" and "mounts" or "companions") .. " - full list")
            else
                heading:SetText("Only on this snapshot - full list (" .. tostring(#items) .. " entries)")
            end

            local gridTop = headingY - 20
            for i, item in ipairs(items) do
                local col = math.floor((i - 1) / rowsPerColumn)
                local row = (i - 1) % rowsPerColumn
                local fs = text(COLLECTION_TOOLTIP_FONT_SIZE, 0.92, 0.92, 0.92)
                fs:SetPoint("TOPLEFT", frame, "TOPLEFT", left + (col * COLLECTION_TOOLTIP_COLUMN_WIDTH), gridTop - (row * COLLECTION_TOOLTIP_ROW_HEIGHT))
                fs:SetWidth(COLLECTION_TOOLTIP_COLUMN_WIDTH - 6)
                fs:SetHeight(COLLECTION_TOOLTIP_ROW_HEIGHT)
                fs:SetText(CollectionItemLabel(item, collectionType))
            end
        end

        local footerY = -frameHeight + 31
        local note = text(9, 0.68, 0.68, 0.68)
        note:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", left, 12)
        note:SetWidth(frameWidth - 24)
        if not diff.sameFaction and collectionType == "mounts" then
            note:SetText("Different-faction comparison: many listed names can be faction substitutions rather than genuinely unique mounts.")
        else
            note:SetText("Closest snapshot = the most similar complete character snapshot in the active realm scope (same faction is preferred).")
        end
        if incomplete and incomplete > 0 then
            note:SetText(note:GetText() .. "  " .. tostring(incomplete) .. " shown character(s) were skipped because their detail snapshot is incomplete.")
        end
    end

    frame:ClearAllPoints()
    local x, y = GetCursorPosition()
    local scale = (UIParent and UIParent:GetEffectiveScale()) or 1
    x, y = x / scale, y / scale
    frame:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", x + 16, y + 16)
    frame:Show()
end

function AA:ShowDashboardCellTooltip(cell)
    local data = cell and cell.data
    if not data then
        return
    end

    if data.kind == "collection" then
        self:ShowCollectionDiffTooltip(cell, data)
        return
    end

    self:HideCollectionTooltip()
    GameTooltip:SetOwner(cell, "ANCHOR_CURSOR")

    if data.kind == "profession" then
        local prof = data.profession
        if prof then
            GameTooltip:AddLine(prof.name or "Profession", 1, 0.82, 0)
            GameTooltip:AddDoubleLine("Skill", tostring(prof.skill or 0) .. " / " .. tostring(prof.max or 0), 1, 1, 1, 1, 1, 1)
            if prof.skillLine then
                GameTooltip:AddLine("Skill line ID: " .. tostring(prof.skillLine), 0.6, 0.6, 0.6)
            end
            if data.char then
                local book = AA:GetRecipeBook(data.char, prof.name)
                local count = 0
                if book and type(book.recipes) == "table" then
                    for _ in pairs(book.recipes) do count = count + 1 end
                end
                GameTooltip:AddDoubleLine("Stored recipes", tostring(count), 1, 1, 1, 1, 1, 1)
                if data.char.key == AA.currentCharacterKey and ProfessionHasNativeWindow(prof) then
                    if IsArchaeologyProfession(prof) then
                        GameTooltip:AddLine("Left-click: open Blizzard Archaeology.", 0.65, 0.85, 1.0)
                    else
                        GameTooltip:AddLine("Left-click: open Blizzard profession window.", 0.65, 0.85, 1.0)
                    end
                else
                    GameTooltip:AddLine("Left-click: open stored recipe snapshot", 0.65, 0.85, 1.0)
                end
            end
        else
            GameTooltip:AddLine(data.label or "Profession", 1, 0.82, 0)
            GameTooltip:AddLine("Not learned / no stored skill.", 0.75, 0.75, 0.75)
        end
    elseif data.kind == "quest" then
        local milestone = data.milestone
        local state = data.state
        GameTooltip:AddLine((state and state.title) or (milestone and milestone.title) or "Legendary quest", 1, 0.82, 0)
        if state then
            if state.state == "done" then
                GameTooltip:AddLine("Completed", 0.2, 1, 0.2)
            elseif state.state == "active" then
                GameTooltip:AddLine("In progress: " .. tostring(state.text or "active"), 1, 0.65, 0.15)
            elseif state.state == "skipped" then
                GameTooltip:AddLine("Optional breadcrumb skipped", 0.65, 0.78, 0.9)
            else
                GameTooltip:AddLine("Not completed / not currently in quest log", 1, 0.3, 0.3, true)
            end
            if state.questID then
                GameTooltip:AddLine("Quest ID: " .. tostring(state.questID), 0.65, 0.65, 0.65)
            end
        else
            GameTooltip:AddLine("No profile scan stored yet.", 0.65, 0.65, 0.65)
        end
    elseif data.kind == "collection" then
        GameTooltip:AddLine(data.label or "Collection", 1, 0.82, 0)
        GameTooltip:AddDoubleLine("Stored count", tostring(data.value or 0), 1, 1, 1, 1, 1, 1)

        local char = data.char
        local collectionType = data.collectionType
        local details, complete, captured, expected = CollectionSnapshotStatus(char, collectionType)
        if type(details) ~= "table" or not complete then
            GameTooltip:AddLine(" ")
            GameTooltip:AddLine("Detailed snapshot is incomplete or from an older Alternator version.", 1, 0.65, 0.2, true)
            GameTooltip:AddDoubleLine("Captured / expected", tostring(captured or 0) .. " / " .. tostring(expected or 0), 0.8, 0.8, 0.8, 1, 1, 1)
            GameTooltip:AddLine("Log this character once with Alternator 0.2.7+ to rebuild a verified snapshot.", 0.75, 0.75, 0.75, true)
        else
            local diff, incomplete = self:GetBestCollectionComparison(char, collectionType)
            GameTooltip:AddLine(" ")
            if diff then
                local other = diff.other
                local otherLabel = (other.name or "Unknown") .. "-" .. (other.realm or "UnknownRealm")
                GameTooltip:AddLine("Best comparison", 0.35, 0.85, 1.0)
                GameTooltip:AddDoubleLine(otherLabel, tostring(diff.otherValue), 0.92, 0.92, 0.92, 1, 1, 1)
                if diff.sameFaction then
                    GameTooltip:AddLine("Same-faction snapshot preferred.", 0.55, 0.75, 0.55)
                end

                local netText = diff.net > 0 and ("+" .. tostring(diff.net)) or tostring(diff.net)
                local netR, netG, netB = 1, 1, 1
                if diff.net > 0 then
                    netR, netG, netB = 0.3, 1, 0.3
                elseif diff.net < 0 then
                    netR, netG, netB = 1, 0.35, 0.35
                end
                GameTooltip:AddDoubleLine("Net count difference", netText, 1, 1, 1, netR, netG, netB)
                GameTooltip:AddDoubleLine("Only on this snapshot", tostring(diff.onlyCurrentUnits), 1, 1, 1, 1, 1, 1)
                GameTooltip:AddDoubleLine("Only on " .. (other.name or "other"), tostring(diff.onlyOtherUnits), 1, 1, 1, 1, 1, 1)

                if diff.exactExtra then
                    GameTooltip:AddLine(" ")
                    GameTooltip:AddLine("Confirmed extra " .. (collectionType == "mounts" and "mount(s)" or "companion(s)"), 0.25, 1.0, 0.25)
                    AddCollectionItemLines(diff.onlyCurrent, collectionType, 10)
                elseif diff.net > 0 then
                    GameTooltip:AddLine(" ")
                    GameTooltip:AddLine("The +" .. tostring(diff.net) .. " count cannot be assigned to one specific entry.", 1, 0.72, 0.20, true)
                    GameTooltip:AddLine("The two stored sets contain substitutions (often faction/class/profession-specific mounts), so several names differ in both directions.", 0.78, 0.78, 0.78, true)
                    if #diff.onlyCurrent > 0 then
                        GameTooltip:AddLine("Only on this snapshot (sample)", 0.35, 0.85, 1.0)
                        AddCollectionItemLines(diff.onlyCurrent, collectionType, 5)
                    end
                elseif diff.net == 0 and (diff.onlyCurrentUnits > 0 or diff.onlyOtherUnits > 0) then
                    GameTooltip:AddLine(" ")
                    GameTooltip:AddLine("Same total count, but the stored sets differ.", 1, 0.72, 0.20, true)
                    GameTooltip:AddLine("This is usually caused by faction/class/profession-specific collection entries rather than an actual count advantage.", 0.78, 0.78, 0.78, true)
                elseif diff.net < 0 and diff.exactMissing then
                    GameTooltip:AddLine(" ")
                    GameTooltip:AddLine("This character is missing exactly " .. tostring(-diff.net) .. " compared with " .. (other.name or "the comparison character") .. ".", 1, 0.55, 0.35, true)
                    AddCollectionItemLines(diff.onlyOther, collectionType, 10)
                else
                    GameTooltip:AddLine(" ")
                    GameTooltip:AddLine("No unambiguous single-entry difference can be inferred from these snapshots.", 0.72, 0.72, 0.72, true)
                end

                if incomplete and incomplete > 0 then
                    GameTooltip:AddLine(" ")
                    GameTooltip:AddLine(tostring(incomplete) .. " other shown character(s) were skipped because their detailed snapshot is incomplete.", 1, 0.55, 0.25, true)
                end
            else
                GameTooltip:AddLine("No other complete detailed snapshot is available in the selected realm scope.", 0.65, 0.65, 0.65, true)
                if incomplete and incomplete > 0 then
                    GameTooltip:AddLine(tostring(incomplete) .. " comparison character(s) need to be rescanned with Alternator 0.2.6+.", 1, 0.55, 0.25, true)
                end
            end
        end
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Comparison uses verified stored snapshots; mount names are normalized before matching.", 0.55, 0.55, 0.55, true)
    elseif data.kind == "character" then
        local char = data.char
        GameTooltip:AddLine((char.name or "Unknown") .. "-" .. (char.realm or "UnknownRealm"), 1, 0.82, 0)
        GameTooltip:AddDoubleLine("Level", tostring(char.level or 0), 1, 1, 1, 1, 1, 1)
        GameTooltip:AddDoubleLine("Last online", FormatTimestamp(char.lastSeen), 1, 1, 1, 1, 1, 1)
        GameTooltip:AddDoubleLine("Profile scan", FormatTimestamp(char.profileScanAt), 1, 1, 1, 1, 1, 1)
        GameTooltip:AddDoubleLine("Achievement scan", FormatTimestamp(char.lastScan), 1, 1, 1, 1, 1, 1)
    end
    GameTooltip:Show()
end

local function CreateDashboardCell(parent, column, isHeader)
    local cell
    if column.key == "remove" and not isHeader then
        cell = CreateFrame("Button", nil, parent)
    else
        cell = CreateFrame("Frame", nil, parent)
    end

    cell:SetSize(column.width, DASHBOARD_ROW_HEIGHT)
    cell.bg = cell:CreateTexture(nil, "BACKGROUND")
    cell.bg:SetAllPoints()
    cell.bg:SetTexture(1, 1, 1, 1)
    cell.bg:SetVertexColor(0.08, 0.08, 0.08, isHeader and 0.90 or 0.38)

    cell.text = cell:CreateFontString(nil, "OVERLAY", isHeader and "GameFontNormalSmall" or "GameFontHighlightSmall")
    cell.text:SetPoint("LEFT", cell, "LEFT", 4, 0)
    cell.text:SetPoint("RIGHT", cell, "RIGHT", -4, 0)
    if column.key == "name" or column.key == "realm" or column.key == "prof1" or column.key == "prof2" then
        cell.text:SetJustifyH("LEFT")
    else
        cell.text:SetJustifyH("CENTER")
    end

    if isHeader then
        cell.text:SetText(column.label)
        cell.text:SetTextColor(1, 0.82, 0)
    else
        cell:EnableMouse(true)
        cell:SetScript("OnEnter", function(self)
            AA:ShowDashboardCellTooltip(self)
        end)
        cell:SetScript("OnLeave", function()
            GameTooltip:Hide()
            AA:HideCollectionTooltip()
        end)

        -- Summary profession cells need the same hardware-secure /cast path as
        -- the Open buttons on the Professions tab. A normal OnMouseUp handler
        -- cannot open an online Blizzard TradeSkill window reliably on 5.4.8.
        if column.key == "prof1" or column.key == "prof2" or column.key == "cooking" or column.key == "firstAid" then
            local secure = CreateFrame("Button", nil, cell, "SecureActionButtonTemplate")
            secure:SetAllPoints(cell)
            secure:SetFrameLevel(cell:GetFrameLevel() + 12)
            secure:EnableMouse(true)
            secure:RegisterForClicks("AnyDown", "AnyUp")
            secure:SetScript("OnEnter", function()
                AA:ShowDashboardCellTooltip(cell)
            end)
            secure:SetScript("OnLeave", function()
                GameTooltip:Hide()
                AA:HideCollectionTooltip()
            end)
            secure:Hide()
            cell.secureProfessionButton = secure
        end
    end

    return cell
end

local function PositionDashboardCells(row, view)
    for _, column in ipairs(DASHBOARD_COLUMNS) do
        local cell = row.cells[column.key]
        cell:Hide()
        cell:ClearAllPoints()
    end

    local previous
    for _, column in ipairs(GetDashboardColumns(view)) do
        local cell = row.cells[column.key]
        cell:Show()
        cell:SetSize(column.width, DASHBOARD_ROW_HEIGHT)
        if previous then
            cell:SetPoint("LEFT", previous, "RIGHT", 0, 0)
        else
            cell:SetPoint("LEFT", row, "LEFT", 0, 0)
        end
        previous = cell
    end
end

local function ConfigureSummaryProfessionCell(cell, char, prof, allowSnapshot)
    if not cell then return end
    local secure = cell.secureProfessionButton
    local inCombat = type(InCombatLockdown) == "function" and InCombatLockdown()

    -- Always remove the ordinary click first; the branch below installs exactly
    -- one action path for the current state.
    cell:SetScript("OnMouseUp", nil)

    if secure and not inCombat then
        AA:ClearSecureProfessionButton(secure)
        secure:Hide()
    end

    if not prof then return end

    if char.key ~= AA.currentCharacterKey then
        -- Offline characters continue to use Alternator's saved recipe snapshot.
        if allowSnapshot then
            cell:SetScript("OnMouseUp", function()
                AA:OpenStoredProfessionForCharacter(char.key, prof)
            end)
        end
        return
    end

    if inCombat then return end

    if IsArchaeologyProfession(prof) then
        cell:SetScript("OnMouseUp", function()
            AA:OpenNativeProfessionForCharacter(char.key, prof)
        end)
        return
    end

    if ProfessionHasNativeWindow(prof) and secure then
        secure.profession = prof
        secure.charKey = char.key
        if AA:ConfigureSecureProfessionButton(secure, prof) then
            -- Summary used to register both mouse-down and mouse-up through the
            -- shared helper. On some 5.4.8 clients that executes /cast twice,
            -- opening the TradeSkill frame and immediately toggling it closed.
            -- One hardware click on release is sufficient and deterministic here.
            secure:RegisterForClicks("LeftButtonUp")
            secure:Show()
        end
    end
end

function AA:PopulateDashboardRow(row, char)
    row.charKey = char and char.key or nil
    if not char then
        row:Hide()
        return
    end

    row:Show()
    local isCurrent = char.key == self.currentCharacterKey

    local classColor = char.class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[char.class]
    local nameColor = classColor or { r = 1, g = 1, b = 1 }

    local nameCell = row.cells.name
    nameCell.text:SetText((char.name or "Unknown") .. (isCurrent and " (you)" or ""))
    nameCell.text:SetTextColor(nameColor.r or 1, nameColor.g or 1, nameColor.b or 1)
    nameCell.data = { kind = "character", char = char }
    SetCellBackground(nameCell, { 0.12, 0.12, 0.12, 0.45 })

    row.cells.realm.text:SetText(char.realm or "?")
    row.cells.realm.text:SetTextColor(0.92, 0.92, 0.92)
    row.cells.realm.data = { kind = "character", char = char }
    SetCellBackground(row.cells.realm, { 0.12, 0.12, 0.12, 0.45 })

    row.cells.level.text:SetText(tostring(char.level or 0))
    row.cells.level.data = { kind = "character", char = char }
    SetCellBackground(row.cells.level, { 0.12, 0.12, 0.12, 0.45 })

    local profs = char.professions or {}
    local p1 = profs.primary1
    local p2 = profs.primary2

    row.cells.prof1.text:SetText(ProfessionDisplayName(p1))
    row.cells.prof1.data = { kind = "profession", profession = p1, label = "Primary profession 1", char = char }
    ConfigureSummaryProfessionCell(row.cells.prof1, char, p1, true)
    SetCellBackground(row.cells.prof1, ProfessionStateColor(p1, false))

    row.cells.prof1skill.text:SetText(p1 and tostring(p1.skill or 0) or "-")
    row.cells.prof1skill.data = { kind = "profession", profession = p1, label = "Primary profession 1" }
    SetCellBackground(row.cells.prof1skill, ProfessionStateColor(p1, false))

    row.cells.prof2.text:SetText(ProfessionDisplayName(p2))
    row.cells.prof2.data = { kind = "profession", profession = p2, label = "Primary profession 2", char = char }
    ConfigureSummaryProfessionCell(row.cells.prof2, char, p2, true)
    SetCellBackground(row.cells.prof2, ProfessionStateColor(p2, false))

    row.cells.prof2skill.text:SetText(p2 and tostring(p2.skill or 0) or "-")
    row.cells.prof2skill.data = { kind = "profession", profession = p2, label = "Primary profession 2" }
    SetCellBackground(row.cells.prof2skill, ProfessionStateColor(p2, false))

    local secondary = {
        arch = { prof = profs.archaeology, label = "Archaeology", recipes = false },
        fishing = { prof = profs.fishing, label = "Fishing", recipes = false },
        cooking = { prof = profs.cooking, label = "Cooking", recipes = true },
        firstAid = { prof = profs.firstAid, label = "First Aid", recipes = true },
    }
    for cellKey, data in pairs(secondary) do
        local cell = row.cells[cellKey]
        cell.text:SetText(tostring(data.prof and data.prof.skill or 0))
        cell.data = { kind = "profession", profession = data.prof, label = data.label, char = data.recipes and char or nil }
        if data.recipes and data.prof then
            ConfigureSummaryProfessionCell(cell, char, data.prof, true)
        else
            cell:SetScript("OnMouseUp", nil)
            if cell.secureProfessionButton and not (type(InCombatLockdown) == "function" and InCombatLockdown()) then
                AA:ClearSecureProfessionButton(cell.secureProfessionButton)
                cell.secureProfessionButton:Hide()
            end
        end
        SetCellBackground(cell, ProfessionStateColor(data.prof, true))
    end

    local legendary = char.legendary or {}
    for _, column in ipairs(DASHBOARD_COLUMNS) do
        if column.milestone then
            local cell = row.cells[column.key]
            local milestone = FindMilestoneByKey(column.milestone)
            local state = legendary[column.milestone]
            if not char.profileScanned then
                cell.text:SetText("?")
                cell.text:SetTextColor(0.75, 0.75, 0.75)
                SetCellBackground(cell, PROF_STATE_COLORS.none)
            elseif state and state.state == "done" then
                cell.text:SetText("done")
                cell.text:SetTextColor(0.75, 1, 0.75)
                SetCellBackground(cell, QUEST_STATE_COLORS.done)
            elseif state and state.state == "active" then
                cell.text:SetText(state.text and state.text ~= "" and state.text or "active")
                cell.text:SetTextColor(1, 0.95, 0.70)
                SetCellBackground(cell, QUEST_STATE_COLORS.active)
            else
                cell.text:SetText("")
                cell.text:SetTextColor(1, 0.85, 0.85)
                SetCellBackground(cell, QUEST_STATE_COLORS.none)
            end
            cell.data = { kind = "quest", milestone = milestone, state = state }
        end
    end

    local collections = char.collections or {}
    row.cells.mounts.text:SetText(char.collectionsScannedAt and tostring(collections.mounts or 0) or "?")
    row.cells.mounts.text:SetTextColor(0.95, 0.95, 0.95)
    row.cells.mounts.data = { kind = "collection", label = "Mounts", value = collections.mounts or 0, char = char, collectionType = "mounts" }
    SetCellBackground(row.cells.mounts, { 0.12, 0.12, 0.12, 0.45 })

    row.cells.companions.text:SetText(char.collectionsScannedAt and tostring(collections.companions or 0) or "?")
    row.cells.companions.text:SetTextColor(0.95, 0.95, 0.95)
    row.cells.companions.data = { kind = "collection", label = "Companions / battle pets", value = collections.companions or 0, char = char, collectionType = "companions" }
    SetCellBackground(row.cells.companions, { 0.12, 0.12, 0.12, 0.45 })

    local remove = row.cells.remove
    remove.data = nil
    remove.text:SetText(isCurrent and "" or "X")
    remove.text:SetTextColor(1, 0.30, 0.30)
    SetCellBackground(remove, { 0.12, 0.12, 0.12, 0.45 })
    if isCurrent then
        remove:Disable()
        remove:EnableMouse(false)
    else
        remove:Enable()
        remove:EnableMouse(true)
        remove:SetScript("OnClick", function()
            AA:RequestRemoveCharacter(char.key)
        end)
        remove:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:AddLine("Remove " .. (char.name or "character"), 1, 0.3, 0.3)
            GameTooltip:AddLine("Deletes only Alternator's stored data for this character.", 0.7, 0.7, 0.7, true)
            GameTooltip:Show()
        end)
        remove:SetScript("OnLeave", function()
            GameTooltip:Hide()
        end)
    end
end

local function DashboardVisibleRowCount(frame)
    if not frame then
        return 1
    end
    local available = (frame:GetHeight() or DASHBOARD_HEIGHT) - 175
    local rows = math.floor(available / DASHBOARD_ROW_HEIGHT)
    if rows < 1 then rows = 1 end
    if rows > DASHBOARD_MAX_ROWS then rows = DASHBOARD_MAX_ROWS end
    return rows
end

function AA:ConfigureDashboardLayout()
    local frame = self.dashboardFrame
    if not frame or not frame.header then
        return
    end

    local view = self:GetDashboardView()
    local width = DashboardTotalWidth(view)
    frame.header:SetSize(width, DASHBOARD_ROW_HEIGHT)
    PositionDashboardCells(frame.header, view)
    for _, row in ipairs(frame.rows or {}) do
        row:SetSize(width, DASHBOARD_ROW_HEIGHT)
        PositionDashboardCells(row, view)
    end

    if self.dashboardViewDropDown then
        UIDropDownMenu_SetText(self.dashboardViewDropDown, self:GetDashboardViewLabel())
    end

    local showRecipeSearch = view == "professions"
    if frame.recipeSearchLabel then if showRecipeSearch then frame.recipeSearchLabel:Show() else frame.recipeSearchLabel:Hide() end end
    if frame.recipeSearchBox then if showRecipeSearch then frame.recipeSearchBox:Show() else frame.recipeSearchBox:Hide() end end
    if frame.recipeSearchButton then if showRecipeSearch then frame.recipeSearchButton:Show() else frame.recipeSearchButton:Hide() end end
    if frame.recipeGuideButton then if showRecipeSearch then frame.recipeGuideButton:Show() else frame.recipeGuideButton:Hide() end end

    frame.status:ClearAllPoints()
    frame.status:SetPoint("TOPLEFT", frame, "TOPLEFT", 18, -78)
    -- Status always owns its whole row. Profession recipe controls live on
    -- a dedicated row below so long realm/profile text never collides with them.
    frame.status:SetPoint("RIGHT", frame, "RIGHT", -18, 0)
end

function AA:RefreshDashboard(resetScroll)
    local frame = self.dashboardFrame
    if not frame then
        return
    end

    self:ConfigureDashboardLayout()
    local chars = self:GetDashboardCharactersSorted()
    local profileCount = 0
    for _, char in ipairs(chars) do
        if char.profileScanned then
            profileCount = profileCount + 1
        end
    end

    frame.status:SetText(string.format(
        "%d character(s) shown in selected realms - %d profile scan(s) complete - Realms: %s",
        #chars, profileCount, self:GetRealmFilterLabel()
    ))

    if resetScroll and frame.scroll then
        FauxScrollFrame_SetOffset(frame.scroll, 0)
        if frame.scroll.ScrollBar then
            frame.scroll.ScrollBar:SetValue(0)
        end
    end

    local visibleRows = DashboardVisibleRowCount(frame)
    local offset = frame.scroll and FauxScrollFrame_GetOffset(frame.scroll) or 0
    if frame.scroll then
        FauxScrollFrame_Update(frame.scroll, #chars, visibleRows, DASHBOARD_ROW_HEIGHT)
        offset = FauxScrollFrame_GetOffset(frame.scroll) or 0
    end

    for i = 1, DASHBOARD_MAX_ROWS do
        local row = frame.rows[i]
        if i <= visibleRows then
            local char = chars[offset + i]
            if char then
                self:PopulateDashboardRow(row, char)
            else
                row:Hide()
            end
        else
            row:Hide()
        end
    end

    if #chars == 0 then
        frame.emptyText:Show()
        frame.emptyText:SetText("No character profiles in the selected realm(s). Log a character once so Alternator can build its snapshot.")
    else
        frame.emptyText:Hide()
    end
end

function AA:CreateDashboardFrame()
    if self.dashboardFrame then
        return self.dashboardFrame
    end

    local frame = CreateFrame("Frame", "AlternatorDashboardFrame", UIParent)
    local savedSize = self.db and self.db.settings and self.db.settings.dashboardSize or nil
    local initialWidth = savedSize and tonumber(savedSize.width) or DASHBOARD_WIDTH
    local initialHeight = savedSize and tonumber(savedSize.height) or DASHBOARD_HEIGHT
    frame:SetSize(initialWidth, initialHeight)
    frame:SetPoint("CENTER", UIParent, "CENTER", 0, 20)
    frame:SetFrameStrata("DIALOG")
    if frame.SetToplevel then frame:SetToplevel(true) end
    frame:SetClampedToScreen(true)
    frame:SetMovable(true)
    frame:SetResizable(true)
    if frame.SetMinResize then frame:SetMinResize(DASHBOARD_MIN_WIDTH, DASHBOARD_MIN_HEIGHT) end
    if frame.SetMaxResize then
        local maxW = math.min(DASHBOARD_MAX_WIDTH, (UIParent and UIParent:GetWidth() or DASHBOARD_MAX_WIDTH) - 20)
        local maxH = math.min(DASHBOARD_MAX_HEIGHT, (UIParent and UIParent:GetHeight() or DASHBOARD_MAX_HEIGHT) - 20)
        frame:SetMaxResize(math.max(DASHBOARD_MIN_WIDTH, maxW), math.max(DASHBOARD_MIN_HEIGHT, maxH))
    end
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", function(self)
        self:StartMoving()
    end)
    frame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
    end)

    frame:SetBackdrop({
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true,
        tileSize = 32,
        edgeSize = 32,
        insets = { left = 11, right = 12, top = 12, bottom = 11 },
    })
    local solidBG = frame:CreateTexture(nil, "BACKGROUND")
    solidBG:SetPoint("TOPLEFT", frame, "TOPLEFT", 11, -12)
    solidBG:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -12, 11)
    solidBG:SetTexture(0.025, 0.025, 0.025, 1)
    frame.solidBG = solidBG

    local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOPLEFT", frame, "TOPLEFT", 18, -15)
    title:SetText("Alternator - Character Overview")

    local version = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    version:SetPoint("LEFT", title, "RIGHT", 10, 0)
    version:SetText("v" .. VERSION)
    version:SetTextColor(0.65, 0.65, 0.65)

    local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -5, -5)

    local scan = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    scan:SetSize(105, 22)
    scan:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -34, -42)
    scan:SetText("Scan current")
    scan:SetScript("OnClick", function()
        AA:ScanCurrentCharacterProfile(false)
        AA:StartScan(true)
    end)

    local realmLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    realmLabel:SetPoint("TOPLEFT", frame, "TOPLEFT", 18, -46)
    realmLabel:SetText("Realms:")

    local realmDropDown = CreateFrame("Frame", "AlternatorDashboardRealmDropDown", frame, "UIDropDownMenuTemplate")
    realmDropDown:SetPoint("LEFT", realmLabel, "RIGHT", -12, -2)
    self:SetupRealmDropDown(realmDropDown, 125)
    self.dashboardRealmDropDown = realmDropDown

    local viewLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    viewLabel:SetPoint("LEFT", realmDropDown, "RIGHT", 12, 2)
    viewLabel:SetText("View:")

    local viewDropDown = CreateFrame("Frame", "AlternatorDashboardViewDropDown", frame, "UIDropDownMenuTemplate")
    viewDropDown:SetPoint("LEFT", viewLabel, "RIGHT", -12, -2)
    self:SetupDashboardViewDropDown(viewDropDown, 140)
    self.dashboardViewDropDown = viewDropDown

    local sortLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    sortLabel:SetPoint("RIGHT", scan, "LEFT", -185, 0)
    sortLabel:SetText("Sort:")

    local sortDropDown = CreateFrame("Frame", "AlternatorDashboardSortDropDown", frame, "UIDropDownMenuTemplate")
    sortDropDown:SetPoint("LEFT", sortLabel, "RIGHT", -12, -2)
    self:SetupSortDropDown(sortDropDown, 145)
    self.dashboardSortDropDown = sortDropDown

    local status = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    status:SetPoint("TOPLEFT", frame, "TOPLEFT", 18, -78)
    status:SetPoint("RIGHT", frame, "RIGHT", -18, 0)
    status:SetJustifyH("LEFT")
    status:SetTextColor(0.85, 0.85, 0.85)
    frame.status = status

    local recipeGuideButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    recipeGuideButton:SetSize(82, 20)
    recipeGuideButton:SetPoint("TOPLEFT", frame, "TOPLEFT", 18, -99)
    recipeGuideButton:SetText("Recipe scan")
    recipeGuideButton:SetScript("OnClick", function() AA:ShowRecipeGuide() end)
    frame.recipeGuideButton = recipeGuideButton

    local recipeSearchLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    recipeSearchLabel:SetPoint("LEFT", recipeGuideButton, "RIGHT", 18, 0)
    recipeSearchLabel:SetText("Search recipes:")
    frame.recipeSearchLabel = recipeSearchLabel

    local recipeSearchBox = CreateFrame("EditBox", "AlternatorRecipeSearchBox", frame, "InputBoxTemplate")
    recipeSearchBox:SetSize(190, 20)
    recipeSearchBox:SetPoint("LEFT", recipeSearchLabel, "RIGHT", 8, 0)
    recipeSearchBox:SetAutoFocus(false)
    recipeSearchBox:SetScript("OnEnterPressed", function(self)
        AA:SearchRecipes(self:GetText() or "")
        self:ClearFocus()
    end)
    recipeSearchBox:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    frame.recipeSearchBox = recipeSearchBox

    local recipeSearchButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    recipeSearchButton:SetSize(56, 20)
    recipeSearchButton:SetPoint("LEFT", recipeSearchBox, "RIGHT", 6, 0)
    recipeSearchButton:SetText("Search")
    recipeSearchButton:SetScript("OnClick", function() AA:SearchRecipes(recipeSearchBox:GetText() or "") end)
    frame.recipeSearchButton = recipeSearchButton

    local tableLeft = 18
    local header = CreateFrame("Frame", nil, frame)
    header:SetPoint("TOPLEFT", frame, "TOPLEFT", tableLeft, -128)
    header:SetSize(DashboardTotalWidth(self:GetDashboardView()), DASHBOARD_ROW_HEIGHT)
    header.cells = {}
    for _, column in ipairs(DASHBOARD_COLUMNS) do
        header.cells[column.key] = CreateDashboardCell(header, column, true)
    end
    PositionDashboardCells(header, self:GetDashboardView())
    frame.header = header

    local scroll = CreateFrame("ScrollFrame", "AlternatorDashboardScrollFrame", frame, "FauxScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, -2)
    scroll:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -30, 24)
    scroll:SetScript("OnVerticalScroll", function(self, offset)
        FauxScrollFrame_OnVerticalScroll(self, offset, DASHBOARD_ROW_HEIGHT, function()
            AA:RefreshDashboard(false)
        end)
    end)
    scroll:EnableMouseWheel(true)
    scroll:SetScript("OnMouseWheel", function(self, delta)
        local scrollBar = self.ScrollBar or _G[self:GetName() .. "ScrollBar"]
        if scrollBar then
            local step = DASHBOARD_ROW_HEIGHT * 3
            scrollBar:SetValue(scrollBar:GetValue() - (delta * step))
        end
    end)
    frame.scroll = scroll

    frame.rows = {}
    for i = 1, DASHBOARD_MAX_ROWS do
        local row = CreateFrame("Frame", nil, frame)
        row:SetSize(DashboardTotalWidth(self:GetDashboardView()), DASHBOARD_ROW_HEIGHT)
        row:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, -2 - ((i - 1) * DASHBOARD_ROW_HEIGHT))
        row.cells = {}
        for _, column in ipairs(DASHBOARD_COLUMNS) do
            row.cells[column.key] = CreateDashboardCell(row, column, false)
        end
        PositionDashboardCells(row, self:GetDashboardView())
        frame.rows[i] = row
    end

    local resizeGrip = CreateFrame("Button", nil, frame)
    resizeGrip:SetSize(18, 18)
    resizeGrip:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -5, 5)
    resizeGrip:SetFrameLevel(frame:GetFrameLevel() + 10)
    resizeGrip:EnableMouse(true)
    local gripNormal = resizeGrip:CreateTexture(nil, "ARTWORK")
    gripNormal:SetAllPoints(resizeGrip)
    gripNormal:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    resizeGrip.normalTexture = gripNormal
    local gripHighlight = resizeGrip:CreateTexture(nil, "HIGHLIGHT")
    gripHighlight:SetAllPoints(resizeGrip)
    gripHighlight:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    local gripPushed = resizeGrip:CreateTexture(nil, "ARTWORK")
    gripPushed:SetAllPoints(resizeGrip)
    gripPushed:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    gripPushed:Hide()
    resizeGrip.pushedTexture = gripPushed
    resizeGrip:SetScript("OnMouseDown", function(self, button)
        if button == "LeftButton" then
            if self:GetParent().Raise then self:GetParent():Raise() end
            self.normalTexture:Hide()
            self.pushedTexture:Show()
            self:GetParent():StartSizing("BOTTOMRIGHT")
        end
    end)
    resizeGrip:SetScript("OnMouseUp", function(self, button)
        if button == "LeftButton" then
            local parent = self:GetParent()
            parent:StopMovingOrSizing()
            self.pushedTexture:Hide()
            self.normalTexture:Show()
            if AA.db and AA.db.settings then
                AA.db.settings.dashboardSize = AA.db.settings.dashboardSize or {}
                AA.db.settings.dashboardSize.width = math.floor(parent:GetWidth() + 0.5)
                AA.db.settings.dashboardSize.height = math.floor(parent:GetHeight() + 0.5)
            end
            AA:RefreshDashboard(false)
        end
    end)
    resizeGrip:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT")
        GameTooltip:AddLine("Resize Alternator", 1, 0.82, 0)
        GameTooltip:AddLine("Drag this corner to change the overview width and height.", 0.8, 0.8, 0.8, true)
        GameTooltip:Show()
    end)
    resizeGrip:SetScript("OnLeave", function() GameTooltip:Hide() end)
    frame.resizeGrip = resizeGrip

    local emptyText = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    emptyText:SetPoint("CENTER", frame, "CENTER", 0, -30)
    emptyText:SetWidth(620)
    emptyText:SetJustifyH("CENTER")
    emptyText:SetTextColor(0.75, 0.75, 0.75)
    frame.emptyText = emptyText

    frame:SetScript("OnShow", function(self)
        if self.Raise then self:Raise() end
        AA:RefreshDashboard(true)
    end)
    frame:SetScript("OnMouseDown", function(self)
        if self.Raise then self:Raise() end
    end)
    frame:Hide()

    if UISpecialFrames then
        local alreadyAdded = false
        for _, name in ipairs(UISpecialFrames) do
            if name == "AlternatorDashboardFrame" then
                alreadyAdded = true
                break
            end
        end
        if not alreadyAdded then
            table.insert(UISpecialFrames, "AlternatorDashboardFrame")
        end
    end

    self.dashboardFrame = frame
    frame:SetScript("OnSizeChanged", function(self)
        if AA.dashboardFrame == self then
            AA:RefreshDashboard(false)
        end
    end)
    self:ConfigureDashboardLayout()
    self:RefreshSortDropDowns()
    self:RefreshRealmDropDowns()
    return frame
end

function AA:ToggleDashboard()
    if not self:IsEnabled() then
        Print("Alternator is disabled. Right-click the minimap button or use /alt options to enable it.")
        return
    end

    local frame = self:CreateDashboardFrame()
    if frame:IsShown() then
        frame:Hide()
    else
        frame:Show()
        self:RefreshDashboard(true)
    end
end

function AA:UpdateMinimapButtonPosition()
    local button = self.minimapButton
    if not button or not self.db or not self.db.settings then
        return
    end

    local minimap = self.db.settings.minimap or {}
    local x = tonumber(minimap.x) or -74
    local y = tonumber(minimap.y) or -74
    button:ClearAllPoints()
    button:SetPoint("CENTER", Minimap, "CENTER", x, y)
end

function AA:ResetMinimapButtonPosition()
    if not self.db then
        self:InitializeDatabase()
    end
    self.db.settings.minimap = self.db.settings.minimap or {}
    self.db.settings.minimap.x = -74
    self.db.settings.minimap.y = -74
    self:UpdateMinimapButtonPosition()
end

function AA:CreateMinimapButton()
    if self.minimapButton or not Minimap then
        return self.minimapButton
    end

    local button = CreateFrame("Button", "AlternatorMinimapButton", Minimap)
    button:SetSize(34, 34)
    button:SetFrameStrata("MEDIUM")
    button:SetFrameLevel((Minimap:GetFrameLevel() or 0) + 8)
    button:SetMovable(true)
    button:EnableMouse(true)
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    button:RegisterForDrag("LeftButton")

    -- A roster/group icon communicates "alts / characters" much better than
    -- the generic book used by v0.1.0. This texture exists in the MoP-era UI.
    local icon = button:CreateTexture(nil, "BACKGROUND")
    icon:SetSize(23, 23)
    icon:SetPoint("CENTER", button, "CENTER", 0, 0)
    icon:SetTexture("Interface\\Icons\\Achievement_GuildPerk_EverybodysFriend")
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    button.icon = icon

    local border = button:CreateTexture(nil, "OVERLAY")
    border:SetSize(54, 54)
    border:SetPoint("CENTER", button, "CENTER", 0, 0)
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")

    local highlight = button:CreateTexture(nil, "HIGHLIGHT")
    highlight:SetSize(31, 31)
    highlight:SetPoint("CENTER")
    highlight:SetTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    highlight:SetBlendMode("ADD")

    button:SetScript("OnClick", function(self, mouseButton)
        -- Suppress the click generated immediately after a drag.
        if self.lastDragStop and (GetTime() - self.lastDragStop) < 0.20 then
            return
        end
        if mouseButton == "RightButton" then
            AA:OpenOptions()
        else
            AA:ToggleDashboard()
        end
    end)

    button:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("Alternator", 1, 0.82, 0)
        GameTooltip:AddLine("Left-click: character overview", 1, 1, 1)
        GameTooltip:AddLine("Right-click: settings", 1, 1, 1)
        GameTooltip:AddLine("Hold left button and drag: move", 0.7, 0.7, 0.7)
        GameTooltip:Show()
    end)
    button:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)

    button:SetScript("OnDragStart", function(self)
        self.dragging = true
        self:SetScript("OnUpdate", function(btn)
            local mx, my = Minimap:GetCenter()
            if not mx or not my then
                return
            end

            local scale = UIParent:GetEffectiveScale()
            local cx, cy = GetCursorPosition()
            cx, cy = cx / scale, cy / scale

            local dx, dy = cx - mx, cy - my
            local distance = math.sqrt((dx * dx) + (dy * dy))
            if distance < 1 then
                distance = 1
            end

            local radius = ((Minimap:GetWidth() or 140) * 0.5) + 10
            local x = (dx / distance) * radius
            local y = (dy / distance) * radius

            btn:ClearAllPoints()
            btn:SetPoint("CENTER", Minimap, "CENTER", x, y)

            AA.db.settings.minimap = AA.db.settings.minimap or {}
            AA.db.settings.minimap.x = x
            AA.db.settings.minimap.y = y
        end)
    end)

    button:SetScript("OnDragStop", function(self)
        self.dragging = nil
        self.lastDragStop = GetTime()
        self:SetScript("OnUpdate", nil)
    end)

    self.minimapButton = button
    self:UpdateMinimapButtonPosition()
    if not self:IsMinimapButtonShown() then
        button:Hide()
    end
    return button
end

-- -----------------------------------------------------------------------------
-- Embedded "Missing" tab
-- -----------------------------------------------------------------------------
-- Missing follows the same realm comparison filter as Unique/Oldest.
-- Its catalogue is read from the 5.4.8 client itself. GetCategoryNumAchievements
-- with includeAll=true exposes achievements that are normally hidden while
-- incomplete, including Feats of Strength (category 81), so the list does not
-- depend on a brittle hand-maintained achievement-ID database.

local function NormalizeAchievementCategoryParent(parentID)
    parentID = tonumber(parentID)
    if not parentID or parentID < 0 or parentID > 1000000 then
        return -1
    end
    return parentID
end

local function EnsureMissingCategoryNode(categoryMap, categoryID, order)
    categoryID = tonumber(categoryID)
    if not categoryID then
        return nil
    end

    local node = categoryMap[categoryID]
    if not node then
        local title, parentID
        if type(GetCategoryInfo) == "function" then
            title, parentID = GetCategoryInfo(categoryID)
        end
        node = {
            id = categoryID,
            title = title or ("Category " .. tostring(categoryID)),
            parent = NormalizeAchievementCategoryParent(parentID),
            order = tonumber(order) or 999999,
            children = {},
            achievements = {},
            missingAchievements = {},
            missingTotal = 0,
        }
        categoryMap[categoryID] = node
    else
        if order and (not node.order or order < node.order) then
            node.order = order
        end
        if type(GetCategoryInfo) == "function" then
            local title, parentID = GetCategoryInfo(categoryID)
            if title and title ~= "" then node.title = title end
            node.parent = NormalizeAchievementCategoryParent(parentID)
        end
    end
    return node
end

local function MissingNodeSort(a, b)
    local ao = tonumber(a and a.order) or 999999
    local bo = tonumber(b and b.order) or 999999
    if ao ~= bo then return ao < bo end
    local an = Lower(a and a.title or "")
    local bn = Lower(b and b.title or "")
    if an ~= bn then return an < bn end
    return (tonumber(a and a.id) or 0) < (tonumber(b and b.id) or 0)
end

function AA:BuildMissingCatalogue(force)
    if self.missingCatalogueReady and self.missingCatalogue and not force then
        return self.missingCatalogue
    end

    local categoryIDs = type(GetCategoryList) == "function" and GetCategoryList() or nil
    if type(categoryIDs) ~= "table" or #categoryIDs == 0 then
        self.missingCatalogueReady = false
        return nil
    end

    local orderedCategories = {}
    local categorySeen = {}
    for i, categoryID in ipairs(categoryIDs) do
        categoryID = tonumber(categoryID)
        if categoryID and not categorySeen[categoryID] then
            categorySeen[categoryID] = true
            table.insert(orderedCategories, categoryID)
        end
    end

    -- Category 81 is Feats of Strength. Some modified 5.4.8 UIs can omit it
    -- from their visible category list, so explicitly include it when the API
    -- knows the category. The achievement enumeration still comes from the
    -- client's own data and not from a hard-coded list of Feat IDs.
    if not categorySeen[81] and type(GetCategoryInfo) == "function" then
        local featTitle = GetCategoryInfo(81)
        if featTitle and featTitle ~= "" then
            categorySeen[81] = true
            table.insert(orderedCategories, 81)
        end
    end

    local categoryMap = {}
    for i, categoryID in ipairs(orderedCategories) do
        EnsureMissingCategoryNode(categoryMap, categoryID, i)
    end

    -- Ensure every referenced parent exists so the display can reproduce the
    -- Blizzard category hierarchy even when GetCategoryList() omits a parent.
    local pendingParents = {}
    for _, node in pairs(categoryMap) do
        if node.parent and node.parent >= 0 and not categoryMap[node.parent] then
            pendingParents[node.parent] = true
        end
    end
    for parentID in pairs(pendingParents) do
        EnsureMissingCategoryNode(categoryMap, parentID, 999000 + parentID)
    end

    local achievements = {}
    local achievementSeen = {}
    local sequence = 0

    for _, categoryID in ipairs(orderedCategories) do
        local total = 0
        if type(GetCategoryNumAchievements) == "function" then
            local categoryTotal = GetCategoryNumAchievements(categoryID, true)
            total = tonumber(categoryTotal) or 0
        end

        for index = 1, total do
            local id, name, points, completed, month, day, year, description, flags, icon, rewardText, isGuild, wasEarnedByMe, earnedBy, isStatistic = GetAchievementInfo(categoryID, index)
            id = tonumber(id)
            if id and not achievementSeen[id] and not isGuild and not isStatistic then
                achievementSeen[id] = true
                sequence = sequence + 1

                local actualCategoryID = categoryID
                if type(GetAchievementCategory) == "function" then
                    local ok, value = pcall(GetAchievementCategory, id)
                    if ok and tonumber(value) then
                        actualCategoryID = tonumber(value)
                    end
                end

                local node = EnsureMissingCategoryNode(categoryMap, actualCategoryID, 999999)
                local entry = {
                    id = id,
                    name = name or ("Achievement #" .. tostring(id)),
                    points = tonumber(points) or 0,
                    icon = icon,
                    categoryID = actualCategoryID,
                    order = sequence,
                    flags = flags,
                    description = description,
                    rewardText = rewardText,
                }
                table.insert(achievements, entry)
                table.insert(node.achievements, entry)
            end
        end
    end

    -- Feats of Strength are intentionally different from ordinary achievement
    -- categories: the category listing can expose only Feats already earned by
    -- the current account.  For Missing we need the *client catalogue*, not
    -- just the visible/earned subset.  The 5.4.8 client can resolve known
    -- achievement IDs directly, so probe the MoP-era ID range once, keep only
    -- achievements whose actual category is 81, and merge them into the same
    -- catalogue.  This remains client-driven and avoids a brittle manual list.
    if type(GetAchievementInfo) == "function" and type(GetAchievementCategory) == "function" then
        local featNode = EnsureMissingCategoryNode(categoryMap, 81, #orderedCategories + 1)
        local probeMax = MISSING_FOS_SCAN_MAX_ID
        for achievementID = 1, probeMax do
            if not achievementSeen[achievementID] then
                local id, name, points, completed, month, day, year, description, flags, icon, rewardText, isGuild, wasEarnedByMe, earnedBy, isStatistic = GetAchievementInfo(achievementID)
                id = tonumber(id)
                if id and id == achievementID and not achievementSeen[id] and not isGuild and not isStatistic then
                    local ok, actualCategoryID = pcall(GetAchievementCategory, id)
                    actualCategoryID = ok and tonumber(actualCategoryID) or nil
                    if actualCategoryID == 81 then
                        achievementSeen[id] = true
                        sequence = sequence + 1
                        local entry = {
                            id = id,
                            name = name or ("Achievement #" .. tostring(id)),
                            points = tonumber(points) or 0,
                            icon = icon,
                            categoryID = 81,
                            order = sequence,
                            flags = flags,
                            description = description,
                            rewardText = rewardText,
                        }
                        table.insert(achievements, entry)
                        table.insert(featNode.achievements, entry)
                    end
                end
            end
        end
    end

    -- A category discovered from an achievement can itself reference a parent
    -- that was not in the original list. Resolve those parents before linking.
    local addedParent = true
    while addedParent do
        addedParent = false
        local toAdd = {}
        for _, node in pairs(categoryMap) do
            if node.parent and node.parent >= 0 and not categoryMap[node.parent] then
                toAdd[node.parent] = true
            end
        end
        for parentID in pairs(toAdd) do
            EnsureMissingCategoryNode(categoryMap, parentID, 999000 + parentID)
            addedParent = true
        end
    end

    for _, node in pairs(categoryMap) do
        node.children = {}
    end

    local topCategories = {}
    for _, node in pairs(categoryMap) do
        local parent = node.parent and categoryMap[node.parent] or nil
        if parent and parent ~= node then
            table.insert(parent.children, node)
        else
            table.insert(topCategories, node)
        end
    end

    for _, node in pairs(categoryMap) do
        table.sort(node.children, MissingNodeSort)
        table.sort(node.achievements, function(a, b)
            local ao = tonumber(a.order) or 999999
            local bo = tonumber(b.order) or 999999
            if ao ~= bo then return ao < bo end
            return Lower(a.name) < Lower(b.name)
        end)
    end
    table.sort(topCategories, MissingNodeSort)

    local featTotal = 0
    for _, entry in ipairs(achievements) do
        if tonumber(entry.categoryID) == 81 then
            featTotal = featTotal + 1
        end
    end

    self.missingCatalogue = {
        categories = categoryMap,
        topCategories = topCategories,
        achievements = achievements,
        total = #achievements,
        featTotal = featTotal,
        regularTotal = math.max(0, #achievements - featTotal),
    }
    self.missingCatalogueReady = true
    return self.missingCatalogue
end

function AA:BuildMissingAccountData()
    local catalogue = self:BuildMissingCatalogue(false)
    local chars = self:GetVisibleScannedCharactersSorted()
    if not catalogue then
        self.missingTotal = 0
        self.missingFeatsTotal = 0
        self.missingRegularTotal = 0
        self.missingScannedCharacterCount = #chars
        return nil, chars
    end

    local owned = {}
    for _, char in ipairs(chars) do
        for achievementID, earned in pairs(type(char.achievements) == "table" and char.achievements or {}) do
            if earned then
                owned[tonumber(achievementID) or achievementID] = true
            end
        end
    end

    for _, node in pairs(catalogue.categories) do
        node.missingAchievements = {}
        node.missingTotal = 0
    end

    local missingTotal = 0
    if #chars > 0 then
        for _, entry in ipairs(catalogue.achievements) do
            if not owned[entry.id] then
                local node = catalogue.categories[entry.categoryID]
                if node then
                    table.insert(node.missingAchievements, entry)
                    missingTotal = missingTotal + 1
                end
            end
        end
    end

    local visiting = {}
    local function CountMissing(node)
        if not node then return 0 end
        if visiting[node.id] then return 0 end
        visiting[node.id] = true
        local count = #node.missingAchievements
        for _, child in ipairs(node.children or {}) do
            count = count + CountMissing(child)
        end
        visiting[node.id] = nil
        node.missingTotal = count
        return count
    end

    for _, node in ipairs(catalogue.topCategories) do
        CountMissing(node)
    end

    self.missingTotal = missingTotal
    self.missingFeatsTotal = catalogue.categories[81] and (catalogue.categories[81].missingTotal or 0) or 0
    self.missingRegularTotal = math.max(0, missingTotal - (tonumber(self.missingFeatsTotal) or 0))
    self.missingScannedCharacterCount = #chars
    return catalogue, chars
end

function AA:BuildMissingDisplayRows()
    local catalogue, chars = self:BuildMissingAccountData()
    local rows = {}
    if not catalogue or #chars == 0 then
        self.missingDisplayRows = rows
        return rows, chars, catalogue
    end

    local function AddCategory(node, depth)
        if not node or (node.missingTotal or 0) <= 0 then
            return
        end

        table.insert(rows, {
            kind = "category",
            categoryID = node.id,
            node = node,
            depth = depth,
            count = node.missingTotal or 0,
        })

        if self.missingCollapsed[node.id] then
            return
        end

        for _, entry in ipairs(node.missingAchievements or {}) do
            table.insert(rows, {
                kind = "achievement",
                achievementID = entry.id,
                entry = entry,
                categoryID = node.id,
                depth = depth + 1,
            })
        end

        for _, child in ipairs(node.children or {}) do
            AddCategory(child, depth + 1)
        end
    end

    for _, node in ipairs(catalogue.topCategories or {}) do
        AddCategory(node, 0)
    end

    self.missingDisplayRows = rows
    return rows, chars, catalogue
end

function AA:SetAllMissingGroupsCollapsed(collapsed)
    local catalogue = self:BuildMissingCatalogue(false)
    if catalogue then
        for categoryID in pairs(catalogue.categories) do
            self.missingCollapsed[categoryID] = collapsed and true or nil
        end
    end
    self:RefreshMissingTab(true)
end

function AA:GetMissingCategoryPath(categoryID)
    local catalogue = self.missingCatalogue
    if not catalogue or not catalogue.categories then
        return "Unknown category"
    end
    local parts = {}
    local seen = {}
    local node = catalogue.categories[categoryID]
    while node and not seen[node.id] do
        seen[node.id] = true
        table.insert(parts, 1, node.title or ("Category " .. tostring(node.id)))
        node = node.parent and catalogue.categories[node.parent] or nil
    end
    return table.concat(parts, " > ")
end

function AA:UpdateMissingTabRows()
    local frame = self.missingFrame
    if not frame or not frame.rows or not frame.scrollFrame then
        return
    end

    local rows = self.missingDisplayRows or {}
    local scrollHeight = tonumber(frame.scrollFrame:GetHeight()) or 0
    local visibleRows = math.floor(scrollHeight / MISSING_ROW_HEIGHT)
    if visibleRows < 1 then visibleRows = 1 end
    if visibleRows > MISSING_VISIBLE_ROWS then visibleRows = MISSING_VISIBLE_ROWS end
    frame.visibleRowCount = visibleRows

    FauxScrollFrame_Update(frame.scrollFrame, #rows, visibleRows, MISSING_ROW_HEIGHT)
    local offset = FauxScrollFrame_GetOffset(frame.scrollFrame) or 0

    for i = 1, MISSING_VISIBLE_ROWS do
        local row = frame.rows[i]
        local data = (i <= visibleRows) and rows[offset + i] or nil
        row.data = data

        if not data then
            row:Hide()
        else
            row:Show()
            row.icon:Hide()
            row.icon:ClearAllPoints()
            row.groupBG:Hide()
            row.mainText:ClearAllPoints()
            row.countText:SetText("")
            row.rightText:SetText("")

            if data.kind == "category" then
                local depth = tonumber(data.depth) or 0
                local collapsed = self.missingCollapsed[data.categoryID] and true or false
                local marker = collapsed and "[+] " or "[-] "
                row.groupBG:Show()
                row.mainText:SetPoint("LEFT", row, "LEFT", 8 + (depth * 18), 0)
                row.mainText:SetPoint("RIGHT", row, "RIGHT", -300, 0)
                row.mainText:SetText(marker .. (data.node.title or ("Category " .. tostring(data.categoryID))))
                if depth == 0 then
                    row.mainText:SetTextColor(GOLD[1], GOLD[2], GOLD[3])
                else
                    row.mainText:SetTextColor(0.95, 0.80, 0.30)
                end
                row.countText:SetText(tostring(data.count or 0))
                row.countText:SetTextColor(1.00, 0.35, 0.35)
                row.rightText:SetText("")
            else
                local entry = data.entry or {}
                local depth = tonumber(data.depth) or 1
                row.icon:SetPoint("LEFT", row, "LEFT", 14 + (depth * 18), 0)
                row.icon:SetTexture(entry.icon or "Interface\\Icons\\INV_Misc_QuestionMark")
                row.icon:Show()
                row.mainText:SetPoint("LEFT", row.icon, "RIGHT", 7, 0)
                row.mainText:SetPoint("RIGHT", row, "RIGHT", -300, 0)
                row.mainText:SetText(entry.name or ("Achievement #" .. tostring(data.achievementID)))
                row.mainText:SetTextColor(0.95, 0.95, 0.95)
                row.countText:SetText("Missing")
                row.countText:SetTextColor(1.00, 0.25, 0.25)
                row.rightText:SetText(tostring(tonumber(entry.points) or 0) .. " pts")
                row.rightText:SetTextColor(GOLD[1], GOLD[2], GOLD[3])
            end
        end
    end
end

function AA:ShowMissingRowTooltip(row)
    if not self:IsEnabled() or not GameTooltip then
        return
    end
    local data = row and row.data
    if not data then return end

    GameTooltip:SetOwner(row, "ANCHOR_RIGHT")
    GameTooltip:ClearLines()

    if data.kind == "category" then
        local node = data.node
        GameTooltip:AddLine(node and node.title or "Achievement category", 1, 0.82, 0)
        GameTooltip:AddDoubleLine("Missing achievements", tostring(data.count or 0), GREY[1], GREY[2], GREY[3], 1, 0.3, 0.3)
        if data.categoryID == 81 then
            GameTooltip:AddLine("Feats of Strength are read from the 5.4.8 client catalogue with hidden/incomplete achievements included.", 0.75, 0.75, 0.75, true)
        end
        GameTooltip:AddLine("Click to expand or collapse this group.", 0.55, 0.55, 0.55, true)
        GameTooltip:Show()
        return
    end

    if data.kind ~= "achievement" or not data.achievementID then
        return
    end

    local link = GetAchievementLink and GetAchievementLink(data.achievementID)
    if link and GameTooltip.SetHyperlink then
        GameTooltip:SetHyperlink(link)
    else
        local entry = data.entry or {}
        GameTooltip:AddLine(entry.name or ("Achievement #" .. tostring(data.achievementID)), 1, 0.82, 0)
        local description = entry.description
        if (not description or description == "") and type(GetAchievementInfo) == "function" then
            local _, _, _, _, _, _, _, apiDescription = GetAchievementInfo(data.achievementID)
            description = apiDescription
        end
        if description and description ~= "" then
            GameTooltip:AddLine(description, 0.9, 0.9, 0.9, true)
        end
    end
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine("Alternator realm-scope status", 1, 0.82, 0)
    GameTooltip:AddLine(string.format("Missing on all %d scanned character(s) in the active realm scope.", tonumber(self.missingScannedCharacterCount) or 0), 1, 0.25, 0.25, true)
    GameTooltip:AddLine("Realms: " .. self:GetRealmFilterLabel(), 0.62, 0.62, 0.62, true)
    GameTooltip:AddLine("Category: " .. self:GetMissingCategoryPath(data.categoryID), 0.72, 0.72, 0.72, true)
    GameTooltip:AddLine("Achievement ID: " .. tostring(data.achievementID), 0.55, 0.55, 0.55)
    GameTooltip:Show()
end

function AA:OnMissingRowClick(row)
    local data = row and row.data
    if not data then return end

    if data.kind == "category" then
        if self.missingCollapsed[data.categoryID] then
            self.missingCollapsed[data.categoryID] = nil
        else
            self.missingCollapsed[data.categoryID] = true
        end
        self:RefreshMissingTab(false)
        return
    end

    if data.kind == "achievement" and data.achievementID then
        local link = GetAchievementLink and GetAchievementLink(data.achievementID)
        if IsModifiedClick and IsModifiedClick("CHATLINK") and ChatEdit_GetActiveWindow and ChatEdit_GetActiveWindow() then
            if link and ChatEdit_InsertLink then ChatEdit_InsertLink(link) end
            return
        end
        self:OpenAchievementFromUniqueTab(data.achievementID)
    end
end

function AA:RefreshMissingTab(resetScroll)
    local frame = self.missingFrame
    if not frame then return end

    local rows, chars, catalogue = self:BuildMissingDisplayRows()
    chars = chars or {}
    if frame.scope then
        frame.scope:SetText("Catalogue: 5.4.8 client, including hidden achievements and Feats of Strength")
    end
    if self.missingRealmDropDown and type(UIDropDownMenu_SetText) == "function" then
        UIDropDownMenu_SetText(self.missingRealmDropDown, self:GetRealmFilterLabel())
    end

    if not catalogue then
        frame.summary:SetText("Achievement catalogue is not available yet. Try again in a few seconds.")
        frame.emptyText:SetText("Achievement categories are not available yet.")
        frame.emptyText:Show()
    elseif #chars == 0 then
        frame.summary:SetText("No scanned characters yet.")
        frame.emptyText:SetText("No scanned characters yet. Log each character once or run /alt scan.")
        frame.emptyText:Show()
    else
        local scanSuffix = self.scan and "  (scan in progress)" or ""
        local status = string.format(
            "%d scanned character(s) in selected realm scope%s\n%d / %d regular achievement(s) missing in this scope\n%d / %d Feats of Strength missing in this scope",
            #chars,
            scanSuffix,
            tonumber(self.missingRegularTotal) or 0,
            tonumber(catalogue.regularTotal) or 0,
            tonumber(self.missingFeatsTotal) or 0,
            tonumber(catalogue.featTotal) or 0
        )
        frame.summary:SetText(status)
        if (tonumber(self.missingTotal) or 0) == 0 then
            frame.emptyText:SetText("No missing achievements were found in the 5.4.8 client catalogue.")
            frame.emptyText:Show()
        else
            frame.emptyText:Hide()
        end
    end

    if resetScroll and frame.scrollFrame then
        FauxScrollFrame_SetOffset(frame.scrollFrame, 0)
        local scrollBar = frame.scrollFrame.ScrollBar or _G[frame.scrollFrame:GetName() .. "ScrollBar"]
        if scrollBar then scrollBar:SetValue(0) end
    end

    self:UpdateMissingTabRows()
end

function AA:ShowMissingTab()
    if not self:IsEnabled() then
        Print("Alternator is disabled. Enable it in Interface > AddOns > Alternator.")
        return
    end

    local frame = self.missingFrame
    local tab = self.missingTab
    if not frame or not tab or not AchievementFrame then return end

    local catalogue = self:BuildMissingCatalogue(false)
    if catalogue then
        for categoryID in pairs(catalogue.categories) do
            self.missingCollapsed[categoryID] = true
        end
    end

    if IN_GUILD_VIEW and type(AchievementFrame_ToggleView) == "function" then
        AchievementFrame_ToggleView()
    end
    if AchievementFrame.searchResults then AchievementFrame.searchResults:Hide() end
    if type(AchievementFrame_HideSearchPreview) == "function" then AchievementFrame_HideSearchPreview() end

    if PanelTemplates_Tab_OnClick then
        PanelTemplates_Tab_OnClick(tab, AchievementFrame)
    end
    self:UpdateAchievementTabTextOffsets(tab:GetID())

    if type(AchievementFrame_ShowSubFrame) == "function" then
        AchievementFrame_ShowSubFrame(frame)
    else
        frame:Show()
    end

    if AchievementFrameCategories then AchievementFrameCategories:Hide() end
    if AchievementFrameFilterDropDown then AchievementFrameFilterDropDown:Hide() end
    if AchievementFrameHeaderLeftDDLInset then AchievementFrameHeaderLeftDDLInset:Hide() end
    if AchievementFrameHeaderRightDDLInset then AchievementFrameHeaderRightDDLInset:Hide() end
    if AchievementFrameGuildEmblemLeft then AchievementFrameGuildEmblemLeft:Hide() end
    if AchievementFrameGuildEmblemRight then AchievementFrameGuildEmblemRight:Hide() end

    self:RefreshMissingTab(true)
end

function AA:CreateMissingFrame()
    if self.missingFrame or not AchievementFrame or not AchievementFrameCategories or not AchievementFrameAchievements then
        return self.missingFrame
    end

    local frame = CreateFrame("Frame", "AlternatorMissingFrame", AchievementFrame)
    frame:SetPoint("TOPLEFT", AchievementFrameCategories, "TOPLEFT", 0, 0)
    frame:SetPoint("BOTTOMRIGHT", AchievementFrameAchievements, "BOTTOMRIGHT", 0, 0)
    frame:SetFrameLevel(math.max(AchievementFrameCategories:GetFrameLevel(), AchievementFrameAchievements:GetFrameLevel()) + 8)

    local bg = frame:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(frame)
    bg:SetTexture("Interface\\AchievementFrame\\UI-Achievement-AchievementBackground")
    bg:SetTexCoord(0, 1, 0, 0.5)

    local darken = frame:CreateTexture(nil, "BORDER")
    darken:SetAllPoints(frame)
    darken:SetTexture(0, 0, 0, 0.78)

    local border = CreateFrame("Frame", nil, frame)
    border:SetAllPoints(frame)
    border:SetFrameLevel(frame:GetFrameLevel() + 1)
    border:SetBackdrop({
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true,
        tileSize = 16,
        edgeSize = 16,
        insets = { left = 5, right = 5, top = 5, bottom = 5 },
    })
    border:SetBackdropBorderColor(1, 0.675, 0.125, 1)

    local title = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", frame, "TOPLEFT", 16, -13)
    title:SetText("Missing Achievements")
    title:SetTextColor(1, 0.82, 0)
    frame.title = title

    local summary = frame:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    summary:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -4)
    summary:SetPoint("RIGHT", frame, "RIGHT", -16, 0)
    summary:SetJustifyH("LEFT")
    summary:SetJustifyV("TOP")
    summary:SetHeight(52)
    if summary.SetWordWrap then summary:SetWordWrap(true) end
    summary:SetText("Achievements missing from every scanned character on this account.\nRegular achievements and Feats of Strength are counted separately.\nRealm scope follows the filter below.")
    frame.summary = summary

    local rescan = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    rescan:SetSize(105, 22)
    rescan:SetFrameLevel(frame:GetFrameLevel() + 12)
    rescan:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -12, -10)
    rescan:SetText("Rescan current")
    rescan:SetScript("OnClick", function() AA:StartScan(true) end)

    local collapse = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    collapse:SetSize(82, 22)
    collapse:SetFrameLevel(frame:GetFrameLevel() + 12)
    collapse:SetPoint("RIGHT", rescan, "LEFT", -4, 0)
    collapse:SetText("Collapse")
    collapse:SetScript("OnClick", function() AA:SetAllMissingGroupsCollapsed(true) end)

    local expand = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    expand:SetSize(82, 22)
    expand:SetFrameLevel(frame:GetFrameLevel() + 12)
    expand:SetPoint("RIGHT", collapse, "LEFT", -4, 0)
    expand:SetText("Expand")
    expand:SetScript("OnClick", function() AA:SetAllMissingGroupsCollapsed(false) end)

    local scope = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    scope:SetPoint("TOPLEFT", frame, "TOPLEFT", 16, -78)
    scope:SetPoint("RIGHT", frame, "RIGHT", -16, 0)
    scope:SetJustifyH("LEFT")
    if scope.SetWordWrap then scope:SetWordWrap(true) end
    scope:SetText("Catalogue: 5.4.8 client, including hidden achievements and Feats of Strength")
    scope:SetTextColor(0.82, 0.82, 0.82)
    frame.scope = scope

    local realmLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    realmLabel:SetText("Realms:")

    local realmDropDown = CreateFrame("Frame", "AlternatorMissingRealmDropDown", frame, "UIDropDownMenuTemplate")
    self:SetupRealmDropDown(realmDropDown, 155)
    realmDropDown:SetFrameLevel(frame:GetFrameLevel() + 12)
    -- Share the third summary line with the realm selector. This keeps the
    -- three-line status readable while reclaiming the old dedicated realm row.
    realmDropDown:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -10, -47)
    realmLabel:SetPoint("RIGHT", realmDropDown, "LEFT", 14, 0)
    self.missingRealmDropDown = realmDropDown

    local headerBG = frame:CreateTexture(nil, "ARTWORK")
    headerBG:SetPoint("TOPLEFT", frame, "TOPLEFT", 10, -103)
    headerBG:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -10, -103)
    headerBG:SetHeight(22)
    headerBG:SetTexture(0.08, 0.08, 0.08, 0.95)

    local headerLeft = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    headerLeft:SetPoint("LEFT", headerBG, "LEFT", 8, 0)
    headerLeft:SetPoint("RIGHT", headerBG, "RIGHT", -300, 0)
    headerLeft:SetJustifyH("LEFT")
    headerLeft:SetText("Category / achievement")

    local headerCount = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    headerCount:SetPoint("RIGHT", headerBG, "RIGHT", -165, 0)
    headerCount:SetWidth(110)
    headerCount:SetJustifyH("LEFT")
    headerCount:SetText("Missing")

    local headerRight = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    headerRight:SetPoint("RIGHT", headerBG, "RIGHT", -20, 0)
    headerRight:SetWidth(130)
    headerRight:SetJustifyH("LEFT")
    headerRight:SetText("Achievement points")

    local scroll = CreateFrame("ScrollFrame", "AlternatorMissingScrollFrame", frame, "FauxScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", frame, "TOPLEFT", 10, -127)
    scroll:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -8, 10)
    scroll:SetFrameLevel(frame:GetFrameLevel() + 1)
    scroll:SetScript("OnVerticalScroll", function(self, offset)
        FauxScrollFrame_OnVerticalScroll(self, offset, MISSING_ROW_HEIGHT, function() AA:UpdateMissingTabRows() end)
    end)
    frame.scrollFrame = scroll

    frame.rows = {}
    for i = 1, MISSING_VISIBLE_ROWS do
        local row = CreateFrame("Button", nil, frame)
        row:SetHeight(MISSING_ROW_HEIGHT)
        row:SetPoint("TOPLEFT", scroll, "TOPLEFT", 2, -1 - ((i - 1) * MISSING_ROW_HEIGHT))
        row:SetPoint("RIGHT", frame, "RIGHT", -30, 0)
        row:SetFrameLevel(frame:GetFrameLevel() + 3)
        row:RegisterForClicks("LeftButtonUp")

        local groupBG = row:CreateTexture(nil, "BACKGROUND")
        groupBG:SetAllPoints(row)
        groupBG:SetTexture(0.35, 0.23, 0.05, 0.42)
        groupBG:Hide()
        row.groupBG = groupBG

        local highlight = row:CreateTexture(nil, "ARTWORK")
        highlight:SetAllPoints(row)
        highlight:SetTexture(1, 1, 1, 0.08)
        highlight:Hide()
        row.highlight = highlight

        local icon = row:CreateTexture(nil, "ARTWORK")
        icon:SetSize(20, 20)
        icon:SetPoint("LEFT", row, "LEFT", 18, 0)
        icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        row.icon = icon

        local mainText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        mainText:SetPoint("LEFT", row, "LEFT", 8, 0)
        mainText:SetPoint("RIGHT", row, "RIGHT", -300, 0)
        mainText:SetJustifyH("LEFT")
        row.mainText = mainText

        local countText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        countText:SetPoint("RIGHT", row, "RIGHT", -165, 0)
        countText:SetWidth(110)
        countText:SetJustifyH("LEFT")
        row.countText = countText

        local rightText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        rightText:SetPoint("RIGHT", row, "RIGHT", -20, 0)
        rightText:SetWidth(130)
        rightText:SetJustifyH("LEFT")
        row.rightText = rightText

        row:SetScript("OnEnter", function(self)
            self.highlight:Show()
            AA:ShowMissingRowTooltip(self)
        end)
        row:SetScript("OnLeave", function(self)
            self.highlight:Hide()
            if GameTooltip and GameTooltip:IsOwned(self) then GameTooltip:Hide() end
        end)
        row:SetScript("OnClick", function(self) AA:OnMissingRowClick(self) end)
        frame.rows[i] = row
    end

    local empty = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    empty:SetPoint("CENTER", frame, "CENTER", 0, -10)
    empty:SetWidth(560)
    empty:SetJustifyH("CENTER")
    empty:SetTextColor(0.70, 0.70, 0.70)
    empty:Hide()
    frame.emptyText = empty

    frame:SetScript("OnShow", function()
        if AchievementFrameCategories then AchievementFrameCategories:Hide() end
        AA:RefreshMissingTab(false)
    end)
    frame:SetScript("OnSizeChanged", function()
        if AA.missingFrame and AA.missingFrame:IsShown() then
            AA:UpdateMissingTabRows()
        end
    end)
    frame:SetScript("OnHide", function()
        if AchievementFrameCategories then AchievementFrameCategories:Show() end
    end)

    frame:Hide()
    self.missingFrame = frame
    return frame
end

function AA:CreateUniqueFrame()
    if self.uniqueFrame or not AchievementFrame or not AchievementFrameCategories or not AchievementFrameAchievements then
        return self.uniqueFrame
    end

    local frame = CreateFrame("Frame", "AlternatorUniqueFrame", AchievementFrame)
    frame:SetPoint("TOPLEFT", AchievementFrameCategories, "TOPLEFT", 0, 0)
    frame:SetPoint("BOTTOMRIGHT", AchievementFrameAchievements, "BOTTOMRIGHT", 0, 0)
    frame:SetFrameLevel(math.max(AchievementFrameCategories:GetFrameLevel(), AchievementFrameAchievements:GetFrameLevel()) + 8)

    local bg = frame:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(frame)
    bg:SetTexture("Interface\\AchievementFrame\\UI-Achievement-AchievementBackground")
    bg:SetTexCoord(0, 1, 0, 0.5)

    local darken = frame:CreateTexture(nil, "BORDER")
    darken:SetAllPoints(frame)
    darken:SetTexture(0, 0, 0, 0.78)

    local border = CreateFrame("Frame", nil, frame)
    border:SetAllPoints(frame)
    border:SetFrameLevel(frame:GetFrameLevel() + 1)
    border:SetBackdrop({
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true,
        tileSize = 16,
        edgeSize = 16,
        insets = { left = 5, right = 5, top = 5, bottom = 5 },
    })
    border:SetBackdropBorderColor(1, 0.675, 0.125, 1)

    local title = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", frame, "TOPLEFT", 16, -13)
    title:SetText("Unique Achievements")
    title:SetTextColor(1, 0.82, 0)
    frame.title = title

    local summary = frame:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    -- Give the status its own full-width row. It used to share horizontal space
    -- with the Realms/Sort controls, which truncated long Oldest status strings.
    summary:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -4)
    summary:SetPoint("RIGHT", frame, "RIGHT", -16, 0)
    summary:SetJustifyH("LEFT")
    summary:SetJustifyV("TOP")
    summary:SetHeight(18)
    summary:SetText("Unique among scanned characters on this account.")
    frame.summary = summary

    local sortLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    sortLabel:SetText("Sort:")

    local sortDropDown = CreateFrame("Frame", "AlternatorUniqueSortDropDown", frame, "UIDropDownMenuTemplate")
    -- Third row: controls live below the full-width status line. Keep the dropdown
    -- safely inset from the right edge because the 5.4.8 template draws beyond its
    -- nominal content width.
    self:SetupSortDropDown(sortDropDown, 145)
    sortDropDown:SetFrameLevel(frame:GetFrameLevel() + 12)
    sortDropDown:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -10, -61)
    sortLabel:SetPoint("RIGHT", sortDropDown, "LEFT", 14, 0)
    self.uniqueSortDropDown = sortDropDown

    local realmLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    realmLabel:SetText("Realms:")

    local realmDropDown = CreateFrame("Frame", "AlternatorUniqueRealmDropDown", frame, "UIDropDownMenuTemplate")
    self:SetupRealmDropDown(realmDropDown, 155)
    realmDropDown:SetFrameLevel(frame:GetFrameLevel() + 12)
    realmDropDown:SetPoint("RIGHT", sortLabel, "LEFT", -28, 0)
    realmLabel:SetPoint("RIGHT", realmDropDown, "LEFT", 14, 0)
    self.uniqueRealmDropDown = realmDropDown
    realmDropDown:EnableMouse(true)
    realmDropDown:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOMRIGHT")
        GameTooltip:AddLine("Realm comparison filter", 1, 0.82, 0)
        GameTooltip:AddLine("Choose one or several realms to compare.", 0.9, 0.9, 0.9, true)
        GameTooltip:AddLine("Unselected realms are completely ignored by Unique and Oldest comparisons.", 0.65, 0.65, 0.65, true)
        GameTooltip:Show()
    end)
    realmDropDown:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)

    local rescan = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    rescan:SetSize(105, 22)
    rescan:SetFrameLevel(frame:GetFrameLevel() + 12)
    rescan:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -12, -10)
    rescan:SetText("Rescan current")
    rescan:SetScript("OnClick", function()
        AA:StartScan(true)
    end)

    local collapse = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    collapse:SetSize(82, 22)
    collapse:SetFrameLevel(frame:GetFrameLevel() + 12)
    collapse:SetPoint("RIGHT", rescan, "LEFT", -4, 0)
    collapse:SetText("Collapse")
    collapse:SetScript("OnClick", function()
        AA:SetAllUniqueGroupsCollapsed(true)
    end)

    local expand = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    expand:SetSize(82, 22)
    expand:SetFrameLevel(frame:GetFrameLevel() + 12)
    expand:SetPoint("RIGHT", collapse, "LEFT", -4, 0)
    expand:SetText("Expand")
    expand:SetScript("OnClick", function()
        AA:SetAllUniqueGroupsCollapsed(false)
    end)

    local modeButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    modeButton:SetSize(98, 22)
    modeButton:SetFrameLevel(frame:GetFrameLevel() + 12)
    modeButton:SetPoint("RIGHT", expand, "LEFT", -4, 0)
    modeButton:SetText(self:GetUniqueViewMode() == "oldest" and "Show unique" or "Show oldest")
    modeButton:SetScript("OnClick", function()
        AA:ToggleUniqueViewMode()
    end)
    frame.modeButton = modeButton

    local headerBG = frame:CreateTexture(nil, "ARTWORK")
    headerBG:SetPoint("TOPLEFT", frame, "TOPLEFT", 10, -91)
    headerBG:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -10, -91)
    headerBG:SetHeight(22)
    headerBG:SetTexture(0.08, 0.08, 0.08, 0.95)

    local headerLeft = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    headerLeft:SetPoint("LEFT", headerBG, "LEFT", 8, 0)
    headerLeft:SetPoint("RIGHT", headerBG, "RIGHT", -365, 0)
    headerLeft:SetJustifyH("LEFT")
    headerLeft:SetText("Character / achievement")
    frame.headerLeft = headerLeft

    local headerCount = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    headerCount:SetPoint("RIGHT", headerBG, "RIGHT", -240, 0)
    headerCount:SetWidth(120)
    headerCount:SetJustifyH("LEFT")
    headerCount:SetText("Unique")
    frame.headerCount = headerCount

    local headerRight = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    headerRight:SetPoint("RIGHT", headerBG, "RIGHT", -34, 0)
    headerRight:SetWidth(200)
    headerRight:SetJustifyH("LEFT")
    headerRight:SetText("Achievement points")
    frame.headerRight = headerRight

    local headerRightHitbox = CreateFrame("Frame", nil, frame)
    headerRightHitbox:SetFrameLevel(frame:GetFrameLevel() + 5)
    headerRightHitbox:SetPoint("LEFT", headerBG, "RIGHT", -234, 0)
    headerRightHitbox:SetWidth(200)
    headerRightHitbox:SetHeight(22)
    headerRightHitbox:EnableMouse(true)
    headerRightHitbox:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:ClearLines()
        GameTooltip:AddLine("Achievement points", 1, 0.82, 0)
        GameTooltip:AddLine("This column shows |cffffffffCharacter AP / Account AP|r.", 0.90, 0.90, 0.90, true)
        GameTooltip:AddLine("Left number = achievement points earned by that specific character.", 0.75, 0.75, 0.75, true)
        GameTooltip:AddLine("Right number = total account achievement points seen when that character was last scanned.", 0.75, 0.75, 0.75, true)
        GameTooltip:Show()
    end)
    headerRightHitbox:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    frame.headerRightHitbox = headerRightHitbox

    local scroll = CreateFrame("ScrollFrame", "AlternatorUniqueScrollFrame", frame, "FauxScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", frame, "TOPLEFT", 10, -115)
    scroll:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -8, 10)
    scroll:SetFrameLevel(frame:GetFrameLevel() + 1)
    scroll:SetScript("OnVerticalScroll", function(self, offset)
        FauxScrollFrame_OnVerticalScroll(self, offset, UNIQUE_ROW_HEIGHT, function()
            AA:UpdateUniqueTabRows()
        end)
    end)
    frame.scrollFrame = scroll

    frame.rows = {}
    for i = 1, UNIQUE_VISIBLE_ROWS do
        local row = CreateFrame("Button", nil, frame)
        row:SetHeight(UNIQUE_ROW_HEIGHT)
        row:SetPoint("TOPLEFT", frame, "TOPLEFT", 12, -116 - ((i - 1) * UNIQUE_ROW_HEIGHT))
        row:SetPoint("RIGHT", frame, "RIGHT", -30, 0)
        row:SetFrameLevel(frame:GetFrameLevel() + 3)
        row:RegisterForClicks("LeftButtonUp")

        local groupBG = row:CreateTexture(nil, "BACKGROUND")
        groupBG:SetAllPoints(row)
        groupBG:SetTexture(0.35, 0.23, 0.05, 0.42)
        groupBG:Hide()
        row.groupBG = groupBG

        local highlight = row:CreateTexture(nil, "ARTWORK")
        highlight:SetAllPoints(row)
        highlight:SetTexture(1, 1, 1, 0.08)
        highlight:Hide()
        row.highlight = highlight

        local icon = row:CreateTexture(nil, "ARTWORK")
        icon:SetSize(20, 20)
        icon:SetPoint("LEFT", row, "LEFT", 18, 0)
        icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        row.icon = icon

        local mainText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        mainText:SetPoint("LEFT", row, "LEFT", 8, 0)
        mainText:SetPoint("RIGHT", row, "RIGHT", -75, 0)
        mainText:SetJustifyH("LEFT")
        row.mainText = mainText

        local countText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        countText:SetPoint("RIGHT", row, "RIGHT", -240, 0)
        countText:SetWidth(120)
        countText:SetJustifyH("LEFT")
        row.countText = countText

        local rightText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        rightText:SetPoint("RIGHT", row, "RIGHT", -34, 0)
        rightText:SetWidth(200)
        rightText:SetJustifyH("LEFT")
        row.rightText = rightText

        local removeButton = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        removeButton:SetSize(22, 20)
        removeButton:SetPoint("RIGHT", row, "RIGHT", -3, 0)
        removeButton:SetText("X")
        removeButton:SetFrameLevel(row:GetFrameLevel() + 3)
        if removeButton:GetFontString() then
            removeButton:GetFontString():SetTextColor(1.00, 0.30, 0.30)
        end
        removeButton:Hide()
        removeButton:SetScript("OnEnter", function(self)
            local parent = self:GetParent()
            local data = parent and parent.data
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:ClearLines()
            GameTooltip:AddLine("Remove stored character", 1, 0.25, 0.25)
            if data and data.char then
                local fullName = (data.char.name or "Unknown") .. "-" .. (data.char.realm or "UnknownRealm")
                GameTooltip:AddLine(fullName, 1, 1, 1)
            end
            GameTooltip:AddLine("Deletes only Alternator data. The game character and account achievements are not changed.", 0.70, 0.70, 0.70, true)
            GameTooltip:Show()
        end)
        removeButton:SetScript("OnLeave", function(self)
            if GameTooltip and GameTooltip:IsOwned(self) then
                GameTooltip:Hide()
            end
        end)
        removeButton:SetScript("OnClick", function(self)
            local parent = self:GetParent()
            local data = parent and parent.data
            if data and data.kind == "character" and data.charKey then
                AA:RequestRemoveCharacter(data.charKey)
            end
        end)
        row.removeButton = removeButton

        row:SetScript("OnEnter", function(self)
            self.highlight:Show()
            AA:ShowUniqueRowTooltip(self)
        end)
        row:SetScript("OnLeave", function(self)
            self.highlight:Hide()
            if GameTooltip and GameTooltip:IsOwned(self) then
                GameTooltip:Hide()
            end
        end)
        row:SetScript("OnClick", function(self)
            AA:OnUniqueRowClick(self)
        end)

        frame.rows[i] = row
    end

    local empty = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    empty:SetPoint("CENTER", frame, "CENTER", 0, -10)
    empty:SetWidth(500)
    empty:SetJustifyH("CENTER")
    empty:SetTextColor(0.70, 0.70, 0.70)
    empty:Hide()
    frame.emptyText = empty

    frame:SetScript("OnShow", function()
        if AchievementFrameCategories then
            AchievementFrameCategories:Hide()
        end
        AA:RefreshUniqueTab(false)
    end)

    frame:SetScript("OnHide", function()
        -- Blizzard and Overachiever will immediately apply their own visibility
        -- rules when another tab is selected. Re-showing the categories here
        -- gives the stock tabs a clean starting state.
        if AchievementFrameCategories then
            AchievementFrameCategories:Show()
        end
    end)

    frame:Hide()
    self.uniqueFrame = frame
    return frame
end

function AA:CreateUniqueTab()
    if not self:IsEnabled() then
        return
    end
    if not AchievementFrame or not _G.AchievementFrameTab1 then
        return
    end
    if self.uniqueTab then
        self:CreateMissingTab()
        return
    end

    local numTabs = 1
    while _G["AchievementFrameTab" .. numTabs] do
        numTabs = numTabs + 1
    end

    local previous = _G["AchievementFrameTab" .. (numTabs - 1)]
    if not previous then
        return
    end

    local tab = CreateFrame("Button", "AchievementFrameTab" .. numTabs, AchievementFrame, "AchievementFrameTabButtonTemplate")
    tab:SetText("Unique")

    -- AchievementFrameTabButtonTemplate runs its OnLoad before SetText() is called.
    -- On 5.4.8 that means a dynamically-created tab can keep the tiny width that
    -- was calculated for an empty label. Resize it explicitly after setting the
    -- label. Alternator keeps its two custom tabs compact so Unique + Missing fit
    -- beside stock and Overachiever tabs without spilling outside the frame.
    local targetWidth = 84

    -- MoP 5.4.8 uses PanelTemplates_TabResize(tab, padding, absoluteSize, maxWidth).
    -- Keep the resize call protected: some private-server clients ship slightly
    -- different FrameXML, and a sizing helper must never be allowed to abort
    -- creation of the entire Unique tab.
    local resized = false
    if type(PanelTemplates_TabResize) == "function" then
        local ok = pcall(PanelTemplates_TabResize, tab, 0, targetWidth)
        if ok then
            resized = true
        end
    end

    if not resized then
        tab:SetWidth(targetWidth)

        -- Best-effort fallback for the standard tab template. SetWidth() keeps
        -- the button clickable; these texture adjustments make the visual
        -- pieces follow the wider button on clients where the helper differs.
        local tabName = tab:GetName()
        local left = _G[tabName .. "Left"]
        local right = _G[tabName .. "Right"]
        local middle = _G[tabName .. "Middle"]
        local leftDisabled = _G[tabName .. "LeftDisabled"]
        local rightDisabled = _G[tabName .. "RightDisabled"]
        local middleDisabled = _G[tabName .. "MiddleDisabled"]
        local highlight = _G[tabName .. "HighlightTexture"]

        local sideWidth = 0
        if left and left.GetWidth then
            sideWidth = left:GetWidth() * 2
        end
        local middleWidth = math.max(1, targetWidth - sideWidth)
        if middle then middle:SetWidth(middleWidth) end
        if middleDisabled then middleDisabled:SetWidth(middleWidth) end
        if highlight then highlight:SetWidth(targetWidth) end
    end

    tab:SetPoint("LEFT", previous, "RIGHT", -5, 0)
    tab:SetID(numTabs)
    tab:SetScript("OnClick", function()
        AA:ShowUniqueTab()
    end)

    if PanelTemplates_SetNumTabs then
        PanelTemplates_SetNumTabs(AchievementFrame, numTabs)
    end
    if PanelTemplates_UpdateTabs then
        PanelTemplates_UpdateTabs(AchievementFrame)
    end

    self.uniqueTab = tab
    self.uniqueTabIndex = numTabs
    self:CreateUniqueFrame()

    -- Make AchievementFrame_ShowSubFrame aware of our panel. This is also the
    -- compatibility mechanism used by Overachiever_Tabs, so switching between
    -- its Search/Suggestions/Watch tabs and our Unique tab cleanly hides panels.
    if type(ACHIEVEMENTFRAME_SUBFRAMES) == "table" then
        local found = false
        for _, name in ipairs(ACHIEVEMENTFRAME_SUBFRAMES) do
            if name == "AlternatorUniqueFrame" then
                found = true
                break
            end
        end
        if not found then
            table.insert(ACHIEVEMENTFRAME_SUBFRAMES, "AlternatorUniqueFrame")
        end
    end

    self:UpdateAchievementTabTextOffsets(AchievementFrame.selectedTab or 1)
    self:CreateMissingTab()
end

function AA:CreateMissingTab()
    if not self:IsEnabled() then return end
    if self.missingTab or not AchievementFrame or not _G.AchievementFrameTab1 then return end

    local numTabs = 1
    while _G["AchievementFrameTab" .. numTabs] do
        numTabs = numTabs + 1
    end
    local previous = _G["AchievementFrameTab" .. (numTabs - 1)]
    if not previous then return end

    local tab = CreateFrame("Button", "AchievementFrameTab" .. numTabs, AchievementFrame, "AchievementFrameTabButtonTemplate")
    tab:SetText("Missing")
    local targetWidth = 84
    local resized = false
    if type(PanelTemplates_TabResize) == "function" then
        local ok = pcall(PanelTemplates_TabResize, tab, 0, targetWidth)
        if ok then resized = true end
    end
    if not resized then
        tab:SetWidth(targetWidth)
        local tabName = tab:GetName()
        local left = _G[tabName .. "Left"]
        local middle = _G[tabName .. "Middle"]
        local middleDisabled = _G[tabName .. "MiddleDisabled"]
        local highlight = _G[tabName .. "HighlightTexture"]
        local sideWidth = 0
        if left and left.GetWidth then sideWidth = left:GetWidth() * 2 end
        local middleWidth = math.max(1, targetWidth - sideWidth)
        if middle then middle:SetWidth(middleWidth) end
        if middleDisabled then middleDisabled:SetWidth(middleWidth) end
        if highlight then highlight:SetWidth(targetWidth) end
    end

    tab:SetPoint("LEFT", previous, "RIGHT", -5, 0)
    tab:SetID(numTabs)
    tab:SetScript("OnClick", function() AA:ShowMissingTab() end)

    if PanelTemplates_SetNumTabs then PanelTemplates_SetNumTabs(AchievementFrame, numTabs) end
    if PanelTemplates_UpdateTabs then PanelTemplates_UpdateTabs(AchievementFrame) end

    self.missingTab = tab
    self.missingTabIndex = numTabs
    self:CreateMissingFrame()

    if type(ACHIEVEMENTFRAME_SUBFRAMES) == "table" then
        local found = false
        for _, name in ipairs(ACHIEVEMENTFRAME_SUBFRAMES) do
            if name == "AlternatorMissingFrame" then found = true break end
        end
        if not found then table.insert(ACHIEVEMENTFRAME_SUBFRAMES, "AlternatorMissingFrame") end
    end

    self:UpdateAchievementTabTextOffsets(AchievementFrame.selectedTab or 1)
end

function AA:OpenUniqueTab()
    if not self:IsEnabled() then
        Print("Alternator is disabled. Enable it in Interface > AddOns > Alternator.")
        return
    end
    if not IsAddOnLoaded("Blizzard_AchievementUI") then
        LoadAddOn("Blizzard_AchievementUI")
    end

    self:HookAchievementUI()
    self:CreateUniqueTab()

    if AchievementFrame and not AchievementFrame:IsShown() then
        ShowUIPanel(AchievementFrame)
    end

    self:ShowUniqueTab()
end

function AA:OpenMissingTab()
    if not self:IsEnabled() then
        Print("Alternator is disabled. Enable it in Interface > AddOns > Alternator.")
        return
    end
    if not IsAddOnLoaded("Blizzard_AchievementUI") then
        LoadAddOn("Blizzard_AchievementUI")
    end

    self:HookAchievementUI()
    self:CreateUniqueTab()
    if AchievementFrame and not AchievementFrame:IsShown() then
        ShowUIPanel(AchievementFrame)
    end
    self:ShowMissingTab()
end

function AA:CreateHeaderHitbox()
    if self.headerHitbox or not AchievementFrame or not AchievementFrameHeaderPoints then
        return
    end

    local hitbox = CreateFrame("Frame", nil, AchievementFrame)
    hitbox:SetPoint("TOPLEFT", AchievementFrameHeaderPoints, "TOPLEFT", -8, 8)
    hitbox:SetPoint("BOTTOMRIGHT", AchievementFrameHeaderPoints, "BOTTOMRIGHT", 8, -8)
    hitbox:EnableMouse(self:IsEnabled())
    hitbox:SetFrameLevel(AchievementFrame:GetFrameLevel() + 20)

    hitbox:SetScript("OnEnter", function(self)
        if not IN_GUILD_VIEW then
            AA:ShowUniqueSummaryTooltip(self)
        end
    end)

    hitbox:SetScript("OnLeave", function(self)
        if GameTooltip and GameTooltip:IsOwned(self) then
            GameTooltip:Hide()
        end
    end)

    self.headerHitbox = hitbox
end

function AA:HookAchievementUI()
    if not IsAddOnLoaded("Blizzard_AchievementUI") or not AchievementFrame then
        return
    end

    if self.achievementUIHooked then
        self:HookVisibleAchievementButtons()
        self:CreateHeaderHitbox()
        if self:IsEnabled() and (not self.uniqueTab or not self.missingTab) then
            self.uniqueTabCreateAt = GetTime() + 0.10
        end
        return
    end

    self.achievementUIHooked = true

    -- Existing HybridScrollFrame buttons are normally already created by the
    -- time ADDON_LOADED fires, so hook the actual container button table now.
    self:HookVisibleAchievementButtons()

    -- Also catch any buttons that a custom 5.4.8 core creates later.
    if type(AchievementButton_OnLoad) == "function" then
        hooksecurefunc("AchievementButton_OnLoad", function(button)
            AA:HookAchievementButton(button)
        end)
    end

    -- Re-check after updates because private-server UI modifications sometimes
    -- rebuild the HybridScrollFrame button table.
    if type(AchievementFrameAchievements_Update) == "function" then
        hooksecurefunc("AchievementFrameAchievements_Update", function()
            AA:HookVisibleAchievementButtons()
        end)
    end

    if type(AchievementFrame_UpdateFullSearchResults) == "function" then
        hooksecurefunc("AchievementFrame_UpdateFullSearchResults", function()
            AA:HookVisibleAchievementButtons()
        end)
    end

    if type(AchievementFrame_OnShow) == "function" then
        hooksecurefunc("AchievementFrame_OnShow", function()
            AA:HookVisibleAchievementButtons()
            AA:CreateHeaderHitbox()
        end)
    end

    self:CreateHeaderHitbox()
    -- Delay tab creation very slightly so LoadWith addons such as
    -- Overachiever_Tabs can add Search/Suggestions/Watch first. We then occupy
    -- the next free AchievementFrameTabN slot instead of colliding with them.
    self.uniqueTabCreateAt = GetTime() + 0.10

    if GameTooltip and GameTooltip.HookScript and not GameTooltip.__AlternatorHideHooked then
        GameTooltip.__AlternatorHideHooked = true
        GameTooltip:HookScript("OnHide", function(self)
            self.__AlternatorID = nil
            self.__AlternatorOwnBase = nil
        end)
    end
end

function AA:PrintCharacters()
    local chars = self:GetVisibleScannedCharactersSorted()
    local allChars = self:GetScannedCharactersSorted()
    if not self:IsRealmFilterAll() then
        Print(string.format("Scanned characters in comparison set: %d (realms: %s)", #chars, self:GetRealmFilterLabel()))
    else
        Print("Scanned characters: " .. tostring(#chars))
    end

    if #chars == 0 then
        if #allChars > 0 then
            Print("No scanned characters are included by the active realm filter. Choose another realm or select All realms.")
        else
            Print("No completed scans yet. Log each character once or run /alt scan.")
        end
        return
    end

    for _, char in ipairs(chars) do
        Print(string.format("%s - level %s - earned %s - last scan %s", self:CharacterDisplayName(char), tostring(char.level or "?"), tostring(char.earnedCount or 0), FormatTimestamp(char.lastScan)))
    end
end

function AA:PrintUniqueSummary()
    self:BuildOwnershipIndex()
    local chars = self:GetVisibleScannedCharactersSorted()
    local allChars = self:GetScannedCharactersSorted()

    if #chars == 0 then
        if #allChars > 0 then
            Print("No scanned characters are included by the active realm filter.")
        else
            Print("No scanned characters yet.")
        end
        return
    end

    if #chars < #allChars then
        Print("Unique achievements within the selected realm comparison set:")
    else
        Print("Unique achievements by character (unique among scanned characters):")
    end
    local total = 0
    for _, char in ipairs(chars) do
        local count = self.uniqueCounts[char.key] or 0
        total = total + count
        Print(string.format("%s: %d", self:CharacterDisplayName(char), count))
    end
    Print("Total unique achievements: " .. tostring(total))
end

function AA:PrintUniqueForCharacter(char, page)
    self:BuildOwnershipIndex()

    if not self:IsRealmSelected(char.realm or "UnknownRealm") then
        Print(self:CharacterDisplayName(char) .. " is excluded by the active realm comparison filter (" .. self:GetRealmFilterLabel() .. ").")
        return
    end

    page = tonumber(page) or 1
    if page < 1 then
        page = 1
    end

    local list = self.uniqueLists[char.key] or {}
    local total = #list
    local pages = math.max(1, math.ceil(total / PAGE_SIZE))
    if page > pages then
        page = pages
    end

    Print(string.format("Unique achievements for %s: %d total (page %d/%d)", self:CharacterDisplayName(char), total, page, pages))

    if total == 0 then
        return
    end

    local first = ((page - 1) * PAGE_SIZE) + 1
    local last = math.min(page * PAGE_SIZE, total)
    for i = first, last do
        local achievementID = list[i]
        Print(string.format("%d. %s", i, AchievementLinkOrName(achievementID)))
    end

    if page < pages then
        Print(string.format("Next page: /alt unique %s %d", char.name or self:CharacterDisplayName(char), page + 1))
    end
end

function AA:PrintWho(achievementID)
    achievementID = tonumber(achievementID)
    if not achievementID then
        Print("Usage: /alt who <achievementID>")
        return
    end

    local id, name = GetAchievementInfo(achievementID)
    if not id then
        Print("Unknown achievement ID: " .. tostring(achievementID))
        return
    end

    Print((name or ("Achievement #" .. tostring(achievementID))) .. " (#" .. tostring(achievementID) .. ")")
    local chars = self:GetVisibleScannedCharactersSorted()
    local allChars = self:GetScannedCharactersSorted()
    local earnedCount = 0

    for _, char in ipairs(chars) do
        local earned = char.achievements and char.achievements[achievementID]
        if earned then
            earnedCount = earnedCount + 1
            Print("|cff33ff33Earned|r - " .. self:CharacterDisplayName(char))
        else
            Print("|cffff4040Missing|r - " .. self:CharacterDisplayName(char))
        end
    end

    if not self:IsRealmFilterAll() then
        Print(string.format("Selected-realm result: %d / %d characters (%d scanned characters in realm scope: %s).", earnedCount, #chars, #chars, self:GetRealmFilterLabel()))
    else
        Print(string.format("Result: %d / %d scanned characters.", earnedCount, #chars))
    end
end

function AA:RemoveCharacterByKey(charKey)
    if not self.db or not self.db.characters then
        return false
    end

    local char = self.db.characters[charKey]
    if type(char) ~= "table" then
        Print("Character is no longer stored: " .. tostring(charKey))
        return false
    end

    char.key = char.key or charKey
    if char.key == self.currentCharacterKey then
        Print("Cannot remove the currently logged-in character. Log another character first.")
        return false
    end

    local display = (char.name or "Unknown") .. "-" .. (char.realm or "UnknownRealm")
    self.db.characters[charKey] = nil
    self.uniqueCollapsed[charKey] = nil
    self:InvalidateIndex()
    self:RefreshRealmDropDowns()

    if self.uniqueFrame and self.uniqueFrame:IsShown() then
        self:RefreshUniqueTab(false)
    end
    if self.missingFrame and self.missingFrame:IsShown() then
        self:RefreshMissingTab(false)
    end
    if self.dashboardFrame and self.dashboardFrame:IsShown() then
        self:RefreshDashboard(false)
    end

    Print("Removed stored data for " .. display .. ".")
    return true
end

function AA:RequestRemoveCharacter(charKey)
    if not self.db or not self.db.characters then
        return
    end

    local char = self.db.characters[charKey]
    if type(char) ~= "table" then
        Print("Character is no longer stored: " .. tostring(charKey))
        return
    end

    char.key = char.key or charKey
    if char.key == self.currentCharacterKey then
        Print("Cannot remove the currently logged-in character. Log another character first.")
        return
    end

    local display = (char.name or "Unknown") .. "-" .. (char.realm or "UnknownRealm")
    if type(StaticPopup_Show) == "function" then
        local dialog = StaticPopup_Show(REMOVE_POPUP, display, nil, charKey)
        if dialog then
            dialog.data = charKey
        end
    else
        -- Extremely defensive fallback for modified clients without StaticPopup.
        self:RemoveCharacterByKey(charKey)
    end
end

function AA:RemoveCharacter(query)
    local char, reason, matches = self:ResolveCharacter(query)
    if not char then
        if reason == "ambiguous" then
            Print("Character name is ambiguous. Matches:")
            for _, match in ipairs(matches) do
                Print("- " .. (match.key or self:CharacterDisplayName(match)))
            end
        else
            Print("Character not found: " .. tostring(query))
        end
        return
    end

    self:RemoveCharacterByKey(char.key)
end

function AA:PrintStatus()
    local chars = self:GetScannedCharactersSorted()
    local profileCount = 0
    if self.db and self.db.characters then
        for _, char in pairs(self.db.characters) do
            if type(char) == "table" and char.profileScanned then
                profileCount = profileCount + 1
            end
        end
    end
    Print("Version " .. VERSION .. " - " .. (self:IsEnabled() and "enabled" or "disabled") .. " - database v" .. DB_VERSION .. " - " .. #chars .. " achievement scan(s), " .. profileCount .. " character profile(s).")
    Print("Character order: " .. self:GetCharacterSortLabel() .. ".")
    Print("Realm comparison filter: " .. self:GetRealmFilterLabel() .. " (unselected realms are ignored).")

    if self.scan then
        local percent = 0
        if #self.scan.categories > 0 then
            percent = math.floor(((self.scan.categoryIndex - 1) / #self.scan.categories) * 100)
        end
        Print(string.format("Scan running for %s: about %d%%, %d achievement IDs checked so far.", self.scan.charKey, percent, self.scan.total))
    else
        local current = self.db.characters[self.currentCharacterKey]
        if current and current.scanned then
            Print("Current character last scanned: " .. FormatTimestamp(current.lastScan))
        else
            Print("Current character has not completed a scan yet.")
        end
    end
end

function AA:PrintDebug()
    local containerButtons = 0
    if AchievementFrameAchievementsContainer and type(AchievementFrameAchievementsContainer.buttons) == "table" then
        for _ in pairs(AchievementFrameAchievementsContainer.buttons) do
            containerButtons = containerButtons + 1
        end
    end

    Print("Debug: Blizzard_AchievementUI loaded=" .. tostring(IsAddOnLoaded("Blizzard_AchievementUI") and true or false) ..
        ", AchievementFrame=" .. tostring(AchievementFrame ~= nil) ..
        ", container buttons=" .. tostring(containerButtons) ..
        ", hooked buttons=" .. tostring(self.hookedAchievementButtons or 0) ..
        ", unique tab=" .. tostring(self.uniqueTab and self.uniqueTab:GetID() or "not created") ..
        ", missing tab=" .. tostring(self.missingTab and self.missingTab:GetID() or "not created") .. ".")

    if containerButtons > 0 and (self.hookedAchievementButtons or 0) == 0 then
        Print("Debug warning: achievement buttons exist but none are hooked. Use /reload and run /alt debug again.")
    end
end

function AA:PrintHelp()
    Print("Commands:")
    Print("/alt overview - open the character overview")
    Print("/alt scan - rescan current professions, legendary quests and achievements")
    Print("/alt profile - rescan professions, collections, statistics and legendary-quest progress")
    Print("/alt recipes <text> - search stored recipes across selected realms")
    Print("/alt recipescan - open the current character recipe-scan guide")
    Print("/alt chars - list scanned characters and last scan time")
    Print("/alt unique - count unique achievements per character")
    Print("/alt uniqueui - open the embedded Unique tab")
    Print("/alt missing - open achievements missing from every scanned character in the selected realm scope")
    Print("/alt unique <character> [page] - list that character's unique achievements")
    Print("/alt who <achievementID> - show who has / misses one achievement")
    Print("/alt status - show addon and scan status")
    Print("/alt debug - show Achievement UI hook diagnostics")
    Print("/alt options - open Interface > AddOns > Alternator")
    Print("/alt backups - open the Backup Manager")
    Print("/alt remove <character> - remove a stored character")
    Print("/alt reset confirm - erase the entire Alternator database")
end

function AA:HandleSlashCommand(message)
    message = Trim(message)
    if message == "" or message == "help" then
        self:PrintHelp()
        return
    end

    local args = {}
    for word in string.gmatch(message, "%S+") do
        table.insert(args, word)
    end

    local command = Lower(args[1])

    if command == "overview" or command == "table" or command == "dashboard" then
        self:ToggleDashboard()

    elseif command == "scan" then
        self:ScanCurrentCharacterProfile(false)
        self:StartScan(true)

    elseif command == "profile" then
        self:ScanCurrentCharacterProfile(false)

    elseif command == "recipes" or command == "recipe" then
        local query = table.concat(args, " ", 2)
        self:SearchRecipes(query)

    elseif command == "recipescan" or command == "recipe-scan" then
        self:ShowRecipeGuide()

    elseif command == "chars" or command == "characters" then
        self:PrintCharacters()

    elseif command == "unique" then
        if not args[2] then
            self:PrintUniqueSummary()
        else
            local char, reason, matches = self:ResolveCharacter(args[2])
            if char then
                self:PrintUniqueForCharacter(char, args[3])
            elseif reason == "ambiguous" then
                Print("Character name is ambiguous. Matches:")
                for _, match in ipairs(matches) do
                    Print("- " .. (match.key or self:CharacterDisplayName(match)))
                end
            else
                Print("Character not found: " .. tostring(args[2]))
            end
        end

    elseif command == "uniqueui" or command == "ui" then
        self:OpenUniqueTab()

    elseif command == "missing" or command == "missingui" then
        self:OpenMissingTab()

    elseif command == "who" then
        self:PrintWho(args[2])

    elseif command == "options" or command == "config" then
        self:OpenOptions()

    elseif command == "backups" or command == "backup" then
        self:OpenBackupManager()

    elseif command == "status" then
        self:PrintStatus()

    elseif command == "debug" then
        self:PrintDebug()

    elseif command == "remove" or command == "purge" then
        if not args[2] then
            Print("Usage: /alt remove <character>")
        else
            self:RemoveCharacter(args[2])
        end

    elseif command == "reset" then
        if Lower(args[2]) == "confirm" then
            AlternatorDB = {
                version = DB_VERSION,
                characters = {},
                settings = {
                    enabled = self:IsEnabled(),
                    characterSort = self:GetCharacterSortMode(),
                    uniqueViewMode = self:GetUniqueViewMode(),
                    dashboardView = self:GetDashboardView(),
                    dashboardSection = self.db.settings.dashboardSection or "characters",
                    dashboardTab = self.db.settings.dashboardTab or "overview",
                    shownCurrencies = self.db.settings.shownCurrencies or {},
                    currencyDefaultsInitialized = true,
                    selectedCharacterKey = self.db.settings.selectedCharacterKey,
                    realmFilterAll = self:IsRealmFilterAll(),
                    selectedRealms = self.db.settings.selectedRealms or {},
                    minimap = { hide = not self:IsMinimapButtonShown(), x = self.db.settings.minimap and self.db.settings.minimap.x, y = self.db.settings.minimap and self.db.settings.minimap.y },
                    dashboardSize = { width = self.dashboardFrame and self.dashboardFrame:GetWidth() or DASHBOARD_WIDTH, height = self.dashboardFrame and self.dashboardFrame:GetHeight() or DASHBOARD_HEIGHT },
                },
                createdAt = time(),
                lastAddonVersion = VERSION,
                backupStorageInstanceId = self.db and self.db.backupStorageInstanceId or nil,
            }
            self.db = AlternatorDB
            self.scan = nil
            self.profileScanAt = nil
            self:UpdateCurrentCharacterMetadata()
            self:InvalidateIndex()
            if self.uniqueFrame and self.uniqueFrame:IsShown() then
                self:RefreshUniqueTab(true)
            end
            if self.missingFrame and self.missingFrame:IsShown() then
                self:RefreshMissingTab(true)
            end
            if self.dashboardFrame and self.dashboardFrame:IsShown() then
                self:RefreshDashboard(true)
            end
            Print("Database reset. The current character will be scanned again shortly.")
            self.profileScanAt = GetTime() + 0.5
            self.autoScanAt = GetTime() + 1
        else
            Print("This erases all scanned character data. Use /alt reset confirm to continue.")
        end

    else
        Print("Unknown command: " .. tostring(args[1]))
        self:PrintHelp()
    end
end


-- ============================================================================
-- Alternator 0.3.0 main window
-- Alt-manager style master/detail layout.  The previous account-wide tables are
-- intentionally retained under the Summary tab instead of being discarded.
-- ============================================================================

local function MainCurrencyShown(currencyID)
    return AA.db and AA.db.settings and AA.db.settings.shownCurrencies
        and AA.db.settings.shownCurrencies[tostring(currencyID)] == true
end

local function MainFormatMoney(copper)
    copper = tonumber(copper) or 0
    if type(GetCoinTextureString) == "function" then
        return GetCoinTextureString(copper)
    end
    local gold = math.floor(copper / 10000)
    local silver = math.floor((copper % 10000) / 100)
    local bronze = copper % 100
    return string.format("%dg %ds %dc", gold, silver, bronze)
end

local function MainFormatStatisticMoney(copper)
    if copper == nil then return "Not scanned" end
    copper = math.floor(tonumber(copper) or 0)
    if copper < 0 then return "-" .. MainFormatMoney(math.abs(copper)) end
    return MainFormatMoney(copper)
end

local function MainCurrencyTexture(def, info)
    -- Currency icons belong to the currency type, not to a character snapshot.
    -- Older/unscanned character records may not contain info.texture, so resolve
    -- it account-wide and cache it once for every character card.
    local texture = info and info.texture
    if texture then
        if AA.db then
            AA.db.currencyTextures = type(AA.db.currencyTextures) == "table" and AA.db.currencyTextures or {}
            if def and def.id then AA.db.currencyTextures[tostring(def.id)] = texture end
        end
        return texture
    end

    local key = def and def.id and tostring(def.id) or nil
    if key and AA.db and type(AA.db.currencyTextures) == "table" and AA.db.currencyTextures[key] then
        return AA.db.currencyTextures[key]
    end

    -- Backfill from any character that already has a modern currency snapshot.
    if key and AA.db and type(AA.db.characters) == "table" then
        for _, char in pairs(AA.db.characters) do
            local saved = char and char.currencies and char.currencies[key]
            if saved and saved.texture then
                AA.db.currencyTextures = type(AA.db.currencyTextures) == "table" and AA.db.currencyTextures or {}
                AA.db.currencyTextures[key] = saved.texture
                return saved.texture
            end
        end
    end

    -- Last resort: ask the currently logged-in client's currency table.  This is
    -- only used to learn the shared icon; the amount still comes from the selected
    -- character's stored snapshot.
    if def and def.id and type(GetCurrencyInfo) == "function" then
        local ok, name, amount, liveTexture = pcall(GetCurrencyInfo, def.id)
        if ok and liveTexture then
            if AA.db and key then
                AA.db.currencyTextures = type(AA.db.currencyTextures) == "table" and AA.db.currencyTextures or {}
                AA.db.currencyTextures[key] = liveTexture
            end
            return liveTexture
        end
    end

    return "Interface\\Icons\\INV_Misc_QuestionMark"
end

local function MainFormatCurrencyCompact(def, info)
    local amount = tonumber(info and info.amount) or 0
    local texture = MainCurrencyTexture(def, info)
    return string.format("|T%s:12:12:0:0|t %d", tostring(texture), amount)
end

local CURRENCY_ALERT_THRESHOLD = 0.90

local function CurrencyAlertState(info, def)
    if type(info) ~= "table" then return nil end

    local amount = tonumber(info.amount) or 0
    -- Some 5.4.8/private-server cores expose a positive but incorrect totalMax
    -- for currencies such as Valor Points.  alertCap is authoritative for the
    -- warning system; totalCap remains the fallback used when the API has no cap.
    local totalMax = def and tonumber(def.alertCap) or 0
    if totalMax <= 0 then totalMax = tonumber(info.totalMax) or 0 end
    if totalMax <= 0 and def then totalMax = tonumber(def.totalCap) or 0 end
    local earnedThisWeek = tonumber(info.earnedThisWeek) or 0
    local weeklyMax = tonumber(info.weeklyMax) or 0
    local level = nil
    local details = {}

    if totalMax > 0 then
        local ratio = amount / totalMax
        if amount >= totalMax then
            level = "cap"
            table.insert(details, string.format("Current %d / %d (CAP)", amount, totalMax))
        elseif ratio >= CURRENCY_ALERT_THRESHOLD then
            level = level or "near"
            table.insert(details, string.format("Current %d / %d (Near cap)", amount, totalMax))
        end
    end

    if weeklyMax > 0 then
        local ratio = earnedThisWeek / weeklyMax
        if earnedThisWeek >= weeklyMax then
            level = "cap"
            table.insert(details, string.format("Weekly %d / %d (CAP)", earnedThisWeek, weeklyMax))
        elseif ratio >= CURRENCY_ALERT_THRESHOLD then
            if level ~= "cap" then level = level or "near" end
            table.insert(details, string.format("Weekly %d / %d (Near cap)", earnedThisWeek, weeklyMax))
        end
    end

    if not level then return nil end
    return {
        level = level,
        amount = amount,
        totalMax = totalMax,
        earnedThisWeek = earnedThisWeek,
        weeklyMax = weeklyMax,
        detail = table.concat(details, " • "),
    }
end

local function CurrencyAlertColor(level)
    if level == "cap" then return 1.0, 0.20, 0.20 end
    if level == "near" then return 1.0, 0.60, 0.10 end
    return 1.0, 0.82, 0.0
end

local function MainLocationText(char)
    if not char then return "Unknown location" end
    local zone = char.zone or "Unknown location"
    local sub = char.subzone
    if sub and sub ~= "" and sub ~= zone then
        return sub .. " - " .. zone
    end
    return zone
end

local function MainClassColor(char)
    local color = char and char.class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[char.class]
    if color then return color.r or 1, color.g or 1, color.b or 1 end
    return 1, 1, 1
end

local function MainPanel(parent, levelOffset)
    local frame = CreateFrame("Frame", nil, parent)
    frame:SetFrameLevel(parent:GetFrameLevel() + (levelOffset or 1))
    frame:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 16, edgeSize = 14,
        insets = { left = 4, right = 4, top = 4, bottom = 4 },
    })
    frame:SetBackdropColor(0.035, 0.025, 0.015, 1)
    frame:SetBackdropBorderColor(0.62, 0.44, 0.16, 1)
    return frame
end

-- Outer master/detail panes use the same clean, one-pixel visual language as
-- the main navigation tabs. Smaller profession/collection cards keep MainPanel.
local function MainShellPanel(parent, levelOffset)
    local frame = CreateFrame("Frame", nil, parent)
    frame:SetFrameLevel(parent:GetFrameLevel() + (levelOffset or 1))

    frame.bgTexture = frame:CreateTexture(nil, "BACKGROUND")
    frame.bgTexture:SetPoint("TOPLEFT", frame, "TOPLEFT", 1, -1)
    frame.bgTexture:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -1, 1)
    frame.bgTexture:SetTexture(0.018, 0.016, 0.014, 1)

    frame.borderTextures = {}
    local top = frame:CreateTexture(nil, "BORDER")
    top:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0)
    top:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 0, 0)
    top:SetHeight(1)
    table.insert(frame.borderTextures, top)
    local left = frame:CreateTexture(nil, "BORDER")
    left:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0)
    left:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 0, 0)
    left:SetWidth(1)
    table.insert(frame.borderTextures, left)
    local right = frame:CreateTexture(nil, "BORDER")
    right:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 0, 0)
    right:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", 0, 0)
    right:SetWidth(1)
    table.insert(frame.borderTextures, right)
    local bottom = frame:CreateTexture(nil, "BORDER")
    bottom:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 0, 0)
    bottom:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", 0, 0)
    bottom:SetHeight(1)
    table.insert(frame.borderTextures, bottom)

    for _, edge in ipairs(frame.borderTextures) do
        edge:SetTexture(0.50, 0.37, 0.16, 1)
    end
    return frame
end

local function MainSectionTitle(parent, textValue)
    local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    fs:SetText(textValue or "")
    fs:SetTextColor(1, 0.82, 0)
    return fs
end

local function MainSmallText(parent)
    local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    fs:SetTextColor(0.86, 0.86, 0.86)
    return fs
end

local function MainCompactText(value, maxChars)
    value = tostring(value or "")
    maxChars = tonumber(maxChars) or 40
    if string.len(value) <= maxChars then return value end
    return string.sub(value, 1, math.max(1, maxChars - 3)) .. "..."
end

local function SetMainTabBorderColor(button, r, g, b, a)
    if not button or not button.borderTextures then return end
    for _, tex in ipairs(button.borderTextures) do
        tex:SetTexture(r, g, b, a or 1)
    end
end

local function StyleMainTabButton(button, active)
    if not button then return end
    button._alternatorActive = active and true or false
    if active then
        -- The selected tab uses exactly the same fill as the detail pane.
        if button.bgTexture then
            button.bgTexture:ClearAllPoints()
            button.bgTexture:SetPoint("TOPLEFT",button,"TOPLEFT",1,-1)
            button.bgTexture:SetPoint("BOTTOMRIGHT",button,"BOTTOMRIGHT",-1,-1)
            button.bgTexture:SetTexture(0.018, 0.016, 0.014, 1)
        end
        SetMainTabBorderColor(button, 0.50, 0.37, 0.16, 1)
        if button.label then button.label:SetTextColor(1.00, 0.86, 0.30) end
        -- No tab owns a bottom border.  The content pane's top border is the
        -- single baseline for inactive tabs; this mask removes it below the
        -- active tab so the selected page visually flows into the pane.
        if button.bottomBorder then button.bottomBorder:Hide() end
        if button.joinTexture then button.joinTexture:Show() end
        if button.activeLine then button.activeLine:Hide() end
    else
        if button.bgTexture then
            button.bgTexture:ClearAllPoints()
            button.bgTexture:SetPoint("TOPLEFT",button,"TOPLEFT",1,-1)
            button.bgTexture:SetPoint("BOTTOMRIGHT",button,"BOTTOMRIGHT",-1,1)
            button.bgTexture:SetTexture(0.035, 0.032, 0.028, 1)
        end
        SetMainTabBorderColor(button, 0.32, 0.28, 0.22, 1)
        if button.label then button.label:SetTextColor(0.88, 0.72, 0.22) end
        if button.bottomBorder then button.bottomBorder:Hide() end
        if button.joinTexture then button.joinTexture:Hide() end
        if button.activeLine then button.activeLine:Hide() end
    end
end

function AA:UpdateMainSectionStyles(activeSection)
    local frame = self.dashboardFrame
    if not frame or not frame.sectionButtons then return end
    for value, button in pairs(frame.sectionButtons) do
        StyleMainTabButton(button, value == activeSection)
    end
end

function AA:GetMainDashboardSection()
    if not self.db then self:InitializeDatabase() end
    local section = self.db.settings.dashboardSection
    if section ~= "summary" and section ~= "characters" then
        section = "characters"
        self.db.settings.dashboardSection = section
    end
    return section
end

function AA:SetMainDashboardSection(section)
    if not self.db then self:InitializeDatabase() end
    if section ~= "summary" and section ~= "characters" then section = "characters" end
    self.db.settings.dashboardSection = section
    self:RefreshDashboard(true)
end

function AA:UpdateMainTabStyles(activeTab)
    local frame = self.dashboardFrame
    if not frame or not frame.tabButtons then return end
    for value, button in pairs(frame.tabButtons) do
        StyleMainTabButton(button, value == activeTab)
    end
end

function AA:GetMainDashboardTab()
    if not self.db then self:InitializeDatabase() end
    local tab = self.db.settings.dashboardTab or "overview"
    for _, option in ipairs(MAIN_TAB_OPTIONS) do
        if option.value == tab then return tab end
    end
    return "overview"
end

function AA:SetMainDashboardTab(tab)
    if not self.db then self:InitializeDatabase() end
    local valid = false
    for _, option in ipairs(MAIN_TAB_OPTIONS) do
        if option.value == tab then valid = true break end
    end
    if not valid then tab = "overview" end
    self.db.settings.dashboardSection = "characters"
    self.db.settings.dashboardTab = tab
    self:RefreshDashboard(true)
end

function AA:SelectCurrentCharacterForDashboardSession()
    if not self.db or not self.db.settings or not self.currentCharacterKey then
        return
    end

    -- Reset the dashboard character selection once for each login session.
    -- During the same session the user can browse another character, close the
    -- window, and reopen it without losing that selection.  A real relog runs
    -- PLAYER_LOGIN again and intentionally returns the dashboard selection to
    -- the character that is now online.
    self.db.settings.selectedCharacterKey = self.currentCharacterKey
end

function AA:GetSelectedDashboardCharacter(chars)
    chars = chars or self:GetDashboardCharactersSorted()
    if #chars == 0 then return nil end
    local wanted = self.db and self.db.settings and self.db.settings.selectedCharacterKey
    if wanted then
        for _, char in ipairs(chars) do
            if char.key == wanted then return char end
        end
    end
    if self.currentCharacterKey then
        for _, char in ipairs(chars) do
            if char.key == self.currentCharacterKey then
                self.db.settings.selectedCharacterKey = char.key
                return char
            end
        end
    end
    self.db.settings.selectedCharacterKey = chars[1].key
    return chars[1]
end

function AA:SetSelectedDashboardCharacter(charKey)
    if not self.db then self:InitializeDatabase() end
    self.db.settings.selectedCharacterKey = charKey
    self:RefreshDashboard(false)
end

local function MainCharacterCardCurrencyText(char)
    local parts = { MainFormatMoney(AA:GetStoredCharacterMoney(char)) }
    local shown = 0
    local hidden = 0
    for _, def in ipairs(TRACKED_CURRENCIES) do
        if MainCurrencyShown(def.id) then
            local info = char and char.currencies and char.currencies[tostring(def.id)]
            if shown < 2 then
                table.insert(parts, MainFormatCurrencyCompact(def, info))
                shown = shown + 1
            else
                hidden = hidden + 1
            end
        end
    end
    if hidden > 0 then table.insert(parts, "+" .. tostring(hidden) .. " more") end
    return table.concat(parts, "   ")
end

function AA:ShowCharacterCardTooltip(card)
    local char = card and card.char
    if not char then return end
    GameTooltip:SetOwner(card, "ANCHOR_RIGHT")
    GameTooltip:ClearLines()
    local r, g, b = MainClassColor(char)
    GameTooltip:AddLine((char.name or "Unknown") .. "-" .. (char.realm or "?"), r, g, b)
    GameTooltip:AddDoubleLine("Level", tostring(char.level or 0), 0.7,0.7,0.7, 1,1,1)
    GameTooltip:AddDoubleLine("Location", MainLocationText(char), 0.7,0.7,0.7, 1,1,1)
    GameTooltip:AddDoubleLine("Gold", MainFormatMoney(self:GetStoredCharacterMoney(char)), 0.7,0.7,0.7, 1,1,1)
    for _, def in ipairs(TRACKED_CURRENCIES) do
        if MainCurrencyShown(def.id) then
            local info = char.currencies and char.currencies[tostring(def.id)]
            GameTooltip:AddDoubleLine((info and info.name) or def.name, tostring(info and info.amount or 0), 0.7,0.7,0.7, 1,0.82,0)
        end
    end
    GameTooltip:AddDoubleLine("Last seen", FormatTimestamp(char.lastSeen or char.profileScanAt), 0.7,0.7,0.7, 1,1,1)
    GameTooltip:Show()
end

function AA:RefreshMainCharacterList(chars)
    local frame = self.dashboardFrame
    if not frame or not frame.characterPane then return end
    chars = chars or self:GetDashboardCharactersSorted()
    local pane = frame.characterPane
    local listHeight = math.max(CHARACTER_CARD_HEIGHT, (pane.scroll and pane.scroll:GetHeight() or (pane:GetHeight() - 78)))
    local visible = math.max(1, math.min(CHARACTER_CARD_MAX_ROWS, math.floor(listHeight / CHARACTER_CARD_HEIGHT)))
    local offset = pane.scroll and FauxScrollFrame_GetOffset(pane.scroll) or 0
    if pane.scroll then
        FauxScrollFrame_Update(pane.scroll, #chars, visible, CHARACTER_CARD_HEIGHT)
        offset = FauxScrollFrame_GetOffset(pane.scroll) or 0
    end
    local selected = self:GetSelectedDashboardCharacter(chars)
    for i = 1, CHARACTER_CARD_MAX_ROWS do
        local card = pane.cards[i]
        local char = chars[offset + i]
        if i <= visible and char then
            card.char = char
            card:Show()
            local r,g,b = MainClassColor(char)
            card.name:SetText((char.name or "Unknown") .. (char.key == self.currentCharacterKey and " (you)" or ""))
            card.name:SetTextColor(r,g,b)
            card.meta:SetText(string.format("Level %d   %s", tonumber(char.level) or 0, char.realm or "?"))
            card.location:SetText(MainCompactText(MainLocationText(char), 55))
            card.resources:SetText(MainCharacterCardCurrencyText(char))
            if card.classIcon then
                local coords = CLASS_ICON_TCOORDS and char.class and CLASS_ICON_TCOORDS[char.class]
                if coords then
                    card.classIcon:SetTexture("Interface\\GLUES\\CHARACTERCREATE\\UI-CHARACTERCREATE-CLASSES")
                    card.classIcon:SetTexCoord(coords[1], coords[2], coords[3], coords[4])
                else
                    card.classIcon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
                    card.classIcon:SetTexCoord(0,1,0,1)
                end
            end
            if selected and selected.key == char.key then
                card.selectedBG:SetTexture(0.32, 0.18, 0.03, 0.55)
                card.selectedBG:Show()
                card.border:SetBackdropBorderColor(1, 0.72, 0.18, 1)
                if card.selectedStripe then card.selectedStripe:Hide() end
            else
                card.selectedBG:Hide()
                card.border:SetBackdropBorderColor(0.28, 0.28, 0.28, 1)
                if card.selectedStripe then card.selectedStripe:Hide() end
            end
        else
            card.char = nil
            card:Hide()
        end
    end
    pane.count:SetText(string.format("Characters: %d", #chars))
end

local MainCharacterActiveSpecialization

local HEADER_TEXTURE_BASE = "Interface\\AddOns\\Alternator\\Textures\\Headers\\"
local HEADER_CLASS_ICON_BASE = "Interface\\AddOns\\Alternator\\Textures\\HeaderClassIcons\\"

local HEADER_SPEC_SUFFIX_BY_ID = {
    [62] = "ARCANE", [63] = "FIRE", [64] = "FROST",
    [65] = "HOLY", [66] = "PROTECTION", [70] = "RETRIBUTION",
    [71] = "ARMS", [72] = "FURY", [73] = "PROTECTION",
    [102] = "BALANCE", [103] = "FERAL", [104] = "GUARDIAN", [105] = "RESTORATION",
    [250] = "BLOOD", [251] = "FROST", [252] = "UNHOLY",
    [253] = "BEASTMASTERY", [254] = "MARKSMANSHIP", [255] = "SURVIVAL",
    [256] = "DISCIPLINE", [257] = "HOLY", [258] = "SHADOW",
    [259] = "ASSASSINATION", [260] = "COMBAT", [261] = "SUBTLETY",
    [262] = "ELEMENTAL", [263] = "ENHANCEMENT", [264] = "RESTORATION",
    [265] = "AFFLICTION", [266] = "DEMONOLOGY", [267] = "DESTRUCTION",
    [268] = "BREWMASTER", [269] = "WINDWALKER", [270] = "MISTWEAVER",
}

local HEADER_SPEC_SUFFIX_BY_NAME = {
    ["arcane"] = "ARCANE", ["fire"] = "FIRE", ["frost"] = "FROST",
    ["holy"] = "HOLY", ["protection"] = "PROTECTION", ["retribution"] = "RETRIBUTION",
    ["arms"] = "ARMS", ["fury"] = "FURY",
    ["balance"] = "BALANCE", ["feral"] = "FERAL", ["guardian"] = "GUARDIAN", ["restoration"] = "RESTORATION",
    ["blood"] = "BLOOD", ["unholy"] = "UNHOLY",
    ["beast mastery"] = "BEASTMASTERY", ["marksmanship"] = "MARKSMANSHIP", ["survival"] = "SURVIVAL",
    ["discipline"] = "DISCIPLINE", ["shadow"] = "SHADOW",
    ["assassination"] = "ASSASSINATION", ["combat"] = "COMBAT", ["subtlety"] = "SUBTLETY",
    ["elemental"] = "ELEMENTAL", ["enhancement"] = "ENHANCEMENT",
    ["affliction"] = "AFFLICTION", ["demonology"] = "DEMONOLOGY", ["destruction"] = "DESTRUCTION",
    ["brewmaster"] = "BREWMASTER", ["windwalker"] = "WINDWALKER", ["mistweaver"] = "MISTWEAVER",
}

local function BuildDetailHeaderTexturePath(char)
    if not char or not char.class or char.class == "" then
        return HEADER_TEXTURE_BASE .. "DEFAULT.tga"
    end
    local classToken = string.upper(Trim(char.class or ""))
    return HEADER_TEXTURE_BASE .. classToken .. ".tga"
end

local function BuildDetailHeaderClassIconPath(char)
    if not char or not char.class or char.class == "" then
        return HEADER_CLASS_ICON_BASE .. "DEFAULT.tga"
    end
    local classToken = string.upper(Trim(char.class or ""))
    return HEADER_CLASS_ICON_BASE .. classToken .. ".tga"
end

MainCharacterActiveSpecialization = function(char)
    if not char then return nil end
    local specs = char.specializations
    if type(specs) == "table" then
        if tonumber(specs.activeGroup) == 2 then
            return specs.secondary or specs.primary or char.specialization
        end
        return specs.primary or specs.secondary or char.specialization
    end
    return char.specialization
end

local function RefreshDetailHeaderArt(panel, char)
    if not panel or not char then return end
    local r, g, b = MainClassColor(char)

    if panel.headerBanner then
        -- Textured header art is class-only. The active specialization never
        -- changes the banner: every druid uses DRUID.tga, every priest PRIEST.tga, etc.
        panel.headerBanner:SetTexture(BuildDetailHeaderTexturePath(char))
        panel.headerBanner:SetTexCoord(0, 1, 0, 1)
        panel.headerBanner:SetVertexColor(1, 1, 1, 1)
        panel.headerBanner:SetAlpha(1)
        panel.headerBanner:Show()
    end

    if panel.headerTint then panel.headerTint:Hide() end

    if panel.headerClassArt then
        panel.headerClassArt:SetTexture(BuildDetailHeaderClassIconPath(char))
        panel.headerClassArt:SetTexCoord(0, 1, 0, 1)
        panel.headerClassArt:SetAlpha(1)
        panel.headerClassArt:Show()
    end
    if panel.headerClassBackdrop then panel.headerClassBackdrop:Hide() end
    if panel.headerClassBorder then panel.headerClassBorder:Hide() end
    if panel.headerSpecArt then panel.headerSpecArt:Hide() end
    if panel.headerSpecBorder then panel.headerSpecBorder:Hide() end

    if panel.headerBottomLine then
        panel.headerBottomLine:SetTexture(r, g, b, 0.72)
    end
end

local function BuildArmoryRealmSlug(realm)
    local value = string.lower(Trim(tostring(realm or "")))
    if value == "persés" or value == "perses" then return "perses" end
    if value == "helios" then return "helios" end
    value = string.gsub(value, "%s+", "")
    return value
end

local function BuildArmoryURL(char)
    if not char or not char.name or not char.realm then return nil end
    local realm = BuildArmoryRealmSlug(char.realm)
    if realm == "" then return nil end
    return "https://armory.twinstar-wow.com/" .. realm .. "/character/" .. tostring(char.name)
end

function AA:ShowArmoryLinkPopup(char)
    local url = BuildArmoryURL(char)
    if not url then return end

    local frame = self.armoryLinkFrame
    if not frame then
        frame = CreateFrame("Frame", "AlternatorArmoryLinkFrame", UIParent)
        frame:SetSize(540, 142)
        frame:SetFrameStrata("FULLSCREEN_DIALOG")
        frame:SetFrameLevel(100)
        if frame.SetToplevel then frame:SetToplevel(true) end
        frame:SetClampedToScreen(true)
        frame:SetMovable(true)
        frame:EnableMouse(true)
        frame:RegisterForDrag("LeftButton")

        local saved = self.db and self.db.settings and self.db.settings.armoryPopupPosition
        if type(saved) == "table" and tonumber(saved.x) and tonumber(saved.y) then
            frame:SetPoint("CENTER", UIParent, "CENTER", tonumber(saved.x), tonumber(saved.y))
        else
            frame:SetPoint("CENTER", UIParent, "CENTER", 0, 80)
        end

        frame:SetScript("OnDragStart", function(self)
            self:StartMoving()
        end)
        frame:SetScript("OnDragStop", function(self)
            self:StopMovingOrSizing()
            local fx, fy = self:GetCenter()
            local ux, uy = UIParent:GetCenter()
            if fx and fy and ux and uy and AA.db and AA.db.settings then
                AA.db.settings.armoryPopupPosition = {
                    x = math.floor((fx - ux) + 0.5),
                    y = math.floor((fy - uy) + 0.5),
                }
            end
        end)
        frame:SetBackdrop({
            bgFile="Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
            edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",
            tile=true, tileSize=16, edgeSize=14,
            insets={left=4,right=4,top=4,bottom=4},
        })
        frame:SetBackdropColor(0.035,0.025,0.015,1)
        frame:SetBackdropBorderColor(0.62,0.44,0.16,1)
        local opaqueBG = frame:CreateTexture(nil, "BACKGROUND")
        opaqueBG:SetPoint("TOPLEFT", frame, "TOPLEFT", 5, -5)
        opaqueBG:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -5, 5)
        opaqueBG:SetTexture(0.018,0.016,0.014,1)
        frame.opaqueBG = opaqueBG

        local logo = frame:CreateTexture(nil, "ARTWORK")
        logo:SetSize(58,58)
        logo:SetPoint("TOPLEFT", frame, "TOPLEFT", 16, -12)
        logo:SetTexture("Interface\\AddOns\\Alternator\\Textures\\TwinStarLogo")
        logo:SetTexCoord(0,1,0,1)
        frame.logo = logo

        local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOPLEFT", logo, "TOPRIGHT", 10, -5)
        title:SetText("TwinStar Armory")

        local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
        close:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -6, -6)

        local help = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        help:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -7)
        help:SetPoint("RIGHT", frame, "RIGHT", -34, 0)
        help:SetJustifyH("LEFT")
        help:SetText("Press Ctrl+C to copy the selected character Armory link. Drag this window to move it.")
        help:SetTextColor(.72,.72,.72)

        local edit = CreateFrame("EditBox", "AlternatorArmoryLinkEditBox", frame, "InputBoxTemplate")
        edit:SetPoint("TOPLEFT", frame, "TOPLEFT", 24, -94)
        edit:SetPoint("RIGHT", frame, "RIGHT", -24, 0)
        edit:SetHeight(22)
        edit:SetAutoFocus(false)
        edit:SetScript("OnEscapePressed", function(self) self:ClearFocus(); frame:Hide() end)
        edit:SetScript("OnEnterPressed", function(self) self:HighlightText(0, -1) end)
        edit:SetScript("OnEditFocusGained", function(self) self:HighlightText(0, -1) end)
        edit:SetScript("OnMouseUp", function(self, button)
            if button ~= "LeftButton" then return end
            local now = GetTime()
            if self._alternatorLastClick and (now - self._alternatorLastClick) <= 0.35 then
                self:SetFocus()
                self:HighlightText(0, -1)
                self._alternatorLastClick = nil
            else
                self._alternatorLastClick = now
            end
        end)
        frame.editBox = edit

        self.armoryLinkFrame = frame
    end

    frame.editBox:SetText(url)
    frame:Show()
    frame:Raise()
    frame.editBox:SetFocus()
    frame.editBox:HighlightText(0, -1)
end

local function MainSetDetailHeader(panel, char, titleText)
    if not panel or not char then return end
    panel.title:SetText(titleText or "")
    local r, g, b = MainClassColor(char)
    panel.charName:SetText((char.name or "Unknown") .. "-" .. (char.realm or "?"))
    panel.charName:SetTextColor(r, g, b)
    if panel.charName.SetShadowColor then panel.charName:SetShadowColor(0, 0, 0, 1) end
    if panel.charName.SetShadowOffset then panel.charName:SetShadowOffset(1, -1) end
    RefreshDetailHeaderArt(panel, char)
end

local function MainCharacterRaceText(char)
    if not char then return "Not scanned" end
    local value = char.race or char.raceName or char.raceFile
    if value and value ~= "" then return tostring(value) end
    return "Not scanned"
end

local function MainCharacterGenderText(char)
    if not char then return "Not scanned" end
    if char.gender and char.gender ~= "" then return tostring(char.gender) end
    local sex = tonumber(char.sex)
    if sex == 2 then return "Male" end
    if sex == 3 then return "Female" end
    return "Not scanned"
end

function AA:RefreshOverviewDetail(char)
    local panel = self.dashboardFrame and self.dashboardFrame.detailFrames and self.dashboardFrame.detailFrames.overview
    if not panel or not char then return end
    MainSetDetailHeader(panel, char, "Character Overview")
    if panel.armoryButton then panel.armoryButton.character = char end
    panel.levelValue:SetText(tostring(char.level or 0))
    panel.realmValue:SetText(char.realm or "?")
    panel.raceValue:SetText(MainCharacterRaceText(char))
    panel.genderValue:SetText(MainCharacterGenderText(char))
    local specs = char.specializations
    if type(specs) ~= "table" then
        specs = { activeGroup = (char.specialization and char.specialization.group) or 1 }
        if char.specialization then
            if tonumber(char.specialization.group) == 2 then specs.secondary = char.specialization else specs.primary = char.specialization end
        end
    end

    local function SetSpecDisplay(prefix, spec, groupIndex)
        local value = panel[prefix .. "SpecValue"]
        local icon = panel[prefix .. "SpecIcon"]
        local hitbox = panel[prefix .. "SpecHitbox"]
        if spec and spec.name then
            local suffix = tonumber(specs.activeGroup) == tonumber(groupIndex) and "  |cffffd200(active)|r" or ""
            value:SetText((spec.name or "") .. suffix)
            if spec.icon then icon:SetTexture(spec.icon); icon:Show() else icon:Hide() end
            hitbox.specialization = spec
            hitbox.isActive = tonumber(specs.activeGroup) == tonumber(groupIndex)
        else
            local lowLevel = (tonumber(char.level) or 0) < 10
            value:SetText(lowLevel and "No specialization" or (groupIndex == 2 and "Not learned / not scanned" or "Not scanned"))
            icon:Hide()
            hitbox.specialization = nil
            hitbox.isActive = false
        end
    end

    SetSpecDisplay("primary", specs.primary, 1)
    SetSpecDisplay("secondary", specs.secondary, 2)
    panel.locationValue:SetText(MainLocationText(char))
    panel.moneyValue:SetText(MainFormatMoney(self:GetStoredCharacterMoney(char)))
    panel.lastSeenValue:SetText(FormatTimestamp(char.lastSeen or char.profileScanAt))
    if char.playedTotal ~= nil then
        panel.playedValue:SetText(FormatPlayedTime(char.playedTotal))
        panel.playedValue:SetTextColor(1, 1, 1)
    else
        panel.playedValue:SetText("Not scanned")
        panel.playedValue:SetTextColor(0.55, 0.55, 0.55)
    end
    panel.apValue:SetText(string.format("%s / %s", tostring(char.achievementPoints or "?"), tostring(char.totalAchievementPoints or "?")))
    local idx = 1
    for _, def in ipairs(TRACKED_CURRENCIES) do
        if panel.currencyRows[idx] then
            local row = panel.currencyRows[idx]
            local info = char.currencies and char.currencies[tostring(def.id)]
            row:Show()
            row.label:SetText((info and info.name) or def.name)
            row.value:SetText(tostring(info and info.amount or 0))
            local alert = CurrencyAlertState(info, def)
            if alert then
                local cr,cg,cb = CurrencyAlertColor(alert.level)
                row.value:SetTextColor(cr,cg,cb)
            else
                row.value:SetTextColor(1,0.82,0)
            end
            if info and info.texture then row.icon:SetTexture(info.texture); row.icon:Show() else row.icon:Hide() end
            idx = idx + 1
        end
    end
    while panel.currencyRows[idx] do panel.currencyRows[idx]:Hide(); idx = idx + 1 end

    local values = self:GetCharacterStatisticValues(char)
    if panel.statisticsPeriodDropDown then
        UIDropDownMenu_SetText(panel.statisticsPeriodDropDown, self:GetStatisticsPeriodLabel())
    end
    local mode = self.db and self.db.settings and self.db.settings.statisticsPeriod or "all"
    if panel.statisticsCustomFromBox then panel.statisticsCustomFromBox:SetText((self.db and self.db.settings and self.db.settings.statisticsCustomFrom) or "") end
    if panel.statisticsCustomToBox then panel.statisticsCustomToBox:SetText((self.db and self.db.settings and self.db.settings.statisticsCustomTo) or "") end
    self:RefreshStatisticsCustomRangeControls()

    local q = values.questDisplay
    if values.available then
        panel.statQuestTotalValue:SetText(q ~= nil and tostring(math.floor(q)) or "Not available")
        panel.statQuestDailyValue:SetText(values.questDaily ~= nil and tostring(math.floor(values.questDaily)) or "Not available")
        panel.statGoldTotalValue:SetText(MainFormatStatisticMoney(values.goldTotal))
        panel.statGoldLootedValue:SetText(MainFormatStatisticMoney(values.goldLooted))
        panel.statGoldQuestValue:SetText(MainFormatStatisticMoney(values.goldQuest))
        panel.statGoldAuctionValue:SetText(MainFormatStatisticMoney(values.goldAuction))
        panel.statGoldVendorValue:SetText(MainFormatStatisticMoney(values.goldVendor))
    else
        panel.statQuestTotalValue:SetText("Not scanned")
        panel.statQuestDailyValue:SetText("Not scanned")
        panel.statGoldTotalValue:SetText("Not scanned")
        panel.statGoldLootedValue:SetText("Not scanned")
        panel.statGoldQuestValue:SetText("Not scanned")
        panel.statGoldAuctionValue:SetText("Not scanned")
        panel.statGoldVendorValue:SetText("Not scanned")
    end
    panel.statQuestModeValue:SetText(values.includeRepeatables and "Repeatables included" or "Daily repeatables excluded")
    panel.statQuestModeValue:SetTextColor(values.includeRepeatables and 0.80 or 1.0, values.includeRepeatables and 0.80 or 0.72, values.includeRepeatables and 0.80 or 0.25)

    if values.scannedAt then
        panel.statisticsTrackingNote:SetText("Scanned " .. FormatTimestamp(values.scannedAt))
        panel.statisticsTrackingNote:SetTextColor(.62,.62,.62)
    elseif values.firstTrackedAt then
        panel.statisticsTrackingNote:SetText("Scanned " .. FormatTimestamp(values.firstTrackedAt))
        panel.statisticsTrackingNote:SetTextColor(.62,.62,.62)
    else
        panel.statisticsTrackingNote:SetText("Not scanned")
        panel.statisticsTrackingNote:SetTextColor(.80,.45,.35)
    end
end


local function GearQualityColor(quality)
    local q = tonumber(quality)
    if q and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[q] then
        local c = ITEM_QUALITY_COLORS[q]
        return c.r or 1, c.g or 1, c.b or 1
    end
    return 0.82, 0.82, 0.82
end

function AA:RefreshGearDetail(char)
    local panel = self.dashboardFrame and self.dashboardFrame.detailFrames and self.dashboardFrame.detailFrames.gear
    if not panel or not char then return end
    MainSetDetailHeader(panel, char, "Gear")

    local gear = type(char.gear) == "table" and char.gear or nil
    local scanned = gear and (gear.scannedAt or char.gearScannedAt)
    local isEngineer = self:CharacterHasProfessionSkillLine(char, 202)
    local isBlacksmith = self:CharacterHasProfessionSkillLine(char, 164)
    panel.showTinker = isEngineer and true or false
    if panel.LayoutGearColumns and panel.tableHeader then
        panel.LayoutGearColumns(panel.tableHeader, true, panel.showTinker)
        if panel.tableHeader.tinker then
            if panel.showTinker then panel.tableHeader.tinker:Show() else panel.tableHeader.tinker:Hide() end
        end
        for _, layoutRow in ipairs(panel.gearRows or {}) do
            panel.LayoutGearColumns(layoutRow, false, panel.showTinker)
        end
    end
    local audit = gear and BuildGearAudit(gear, char) or nil
    if gear and audit then gear.audit = audit end
    if panel.itemLevelValue then
        if gear and gear.equippedItemLevel then
            panel.itemLevelValue:SetText(string.format("%.1f", tonumber(gear.equippedItemLevel) or 0))
            panel.itemLevelValue:SetTextColor(1, 0.82, 0)
        else
            panel.itemLevelValue:SetText("Not scanned")
            panel.itemLevelValue:SetTextColor(0.55, 0.55, 0.55)
        end
    end
    if panel.scanInfo then
        panel.scanInfo:SetText(scanned and ("Stored equipment snapshot • " .. FormatTimestamp(scanned)) or "Log this character once to store its equipped gear.")
    end
    if panel.auditStatus then
        if not gear then
            panel.auditStatus:SetText("Gear audit: Not scanned")
            panel.auditStatus:SetTextColor(0.55,0.55,0.55)
        elseif audit and audit.issueCount == 0 then
            panel.auditStatus:SetText("Gear audit: No issues found")
            panel.auditStatus:SetTextColor(0.30,1.00,0.30)
        else
            local parts = {}
            if audit and audit.missingEnchants > 0 then table.insert(parts, "enchants " .. tostring(audit.missingEnchants)) end
            if audit and audit.emptySockets > 0 then table.insert(parts, "empty sockets " .. tostring(audit.emptySockets)) end
            if audit and audit.missingExtraSockets > 0 then table.insert(parts, "extra sockets " .. tostring(audit.missingExtraSockets)) end
            if audit and audit.emptySlots > 0 then table.insert(parts, "empty slots " .. tostring(audit.emptySlots)) end
            panel.auditStatus:SetText("Gear audit: " .. tostring(audit and audit.issueCount or 0) .. " issue(s)" .. (#parts > 0 and ("  •  " .. table.concat(parts, "  •  ")) or ""))
            panel.auditStatus:SetTextColor(1.00,0.62,0.15)
        end
    end

    for i, slotDef in ipairs(GEAR_SLOTS) do
        local row = panel.gearRows and panel.gearRows[i]
        if row then
            local item = gear and gear.slots and gear.slots[slotDef.key] or nil
            local slotAudit = audit and audit.slots and audit.slots[slotDef.key] or nil
            row.itemData = item
            row.auditData = slotAudit
            row.slotLabel:SetText(slotDef.label)

            if row.auditMark then
                if slotAudit and #(slotAudit.issues or {}) > 0 then row.auditMark:Show() else row.auditMark:Hide() end
            end
            if row.SetBackdropBorderColor then
                if slotAudit and #(slotAudit.issues or {}) > 0 then row:SetBackdropBorderColor(1.0,0.10,0.10,1)
                else row:SetBackdropBorderColor(0.30,0.25,0.16,0.65) end
            end

            if item and item.link then
                -- Re-read the exact item link at display time.  This fixes old
                -- snapshots too and guarantees the table uses the same final
                -- ilvl/upgrade information visible in the item's hover tooltip.
                local details = self:GearTooltipItemDetails(item.slotID or slotDef.id, item.baseItemLevel or item.itemLevel, item.link)
                if details then
                    if tonumber(details.effectiveItemLevel) then item.effectiveItemLevel = tonumber(details.effectiveItemLevel) end
                    if details.upgradeCurrent then item.upgradeCurrent = details.upgradeCurrent end
                    if details.upgradeMax then item.upgradeMax = details.upgradeMax end
                    if details.upgradeText then item.upgradeText = details.upgradeText end
                    if details.enchantText then item.enchantText = details.enchantText end
                    if details.reforgeText then item.reforgeText = details.reforgeText end
                    if details.tinkerText then item.tinkerText = details.tinkerText end
                    if details.tinkerID then item.tinkerID = details.tinkerID end
                end
                if not item.gems or #item.gems == 0 then item.gems = self:BuildGearGemSnapshot(item.link) end
                item.socketCount, item.baseSocketCount, item.extraSocketCount = AA:GearGetSocketCounts(item)

                local name = item.name
                if not name or name == "" then name = string.match(item.link, "|h%[([^%]]+)%]|h") or "Equipped item" end
                row.itemName:SetText(name)
                local r,g,b = GearQualityColor(item.quality)
                row.itemName:SetTextColor(r,g,b)
                if item.icon then row.icon:SetTexture(item.icon); row.icon:Show() else row.icon:Hide() end

                local shownLevel = tonumber(item.effectiveItemLevel)
                if not shownLevel or shownLevel <= 0 then
                    shownLevel = tonumber(item.baseItemLevel) or tonumber(item.itemLevel)
                    if shownLevel and tonumber(item.upgradeCurrent) then shownLevel = shownLevel + (tonumber(item.upgradeCurrent) * 4) end
                end
                local levelText = shownLevel and tostring(math.floor(shownLevel + 0.5)) or "—"
                if item.upgradeCurrent and item.upgradeMax then
                    levelText = levelText .. " (" .. tostring(item.upgradeCurrent) .. "/" .. tostring(item.upgradeMax) .. ")"
                end
                row.itemLevel:SetText(levelText)

                local extraSocketIndex, extraSocketLabel = self:GearGetExtraSocketDisplay(item, char, slotDef.key)
                for gemIndex=1,4 do
                    local button = row.gemButtons and row.gemButtons[gemIndex]
                    local gem = nil
                    if type(item.gems) == "table" then
                        -- New snapshots keep the original gem position in gem.index;
                        -- older snapshots were dense arrays, so support both forms.
                        for _, candidate in pairs(item.gems) do
                            if type(candidate) == "table" and tonumber(candidate.index) == gemIndex then gem = candidate; break end
                        end
                        if not gem and item.gems[gemIndex] and not item.gems[gemIndex].index then gem = item.gems[gemIndex] end
                    end
                    local isExtra = extraSocketIndex and gemIndex == extraSocketIndex
                    if button then
                        button.extraSocketLabel = isExtra and extraSocketLabel or nil
                        button.gemData = gem
                        if gem then
                            button.icon:SetTexture(gem.icon or "Interface\\Icons\\INV_Misc_Gem_01")
                            button.icon:SetVertexColor(1,1,1,1)
                            if button.emptyPlus then button.emptyPlus:Hide() end
                            button:Show()
                        elseif isExtra then
                            button.icon:SetTexture("Interface\\ItemSocketingFrame\\UI-EmptySocket-Prismatic")
                            button.icon:SetVertexColor(.75,.75,.75,1)
                            if button.emptyPlus then button.emptyPlus:Show() end
                            button:Show()
                        else
                            if button.emptyPlus then button.emptyPlus:Hide() end
                            button:Hide()
                        end
                        if button.extraBorder then
                            if isExtra then button.extraBorder:Show() else button.extraBorder:Hide() end
                        end
                    end
                end

                if row.enchantBox then
                    row.enchantBox.itemData = item
                    local ench = self:GearCleanEnchantText(item.enchantText)
                    if ench ~= "" then
                        row.enchantBox.text:SetText(ench)
                        row.enchantBox.text:SetTextColor(.25,1,.25)
                        row.enchantBox:Show()
                    elseif tonumber(item.enchantID) and tonumber(item.enchantID) > 0 then
                        row.enchantBox.text:SetText("Enchant #" .. tostring(item.enchantID))
                        row.enchantBox.text:SetTextColor(.25,1,.25)
                        row.enchantBox:Show()
                    elseif GearItemShouldHaveEnchant(slotDef.key, item) then
                        row.enchantBox.text:SetText("Missing")
                        row.enchantBox.text:SetTextColor(1,.18,.18)
                        row.enchantBox:Show()
                    else
                        row.enchantBox.text:SetText("—")
                        row.enchantBox.text:SetTextColor(.48,.48,.48)
                        row.enchantBox:Show()
                    end
                end

                if row.tinkerBox then
                    row.tinkerBox.itemData = item
                    local tinker = tostring(item.tinkerText or "")
                    row.tinkerBox.text:SetText(tinker ~= "" and tinker or "—")
                    if tinker ~= "" then row.tinkerBox.text:SetTextColor(.95,.65,.15)
                    else row.tinkerBox.text:SetTextColor(.48,.48,.48) end
                    if panel.showTinker then row.tinkerBox:Show() else row.tinkerBox:Hide() end
                end

                if row.reforgeBox then
                    row.reforgeBox.itemData = item
                    local reforged = self:GearCleanReforgeText(item.reforgeText)
                    row.reforgeBox.text:SetText(reforged ~= "" and reforged or "—")
                    if reforged ~= "" then row.reforgeBox.text:SetTextColor(.35,.72,1)
                    else row.reforgeBox.text:SetTextColor(.48,.48,.48) end
                    row.reforgeBox:Show()
                end
            else
                row.itemName:SetText("Empty")
                row.itemName:SetTextColor(0.48,0.48,0.48)
                row.itemLevel:SetText("—")
                row.icon:Hide()
                if row.gemButtons then for _,button in ipairs(row.gemButtons) do button.gemData=nil; button.extraSocketLabel=nil; if button.extraBorder then button.extraBorder:Hide() end; if button.emptyPlus then button.emptyPlus:Hide() end; button:Hide() end end
                if row.enchantBox then row.enchantBox.itemData=nil; row.enchantBox.text:SetText("—"); row.enchantBox.text:SetTextColor(.48,.48,.48); row.enchantBox:Show() end
                if row.tinkerBox then row.tinkerBox.itemData=nil; row.tinkerBox.text:SetText("—"); row.tinkerBox.text:SetTextColor(.48,.48,.48); if panel.showTinker then row.tinkerBox:Show() else row.tinkerBox:Hide() end end
                if row.reforgeBox then row.reforgeBox.itemData=nil; row.reforgeBox.text:SetText("—"); row.reforgeBox.text:SetTextColor(.48,.48,.48); row.reforgeBox:Show() end
            end
        end
    end
end

local function ReputationColor(standingID)
    local id = tonumber(standingID) or 4
    if FACTION_BAR_COLORS and FACTION_BAR_COLORS[id] then
        local c = FACTION_BAR_COLORS[id]
        return c.r or 0.8, c.g or 0.8, c.b or 0.8
    end
    local fallback = {
        [1]={0.75,0.15,0.15}, [2]={0.80,0.20,0.20}, [3]={0.85,0.35,0.15},
        [4]={0.85,0.75,0.25}, [5]={0.35,0.75,0.35}, [6]={0.25,0.75,0.55},
        [7]={0.25,0.60,0.85}, [8]={0.35,0.85,0.95},
    }
    local c = fallback[id] or {0.75,0.75,0.75}
    return c[1],c[2],c[3]
end

function AA:RefreshReputationsDetail(char, resetScroll)
    local panel = self.dashboardFrame and self.dashboardFrame.detailFrames and self.dashboardFrame.detailFrames.reputations
    if not panel or not char then return end
    MainSetDetailHeader(panel, char, "Reputations")

    local snapshot = type(char.reputations) == "table" and char.reputations or nil
    local factions = snapshot and type(snapshot.factions) == "table" and snapshot.factions or {}
    panel.reputationData = factions
    if panel.status then
        if snapshot and snapshot.scannedAt then
            panel.status:SetText(string.format("%d reputations stored • %s", #factions, FormatTimestamp(snapshot.scannedAt)))
        else
            panel.status:SetText("No stored reputation snapshot. Log this character once and use Scan current.")
        end
    end

    if resetScroll and panel.scroll then
        FauxScrollFrame_SetOffset(panel.scroll,0)
        local sb=panel.scroll.ScrollBar or _G[panel.scroll:GetName().."ScrollBar"]
        if sb then sb:SetValue(0) end
    end
    local visible = math.max(1, math.min(#panel.rows, math.floor(((panel:GetHeight() or 500)-112)/38)))
    FauxScrollFrame_Update(panel.scroll, #factions, visible, 38)
    local offset = FauxScrollFrame_GetOffset(panel.scroll) or 0
    for i,row in ipairs(panel.rows) do
        local rep = (i <= visible) and factions[offset+i] or nil
        if rep then
            row.repData = rep
            row.name:SetText(rep.name or "Unknown")
            row.standing:SetText(rep.standing or REPUTATION_STANDING_NAMES[rep.standingID] or "Unknown")
            local current = tonumber(rep.progress) or 0
            local needed = tonumber(rep.needed) or 0
            if tonumber(rep.standingID) == 8 then
                row.value:SetText("Exalted")
            elseif needed > 0 then
                row.value:SetText(string.format("%d / %d", current, needed))
            else
                row.value:SetText(tostring(current))
            end
            local r,g,b = ReputationColor(rep.standingID)
            row.standing:SetTextColor(r,g,b)
            row.barFill:SetTexture(r,g,b,0.72)
            row.progressRatio = needed > 0 and math.max(0,math.min(1,current/needed)) or (tonumber(rep.standingID)==8 and 1 or 0)
            local bw = math.max(1,(row.barBG:GetWidth() or 280)-2)
            row.barFill:SetWidth(math.max(1,bw*row.progressRatio))
            row:Show()
        else
            row.repData=nil
            row:Hide()
        end
    end
end

local function CollectCharacterProfessionCooldowns(self, char)
    local entries = {}
    if not char or type(char.recipeBooks) ~= "table" then return entries end
    for _, book in pairs(char.recipeBooks) do
        if type(book) == "table" then
            local bookEntries = self:GetProfessionCooldownEntries(char, book.name)
            for _, entry in ipairs(bookEntries) do table.insert(entries, entry) end
        end
    end
    table.sort(entries, function(a,b)
        local ap = Lower(a.profession or "")
        local bp = Lower(b.profession or "")
        if ap ~= bp then return ap < bp end
        if a.ready ~= b.ready then return a.ready end
        if a.remaining ~= b.remaining then return a.remaining < b.remaining end
        return Lower(a.name or "") < Lower(b.name or "")
    end)
    return entries
end

local function UpdateProfessionsFooterLayout(panel)
    if not panel or not panel.recipeScanButton or not panel.recipeScanStatus or not panel.searchLabel or not panel.searchBox or not panel.searchButton then return end

    local width = tonumber(panel:GetWidth()) or 0
    local statusWidth = math.max(170, tonumber(panel.recipeScanStatus:GetStringWidth()) or 0)
    local searchLabelWidth = math.max(86, tonumber(panel.searchLabel:GetStringWidth()) or 0)

    -- Space needed when everything lives on the bottom row:
    -- [Recipe Scan] [Stored recipe snapshots...] ... [Recipe Search:] [box] [Search]
    local leftNeed = 18 + 112 + 10 + statusWidth
    local rightNeed = 18 + 54 + 8 + 180 + 8 + searchLabelWidth
    local needsSecondLine = width > 0 and (leftNeed + rightNeed + 24 > width)

    panel.recipeScanStatus:ClearAllPoints()
    if needsSecondLine then
        -- Keep the controls on the bottom row and move only the status text up.
        panel.recipeScanStatus:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 18, 49)
        panel.recipeScanStatus:SetWidth(math.max(255, width - 36))
    else
        panel.recipeScanStatus:SetPoint("LEFT", panel.recipeScanButton, "RIGHT", 10, 0)
        panel.recipeScanStatus:SetWidth(255)
    end
    panel.recipeScanStatus:SetJustifyH("LEFT")

    -- The second status line needs its own vertical space. Raise the bottom of
    -- the profession scroll viewport so cooldown rows can never scroll beneath
    -- the footer/status text when the window is narrow.
    if panel.contentScroll then
        panel.contentScroll:ClearAllPoints()
        panel.contentScroll:SetPoint("TOPLEFT",panel,"TOPLEFT",10,-70)
        panel.contentScroll:SetPoint("BOTTOMRIGHT",panel,"BOTTOMRIGHT",-30,needsSecondLine and 82 or 56)
    end
end

function AA:RefreshProfessionsDetail(char)
    local panel = self.dashboardFrame and self.dashboardFrame.detailFrames and self.dashboardFrame.detailFrames.professions
    if not panel or not char then return end

    MainSetDetailHeader(panel, char, "Professions")

    -- Offline characters use their saved snapshot. For the currently logged-in
    -- character prefer a fresh live snapshot whenever GetProfessions() is ready.
    local profs = type(char.professions) == "table" and char.professions or {}
    if char.key == self.currentCharacterKey then
        local live, hasLiveData = BuildProfessionSnapshot()
        if hasLiveData and ProfessionSnapshotHasData(live) then
            profs = live
            char.professions = live
            char.professionsScannedAt = time()
            char.professionsSnapshotValid = true
        end
    end

    local ordered = {
        { missing = "Primary profession 1", prof = profs.primary1 },
        { missing = "Primary profession 2", prof = profs.primary2 },
        { missing = "Archaeology",          prof = profs.archaeology },
        { missing = "Fishing",              prof = profs.fishing },
        { missing = "Cooking",              prof = profs.cooking },
        { missing = "First Aid",            prof = profs.firstAid },
    }

    local shown = 0
    local inCombat = type(InCombatLockdown) == "function" and InCombatLockdown()

    for i, row in ipairs(panel.profRows or {}) do
        local item = ordered[i]
        local prof = item and item.prof
        row.profession = prof
        row.charKey = char.key

        if prof then
            shown = shown + 1
            local displayName = ProfessionDisplayName(prof)
            if (not prof.name or prof.name == "") and displayName ~= "Profession" and displayName ~= "-" then
                prof.name = displayName
            end

            row.title:SetText(displayName)
            row.title:SetTextColor(1, 0.82, 0)
            row.skill:SetText(string.format("%d / %d", tonumber(prof.skill) or 0, tonumber(prof.max) or 0))
            row.skill:SetTextColor(1, 0.82, 0)

            row.openButton.profession = prof
            row.openButton.charKey = char.key
            row.openButton.actionMode = nil
            row.secureOpenButton.profession = prof
            row.secureOpenButton.charKey = char.key
            row.secureOpenButton.actionMode = nil

            if inCombat then
                -- Do not reconfigure protected profession actions while combat
                -- lockdown is active. The normal visual button clearly reports
                -- the temporary state instead.
                row.openButton:SetText("Locked")
                row.openButton.actionMode = "combat"
                row.openButton:EnableMouse(true)
                row.openButton:Disable()
                row.openButton:Show()
            else
                self:ClearSecureProfessionButton(row.secureOpenButton)
                row.secureOpenButton:Hide()
                row.openButton:Hide()
                row.openButton:SetText("Open")
                row.openButton:Enable()
                row.openButton:EnableMouse(true)

                if char.key ~= self.currentCharacterKey then
                    -- Offline browsing is useful only when Alternator has an
                    -- actual recipe list to display. Gathering skills and
                    -- Archaeology therefore deliberately have no Open button.
                    if IsRecipeProfession(prof) then
                        row.openButton.actionMode = "snapshot"
                        row.openButton:Show()
                    else
                        row.openButton:Hide()
                    end
                elseif IsArchaeologyProfession(prof) then
                    -- Archaeology owns a dedicated Blizzard frame and therefore
                    -- uses the ordinary hardware OnClick path.
                    row.openButton.actionMode = "archaeology"
                    row.openButton:Show()
                elseif ProfessionHasNativeWindow(prof) then
                    -- Online crafting professions: keep a normal button visible
                    -- as artwork, but let a panel-level transparent secure button
                    -- above it execute the exact /cast <profession> macro.
                    if self:ConfigureSecureProfessionButton(row.secureOpenButton, prof) then
                        row.secureOpenButton.actionMode = "secure"
                        row.secureOpenButton:Enable()
                        row.openButton.actionMode = "secure"
                        row.openButton:EnableMouse(true)
                        row.openButton:Show()
                        row.secureOpenButton:Show()
                    else
                        row.openButton:SetText("Unavailable")
                        row.openButton:Disable()
                        row.openButton.actionMode = "combat"
                        row.openButton:Show()
                    end
                else
                    -- Online Fishing, Herbalism and Skinning have no browseable
                    -- Blizzard profession/recipe window, so there is deliberately
                    -- no Open button for them. Their skill value remains visible.
                    row.openButton:Hide()
                    row.secureOpenButton:Hide()
                end
            end
        else
            if not inCombat then
                self:ClearSecureProfessionButton(row.secureOpenButton)
                row.secureOpenButton:Hide()
            end
            row.openButton:Hide()
            row.openButton.profession = nil
            row.openButton.charKey = char.key
            row.openButton.actionMode = nil
            row.secureOpenButton.profession = nil
            row.secureOpenButton.charKey = char.key
            row.secureOpenButton.actionMode = nil

            row.title:SetText(item and item.missing or "Profession")
            row.title:SetTextColor(0.55, 0.55, 0.55)
            row.skill:SetText("-")
            row.skill:SetTextColor(0.55, 0.55, 0.55)
        end
    end

    if panel.emptyText then
        if shown == 0 then
            panel.emptyText:SetText(char.key == self.currentCharacterKey
                and "No profession data is available yet. Wait until the character is fully loaded, then use Scan current."
                or "No stored profession snapshot is available for this character yet. Log this character once and scan it with Alternator.")
            panel.emptyText:Show()
        else
            panel.emptyText:Hide()
        end
    end

    -- Stored profession cooldowns are derived from recipe scans. Remaining time
    -- continues to count down while the character is offline because we keep an
    -- absolute readyAt timestamp with the recipe snapshot. The whole profession
    -- body is one scrollable canvas, so cooldowns simply extend that canvas.
    local cooldowns = CollectCharacterProfessionCooldowns(self, char)
    if panel.cooldownTitle then
        panel.cooldownTitle:Show()
        if #cooldowns == 0 then
            panel.cooldownEmpty:SetText(char.key == self.currentCharacterKey
                and "No profession cooldowns recorded. Use Recipe Scan/Refresh while a crafting profession is open."
                or "No stored profession cooldown information for this character.")
            panel.cooldownEmpty:Show()
        else
            panel.cooldownEmpty:Hide()
        end
        for i,row in ipairs(panel.cooldownRows or {}) do
            local entry = cooldowns[i]
            if entry then
                row.icon:SetTexture(entry.icon or "Interface\\Icons\\INV_Misc_QuestionMark")
                row.icon:Show()
                row.profession:SetText(entry.profession or "Profession")
                row.recipe:SetText(entry.name or "Cooldown")
                if entry.ready then
                    row.status:SetText("Ready")
                    row.status:SetTextColor(0.25,1.0,0.25)
                else
                    row.status:SetText(FormatCooldownRemaining(entry.remaining))
                    row.status:SetTextColor(1.0,0.65,0.08)
                end
                row.cooldownData=entry
                row:Show()
            else
                row.cooldownData=nil
                row:Hide()
            end
        end

        if panel.contentChild then
            local visibleCooldowns = math.min(#cooldowns, #(panel.cooldownRows or {}))
            local cooldownHeight = (#cooldowns == 0) and 42 or (visibleCooldowns * 25 + 18)
            panel.contentChild:SetHeight(math.max(425, 376 + cooldownHeight))
        end
        if panel.contentScroll and panel.lastProfessionCharKey ~= char.key then
            panel.contentScroll:SetVerticalScroll(0)
        end
        panel.lastProfessionCharKey = char.key
    end

    if panel.recipeScanButton and panel.recipeScanStatus then
        if char.key == self.currentCharacterKey then
            local recipeProfessions = self:GetCurrentRecipeProfessions()
            local scanned = 0
            for _, recipeProf in ipairs(recipeProfessions) do
                local book = self:GetRecipeBook(char, recipeProf.name)
                if book and book.lastScan then scanned = scanned + 1 end
            end
            panel.recipeScanButton:Show()
            panel.recipeScanStatus:SetText(string.format("Stored recipe snapshots: %d / %d", scanned, #recipeProfessions))
            panel.recipeScanStatus:Show()
        else
            panel.recipeScanButton:Hide()
            panel.recipeScanStatus:Hide()
        end
        UpdateProfessionsFooterLayout(panel)
    end
end

local function LegendaryStateStyle(state, scanned)
    if not scanned or not state then
        return "not scanned", {0.42,0.42,0.42,1}, {0.18,0.18,0.18,0.92}
    end
    if state.state == "done" then
        return "Completed", {0.22,0.78,0.28,1}, QUEST_STATE_COLORS.done
    elseif state.state == "active" then
        local label = state.text and state.text ~= "" and state.text or "In progress"
        return label, {1.00,0.62,0.08,1}, QUEST_STATE_COLORS.active
    elseif state.state == "skipped" then
        return "Skipped", {0.52,0.66,0.78,1}, QUEST_STATE_COLORS.skipped
    end
    return "Not completed", {0.90,0.22,0.22,1}, QUEST_STATE_COLORS.none
end

local function LayoutLegendaryDetail(panel)
    if not panel or not panel.scrollChild then return end
    local y = -2
    local lastChapter = nil
    for i, milestone in ipairs(LEGENDARY_MILESTONES) do
        if milestone.chapter ~= lastChapter then
            lastChapter = milestone.chapter
            local chapter = panel.chapterHeaders[milestone.chapter]
            if chapter then
                chapter:ClearAllPoints()
                chapter:SetPoint("TOPLEFT", panel.scrollChild, "TOPLEFT", 0, y)
                chapter:SetPoint("RIGHT", panel.scrollChild, "RIGHT", -4, 0)
                chapter:Show()
            end
            y = y - 28
        end

        local row = panel.milestoneRows[i]
        if row then
            row:ClearAllPoints()
            row:SetPoint("TOPLEFT", panel.scrollChild, "TOPLEFT", 0, y)
            row:SetPoint("RIGHT", panel.scrollChild, "RIGHT", -4, 0)
            y = y - 38

            if row.detail and row.detail:IsShown() then
                local detailHeight = row.detail.desiredHeight or 72
                row.detail:ClearAllPoints()
                row.detail:SetPoint("TOPLEFT", panel.scrollChild, "TOPLEFT", 8, y + 2)
                row.detail:SetPoint("RIGHT", panel.scrollChild, "RIGHT", -12, 0)
                row.detail:SetHeight(detailHeight)
                y = y - detailHeight - 8
            end
        end
    end
    panel.scrollChild:SetHeight(math.max(1, -y + 8))
end

function AA:SetLegendaryExpanded(panel, key, manual)
    if not panel then return end
    if panel.expandedKey == key then
        panel.expandedKey = nil
    else
        panel.expandedKey = key
    end
    if manual then panel.legendaryManualChoice = true end
    for i, milestone in ipairs(LEGENDARY_MILESTONES) do
        local row = panel.milestoneRows and panel.milestoneRows[i]
        if row and row.detail then
            local expanded = panel.expandedKey == milestone.key
            if expanded then row.detail:Show() else row.detail:Hide() end
            if row.arrow then row.arrow:SetText(expanded and "-" or "+") end
        end
    end
    LayoutLegendaryDetail(panel)
end

function AA:RefreshLegendaryDetail(char)
    local panel = self.dashboardFrame and self.dashboardFrame.detailFrames and self.dashboardFrame.detailFrames.legendary
    if not panel or not char then return end
    MainSetDetailHeader(panel, char, "Legendary Cloak")
    local legendary = char.legendary or {}

    if panel.scrollChild then
        local availableWidth = math.max(420, (panel:GetWidth() or 600) - 54)
        panel.scrollChild:SetWidth(availableWidth)
    end

    local activeKey = nil
    for i, milestone in ipairs(LEGENDARY_MILESTONES) do
        local row = panel.milestoneRows[i]
        local state = legendary[milestone.key]
        local title = (state and state.title) or ResolveMilestoneTitle(milestone, char.faction)
        row.name:SetText(title)
        row.milestoneKey = milestone.key
        row.charKey = char.key

        local statusText, borderColor, bgColor = LegendaryStateStyle(state, char.profileScanned)
        row.status:SetText((state and state.state == "none") and "" or statusText)
        row.bg:SetTexture(bgColor[1], bgColor[2], bgColor[3], (state and state.state == "active") and 0.88 or 0.82)

        if state and state.state == "active" and not activeKey then activeKey = milestone.key end

        if row.detail then
            row.detail:SetBackdropBorderColor(borderColor[1], borderColor[2], borderColor[3], 1)
            row.detail.status:SetText("Status: " .. statusText)
            row.detail.status:SetTextColor(borderColor[1], borderColor[2], borderColor[3])
            row.detail.description:SetText(LEGENDARY_QUEST_DESCRIPTIONS[milestone.key] or "Legendary quest step in Wrathion's Mists of Pandaria quest line.")
            local progress = state and state.text or ""
            if state and state.state == "active" and progress ~= "" and Lower(progress) ~= "active" then
                row.detail.progress:SetText("Progress: " .. progress)
                row.detail.progress:Show()
            else
                row.detail.progress:SetText("")
                row.detail.progress:Hide()
            end
            if row.detail.questID then
                local qid = state and state.questID
                row.detail.questID:SetText(qid and ("Quest ID: " .. tostring(qid)) or "")
            end

            local width = math.max(300, (panel.scrollChild:GetWidth() or 600) - 40)
            row.detail.description:SetWidth(width - 24)
            row.detail.progress:SetWidth(width - 24)
            local descriptionHeight = math.max(28, row.detail.description:GetStringHeight() or 28)
            local progressHeight = row.detail.progress:IsShown() and math.max(14, row.detail.progress:GetStringHeight() or 14) or 0
            row.detail.desiredHeight = math.max(70, 28 + descriptionHeight + progressHeight + 18)
        end
    end

    if panel.legendaryCharacterKey ~= char.key then
        panel.legendaryCharacterKey = char.key
        panel.legendaryManualChoice = nil
        panel.expandedKey = activeKey
    elseif not panel.legendaryManualChoice and activeKey then
        panel.expandedKey = activeKey
    end

    for i, milestone in ipairs(LEGENDARY_MILESTONES) do
        local row = panel.milestoneRows[i]
        if row and row.detail then
            local expanded = panel.expandedKey == milestone.key
            if expanded then row.detail:Show() else row.detail:Hide() end
            if row.arrow then row.arrow:SetText(expanded and "-" or "+") end
        end
    end
    LayoutLegendaryDetail(panel)
end

function AA:RefreshCollectionsDetail(char)
    local panel = self.dashboardFrame and self.dashboardFrame.detailFrames and self.dashboardFrame.detailFrames.collections
    if not panel or not char then return end
    MainSetDetailHeader(panel, char, "Mounts & Companions")
    local collections = char.collections or {}
    panel.mountValue:SetText(char.collectionsScannedAt and tostring(collections.mounts or 0) or "?")
    panel.petValue:SetText(char.collectionsScannedAt and tostring(collections.companions or 0) or "?")
    panel.mountCard.data = { kind="collection", label="Mounts", value=collections.mounts or 0, char=char, collectionType="mounts" }
    panel.petCard.data = { kind="collection", label="Companions / battle pets", value=collections.companions or 0, char=char, collectionType="companions" }
end

local function SummaryCharacterDisplayName(char)
    if not char then return "Unknown" end
    return (char.name or "Unknown") .. "-" .. (char.realm or "?")
end

local function SummarySortCharacters(chars)
    local result = {}
    for _, char in ipairs(chars or {}) do table.insert(result, char) end
    table.sort(result, function(a, b)
        local an = Lower((a and a.name) or "")
        local bn = Lower((b and b.name) or "")
        if an ~= bn then return an < bn end
        return Lower((a and a.realm) or "") < Lower((b and b.realm) or "")
    end)
    return result
end

local function SummaryFormatGoldOnly(copper)
    local gold = math.floor((tonumber(copper) or 0) / 10000)
    local sign = gold < 0 and "-" or ""
    local digits = tostring(math.abs(gold))
    local parts = {}
    while string.len(digits) > 3 do
        table.insert(parts, 1, string.sub(digits, -3))
        digits = string.sub(digits, 1, string.len(digits) - 3)
    end
    table.insert(parts, 1, digits)
    return sign .. table.concat(parts, ",") .. "g"
end

local SUMMARY_PROFESSION_SPELL_IDS = {
    ["alchemy"] = 2259,
    ["blacksmithing"] = 2018,
    ["enchanting"] = 7411,
    ["engineering"] = 4036,
    ["herbalism"] = 2366,
    ["inscription"] = 45357,
    ["jewelcrafting"] = 25229,
    ["leatherworking"] = 2108,
    ["mining"] = 2575,
    ["skinning"] = 8613,
    ["tailoring"] = 3908,
    ["archaeology"] = 78670,
    ["fishing"] = 7620,
    ["cooking"] = 2550,
    ["first aid"] = 3273,
}

local function SummaryProfessionIcon(name, storedIcon)
    if storedIcon then return storedIcon end
    local spellID = SUMMARY_PROFESSION_SPELL_IDS[Lower(Trim(name or ""))]
    if spellID and type(GetSpellInfo) == "function" then
        local _, _, icon = GetSpellInfo(spellID)
        if icon then return icon end
    end
    return "Interface\\Icons\\INV_Misc_QuestionMark"
end

local function SummaryFormatGoldNumber(copper)
    local textValue = SummaryFormatGoldOnly(copper)
    return string.gsub(textValue, "g$", "")
end

local SUMMARY_GOLD_ICON = "Interface\\MoneyFrame\\UI-GoldIcon"

local function SummaryAddCharacterEntry(bucket, char, detail)
    bucket.entries = bucket.entries or {}
    table.insert(bucket.entries, { char = char, detail = detail })
    bucket.count = (bucket.count or 0) + 1
end

function AA:BuildAccountSummaryData(chars)
    chars = chars or self:GetDashboardCharactersSorted()
    local result = {
        total = #chars,
        all = { title = "All characters", count = #chars, entries = {} },
        factions = {},
        races = {},
        professions = {},
        realms = {},
        currencyAlerts = {},
        played = { title = "Played time", totalSeconds = 0, count = #chars, scannedCount = 0, entries = {} },
    }

    for _, char in ipairs(chars) do
        table.insert(result.all.entries, { char = char })

        local playedSeconds = tonumber(char.playedTotal)
        if playedSeconds and playedSeconds >= 0 then
            result.played.totalSeconds = result.played.totalSeconds + playedSeconds
            result.played.scannedCount = result.played.scannedCount + 1
        end
        table.insert(result.played.entries, { char = char, seconds = playedSeconds, scannedAt = char.playedScannedAt })

        local faction = Trim(char.faction or "")
        if faction == "" then faction = "Unknown" end
        local factionKey = Lower(faction)
        local factionBucket = result.factions[factionKey]
        if not factionBucket then
            factionBucket = { title = faction, label = faction, count = 0, entries = {} }
            result.factions[factionKey] = factionBucket
        end
        SummaryAddCharacterEntry(factionBucket, char)

        local race = Trim(char.race or char.raceName or char.raceFile or "")
        if race == "" then race = "Unknown" end
        local raceKey = Lower(race)
        local raceBucket = result.races[raceKey]
        if not raceBucket then
            raceBucket = { title = race, label = race, count = 0, entries = {} }
            result.races[raceKey] = raceBucket
        end
        SummaryAddCharacterEntry(raceBucket, char)

        local seenProfessions = {}
        local profs = type(char.professions) == "table" and char.professions or {}
        local professionSlots = { profs.primary1, profs.primary2, profs.archaeology, profs.fishing, profs.cooking, profs.firstAid }
        for _, prof in ipairs(professionSlots) do
            if prof then
                local name = ProfessionDisplayName(prof)
                if name and name ~= "" and name ~= "-" and name ~= "Profession" then
                    local key = Lower(name)
                    if not seenProfessions[key] then
                        seenProfessions[key] = true
                        local bucket = result.professions[key]
                        if not bucket then
                            bucket = { title = name, label = name, count = 0, entries = {}, icon = SummaryProfessionIcon(name, prof.icon) }
                            result.professions[key] = bucket
                        elseif not bucket.icon then
                            bucket.icon = SummaryProfessionIcon(name, prof.icon)
                        end
                        local skillText = string.format("%d / %d", tonumber(prof.skill) or 0, tonumber(prof.max) or 0)
                        local cooldownEntries = self:GetProfessionCooldownEntries(char, name)
                        if #cooldownEntries > 0 then
                            bucket.cooldownReady = tonumber(bucket.cooldownReady) or 0
                            bucket.cooldownActive = tonumber(bucket.cooldownActive) or 0
                            local parts = {}
                            local anyActive = false
                            for _, cd in ipairs(cooldownEntries) do
                                if cd.ready then
                                    table.insert(parts, (cd.name or "Cooldown") .. ": Ready")
                                else
                                    anyActive = true
                                    table.insert(parts, (cd.name or "Cooldown") .. ": " .. FormatCooldownRemaining(cd.remaining))
                                end
                            end
                            if anyActive then bucket.cooldownActive = bucket.cooldownActive + 1 else bucket.cooldownReady = bucket.cooldownReady + 1 end
                            skillText = skillText .. "  •  " .. table.concat(parts, ", ")
                        end
                        SummaryAddCharacterEntry(bucket, char, skillText)
                    end
                end
            end
        end

        -- Currency alerts are derived from the stored currency snapshot.  Only
        -- currencies that are actually at/near a known total or weekly cap are
        -- added to the account overview.
        for _, def in ipairs(TRACKED_CURRENCIES) do
            local info = char.currencies and char.currencies[tostring(def.id)]
            local alert = CurrencyAlertState(info, def)
            if alert then
                local key = tostring(def.id)
                local bucket = result.currencyAlerts[key]
                if not bucket then
                    bucket = {
                        title = (info and info.name) or def.name,
                        label = (info and info.name) or def.name,
                        id = def.id,
                        icon = MainCurrencyTexture(def, info),
                        count = 0,
                        capCount = 0,
                        nearCount = 0,
                        entries = {},
                    }
                    result.currencyAlerts[key] = bucket
                end
                bucket.count = bucket.count + 1
                if alert.level == "cap" then bucket.capCount = bucket.capCount + 1 else bucket.nearCount = bucket.nearCount + 1 end
                table.insert(bucket.entries, { char = char, info = info, alert = alert })
            end
        end

        local realm = Trim(char.realm or "")
        if realm == "" then realm = "Unknown realm" end
        local realmKey = Lower(realm)
        local realmBucket = result.realms[realmKey]
        if not realmBucket then
            realmBucket = { title = realm, label = realm, money = 0, entries = {} }
            result.realms[realmKey] = realmBucket
        end
        local money = self:GetStoredCharacterMoney(char)
        realmBucket.money = realmBucket.money + money
        table.insert(realmBucket.entries, { char = char, money = money })
    end

    for _, bucket in pairs(result.factions) do
        table.sort(bucket.entries, function(a,b) return Lower(SummaryCharacterDisplayName(a.char)) < Lower(SummaryCharacterDisplayName(b.char)) end)
    end
    for _, bucket in pairs(result.races) do
        table.sort(bucket.entries, function(a,b) return Lower(SummaryCharacterDisplayName(a.char)) < Lower(SummaryCharacterDisplayName(b.char)) end)
    end
    for _, bucket in pairs(result.professions) do
        table.sort(bucket.entries, function(a,b) return Lower(SummaryCharacterDisplayName(a.char)) < Lower(SummaryCharacterDisplayName(b.char)) end)
    end
    table.sort(result.all.entries, function(a,b) return Lower(SummaryCharacterDisplayName(a.char)) < Lower(SummaryCharacterDisplayName(b.char)) end)
    table.sort(result.played.entries, function(a,b)
        local av = tonumber(a.seconds)
        local bv = tonumber(b.seconds)
        if av ~= nil and bv == nil then return true end
        if av == nil and bv ~= nil then return false end
        if av ~= nil and bv ~= nil and av ~= bv then return av > bv end
        return Lower(SummaryCharacterDisplayName(a.char)) < Lower(SummaryCharacterDisplayName(b.char))
    end)
    for _, bucket in pairs(result.realms) do
        table.sort(bucket.entries, function(a,b)
            if (a.money or 0) ~= (b.money or 0) then return (a.money or 0) > (b.money or 0) end
            return Lower(SummaryCharacterDisplayName(a.char)) < Lower(SummaryCharacterDisplayName(b.char))
        end)
    end
    for _, bucket in pairs(result.currencyAlerts) do
        table.sort(bucket.entries, function(a,b)
            local al = a.alert and a.alert.level == "cap" and 2 or 1
            local bl = b.alert and b.alert.level == "cap" and 2 or 1
            if al ~= bl then return al > bl end
            local ar = 0
            local br = 0
            if a.alert then
                if (a.alert.totalMax or 0) > 0 then ar = math.max(ar, (a.alert.amount or 0) / a.alert.totalMax) end
                if (a.alert.weeklyMax or 0) > 0 then ar = math.max(ar, (a.alert.earnedThisWeek or 0) / a.alert.weeklyMax) end
            end
            if b.alert then
                if (b.alert.totalMax or 0) > 0 then br = math.max(br, (b.alert.amount or 0) / b.alert.totalMax) end
                if (b.alert.weeklyMax or 0) > 0 then br = math.max(br, (b.alert.earnedThisWeek or 0) / b.alert.weeklyMax) end
            end
            if ar ~= br then return ar > br end
            return Lower(SummaryCharacterDisplayName(a.char)) < Lower(SummaryCharacterDisplayName(b.char))
        end)
    end

    return result
end

function AA:ShowAccountSummaryTooltip(button)
    local data = button and button.summaryData
    if not data then return end
    GameTooltip:SetOwner(button, "ANCHOR_RIGHT")
    GameTooltip:ClearLines()
    GameTooltip:AddLine(data.title or "Summary", 1, 0.82, 0)

    if data.kind == "played" then
        GameTooltip:AddDoubleLine("Total played", FormatPlayedTime(data.totalSeconds or 0), 0.75,0.75,0.75, 1,0.82,0)
        GameTooltip:AddDoubleLine("Stored played data", string.format("%d / %d characters", tonumber(data.scannedCount) or 0, tonumber(data.count) or 0), 0.75,0.75,0.75, 0.90,0.90,0.90)
        GameTooltip:AddLine(" ")
        for _, entry in ipairs(data.entries or {}) do
            local char = entry.char
            local r,g,b = MainClassColor(char)
            local playedText = entry.seconds ~= nil and FormatPlayedTime(entry.seconds) or "Not scanned"
            local vr,vg,vb = 1,0.82,0
            if entry.seconds == nil then vr,vg,vb = 0.55,0.55,0.55 end
            GameTooltip:AddDoubleLine(SummaryCharacterDisplayName(char), playedText, r,g,b, vr,vg,vb)
        end
        if (tonumber(data.scannedCount) or 0) < (tonumber(data.count) or 0) then
            GameTooltip:AddLine(" ")
            GameTooltip:AddLine("Use Scan current on a character to store its played time.", 0.60,0.60,0.60, true)
        end
    elseif data.kind == "gold" then
        GameTooltip:AddDoubleLine("Realm total", MainFormatMoney(data.money or 0), 0.75,0.75,0.75, 1,0.82,0)
        GameTooltip:AddLine(" ")
        for _, entry in ipairs(data.entries or {}) do
            local char = entry.char
            local r,g,b = MainClassColor(char)
            GameTooltip:AddDoubleLine(SummaryCharacterDisplayName(char), MainFormatMoney(entry.money or 0), r,g,b, 1,0.82,0)
        end
    elseif data.kind == "currencyAlert" then
        local capCount = tonumber(data.capCount) or 0
        local nearCount = tonumber(data.nearCount) or 0
        GameTooltip:AddDoubleLine("At cap", tostring(capCount), 0.75,0.75,0.75, 1.0,0.20,0.20)
        GameTooltip:AddDoubleLine("Near cap", tostring(nearCount), 0.75,0.75,0.75, 1.0,0.60,0.10)
        GameTooltip:AddLine(" ")
        for _, entry in ipairs(data.entries or {}) do
            local char = entry.char
            local r,g,b = MainClassColor(char)
            local ar,ag,ab = CurrencyAlertColor(entry.alert and entry.alert.level)
            GameTooltip:AddDoubleLine(SummaryCharacterDisplayName(char), (entry.alert and entry.alert.detail) or "Alert", r,g,b, ar,ag,ab)
        end
    else
        GameTooltip:AddLine(string.format("%d character(s)", tonumber(data.count) or #(data.entries or {})), 0.72,0.72,0.72)
        GameTooltip:AddLine(" ")
        for _, entry in ipairs(data.entries or {}) do
            local char = entry.char
            local r,g,b = MainClassColor(char)
            if entry.detail and entry.detail ~= "" then
                GameTooltip:AddDoubleLine(SummaryCharacterDisplayName(char), entry.detail, r,g,b, 1,0.82,0)
            else
                GameTooltip:AddLine(SummaryCharacterDisplayName(char), r,g,b)
            end
        end
    end
    GameTooltip:Show()
end

local function CreateAccountSummaryStatButton(parent)
    local button = CreateFrame("Button", nil, parent)
    button:SetHeight(20)
    button:EnableMouse(true)

    button.icon = button:CreateTexture(nil, "ARTWORK")
    button.icon:SetSize(18, 18)
    button.icon:SetPoint("LEFT", button, "LEFT", 0, 0)
    button.icon:Hide()

    button.text = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    button.text:SetPoint("LEFT", button, "LEFT", 0, 0)
    button.text:SetJustifyH("LEFT")

    button:SetScript("OnEnter", function(self)
        if self.text then self.text:SetTextColor(1, 0.92, 0.48) end
        AA:ShowAccountSummaryTooltip(self)
    end)
    button:SetScript("OnLeave", function(self)
        if self.text and self.normalColor then self.text:SetTextColor(unpack(self.normalColor)) end
        GameTooltip:Hide()
    end)
    return button
end

local function EnsureAccountSummaryStatButton(row, index)
    row.buttons = row.buttons or {}
    if not row.buttons[index] then
        row.buttons[index] = CreateAccountSummaryStatButton(row)
    end
    return row.buttons[index]
end

local function LayoutAccountSummaryRow(row, items)
    if not row then return 20 end
    items = items or {}
    local startX = 112
    local maxWidth = math.max(220, (row:GetWidth() or 800) - 8)
    local x, y = startX, 0
    local lineHeight = 20
    local lines = 1

    for i, item in ipairs(items) do
        local button = EnsureAccountSummaryStatButton(row, i)
        button.summaryData = item.data
        button.text:SetText(item.text or "")
        local color = item.color or {0.90, 0.90, 0.90}
        button.normalColor = { color[1], color[2], color[3] }
        button.text:SetTextColor(color[1], color[2], color[3])

        local iconWidth = 0
        button.text:ClearAllPoints()
        if item.icon then
            button.icon:SetTexture(item.icon)
            if item.iconTexCoord then button.icon:SetTexCoord(unpack(item.iconTexCoord)) else button.icon:SetTexCoord(0,1,0,1) end
            local iconSize = tonumber(item.iconSize) or 18
            button.icon:SetSize(iconSize, iconSize)
            button.icon:ClearAllPoints()
            button.icon:SetPoint("LEFT", button, "LEFT", 0, 0)
            button.icon:Show()
            iconWidth = iconSize + 4
            button.text:SetPoint("LEFT", button.icon, "RIGHT", 4, 0)
        else
            button.icon:Hide()
            button.text:SetPoint("LEFT", button, "LEFT", 0, 0)
        end

        local width = math.max(38, math.ceil((button.text:GetStringWidth() or 28) + iconWidth + 12))
        if x + width > maxWidth and x > startX then
            x = startX
            y = y - lineHeight
            lines = lines + 1
        end
        button:ClearAllPoints()
        button:SetPoint("TOPLEFT", row, "TOPLEFT", x, y)
        button:SetWidth(width)
        button:Show()
        x = x + width + 8
    end

    if row.buttons then
        for i = #items + 1, #row.buttons do
            row.buttons[i]:Hide()
            row.buttons[i].summaryData = nil
            if row.buttons[i].icon then row.buttons[i].icon:Hide() end
        end
    end

    local height = math.max(20, lines * lineHeight)
    row:SetHeight(height)
    return height
end

local function SummaryBucketsToSortedList(map)
    local result = {}
    for _, bucket in pairs(map or {}) do table.insert(result, bucket) end
    table.sort(result, function(a,b) return Lower(a.label or a.title or "") < Lower(b.label or b.title or "") end)
    return result
end

function AA:RefreshAccountSummaryOverview(chars)
    local panel = self.dashboardFrame and self.dashboardFrame.detailFrames and self.dashboardFrame.detailFrames.summary
    if not panel or not panel.accountPanel then return end
    local data = self:BuildAccountSummaryData(chars)
    panel.accountData = data
    if panel.scope then panel.scope:SetText("Scope: " .. self:GetRealmFilterLabel()) end

    local characterItems = {
        { text = "Total: " .. tostring(data.total), color = {1,1,1}, data = { kind="characters", title="All characters", count=data.total, entries=data.all.entries } },
    }
    local alliance = data.factions["alliance"] or { count=0, entries={} }
    local horde = data.factions["horde"] or { count=0, entries={} }
    table.insert(characterItems, { text="Alliance: "..tostring(alliance.count), color={0.42,0.68,1.0}, data={kind="characters",title="Alliance",count=alliance.count,entries=alliance.entries} })
    table.insert(characterItems, { text="Horde: "..tostring(horde.count), color={1.0,0.42,0.32}, data={kind="characters",title="Horde",count=horde.count,entries=horde.entries} })
    local unknownFaction = data.factions["unknown"]
    if unknownFaction then table.insert(characterItems, { text="Unknown: "..tostring(unknownFaction.count), color={0.62,0.62,0.62}, data={kind="characters",title="Faction not scanned",count=unknownFaction.count,entries=unknownFaction.entries} }) end

    local playedItems = {}
    if (tonumber(data.played.scannedCount) or 0) > 0 then
        table.insert(playedItems, {
            text = FormatPlayedTime(data.played.totalSeconds or 0),
            color = {1.0,0.82,0},
            data = {
                kind = "played",
                title = "Played time",
                totalSeconds = data.played.totalSeconds,
                scannedCount = data.played.scannedCount,
                count = data.played.count,
                entries = data.played.entries,
            }
        })
    else
        table.insert(playedItems, {
            text = "Not scanned",
            color = {0.55,0.55,0.55},
            data = { kind="played", title="Played time", totalSeconds=0, scannedCount=0, count=data.played.count, entries=data.played.entries }
        })
    end

    local raceItems = {}
    for _, bucket in ipairs(SummaryBucketsToSortedList(data.races)) do
        table.insert(raceItems, { text=(bucket.label or "Unknown")..": "..tostring(bucket.count), color={0.88,0.88,0.88}, data={kind="characters",title=bucket.title or bucket.label,count=bucket.count,entries=bucket.entries} })
    end

    local professionItems = {}
    for _, bucket in ipairs(SummaryBucketsToSortedList(data.professions)) do
        local textValue=tostring(bucket.count)
        if (tonumber(bucket.cooldownReady) or 0) > 0 then
            textValue=textValue.." |cff55ff55Ready:"..tostring(bucket.cooldownReady).."|r"
        end
        if (tonumber(bucket.cooldownActive) or 0) > 0 then
            textValue=textValue.." |cffffa000CD:"..tostring(bucket.cooldownActive).."|r"
        end
        table.insert(professionItems, {
            text=textValue,
            icon=SummaryProfessionIcon(bucket.label, bucket.icon),
            iconSize=18,
            color={0.88,0.88,0.88},
            data={kind="characters",title=bucket.title or bucket.label,count=bucket.count,entries=bucket.entries}
        })
    end
    if #professionItems == 0 then
        table.insert(professionItems, { text="No scanned professions", color={0.55,0.55,0.55}, data={kind="characters",title="Professions",count=0,entries={}} })
    end

    local goldItems = {}
    for _, bucket in ipairs(SummaryBucketsToSortedList(data.realms)) do
        table.insert(goldItems, {
            text=(bucket.label or "Realm")..": "..SummaryFormatGoldNumber(bucket.money),
            icon=SUMMARY_GOLD_ICON,
            iconSize=16,
            color={1.0,0.82,0},
            data={kind="gold",title=(bucket.title or bucket.label).." gold",money=bucket.money,entries=bucket.entries}
        })
    end

    local currencyAlertItems = {}
    for _, bucket in ipairs(SummaryBucketsToSortedList(data.currencyAlerts)) do
        local level = (tonumber(bucket.capCount) or 0) > 0 and "cap" or "near"
        local r,g,b = CurrencyAlertColor(level)
        table.insert(currencyAlertItems, {
            text=tostring(bucket.count),
            icon=bucket.icon,
            iconSize=18,
            color={r,g,b},
            data={
                kind="currencyAlert",
                title=bucket.title or bucket.label or "Currency alert",
                count=bucket.count,
                capCount=bucket.capCount,
                nearCount=bucket.nearCount,
                entries=bucket.entries,
            }
        })
    end
    if #currencyAlertItems == 0 then
        table.insert(currencyAlertItems, { text="No alerts", color={0.52,0.72,0.52}, data={kind="characters",title="Currency alerts",count=0,entries={}} })
    end

    local rows = {
        { frame=panel.accountRows.characters, label="Characters", items=characterItems },
        { frame=panel.accountRows.played, label="Played", items=playedItems },
        { frame=panel.accountRows.races, label="Races", items=raceItems },
        { frame=panel.accountRows.professions, label="Professions", items=professionItems },
        { frame=panel.accountRows.gold, label="Gold by realm", items=goldItems },
        { frame=panel.accountRows.currencyAlerts, label="Currency alerts", items=currencyAlertItems },
    }

    local previous = nil
    local contentHeight = 31
    for _, rowData in ipairs(rows) do
        local row = rowData.frame
        row:ClearAllPoints()
        if previous then row:SetPoint("TOPLEFT", previous, "BOTTOMLEFT", 0, -3); row:SetPoint("RIGHT", panel.accountPanel, "RIGHT", -10, 0)
        else row:SetPoint("TOPLEFT", panel.accountPanel, "TOPLEFT", 10, -31); row:SetPoint("RIGHT", panel.accountPanel, "RIGHT", -10, 0) end
        row.label:SetText(rowData.label .. ":")
        local height = LayoutAccountSummaryRow(row, rowData.items)
        contentHeight = contentHeight + height + 3
        previous = row
    end
    panel.accountPanel:SetHeight(math.max(120, contentHeight + 8))
end

function AA:RefreshMainSummary(resetScroll)
    local frame = self.dashboardFrame
    local panel = frame and frame.detailFrames and frame.detailFrames.summary
    if not panel then return end
    if panel.viewDropDown then UIDropDownMenu_SetText(panel.viewDropDown, self:GetDashboardViewLabel()) end
    local view = self:GetDashboardView()
    local width = DashboardTotalWidth(view)
    panel.header:SetSize(width, DASHBOARD_ROW_HEIGHT)
    PositionDashboardCells(panel.header, view)
    for _, row in ipairs(panel.rows) do row:SetSize(width, DASHBOARD_ROW_HEIGHT); PositionDashboardCells(row, view) end
    local showRecipes = view == "professions"
    if showRecipes then panel.recipeGuide:Show(); panel.searchLabel:Show(); panel.searchBox:Show(); panel.searchButton:Show()
    else panel.recipeGuide:Hide(); panel.searchLabel:Hide(); panel.searchBox:Hide(); panel.searchButton:Hide() end
    local chars = self:GetDashboardCharactersSorted()
    self:RefreshAccountSummaryOverview(chars)
    if resetScroll then FauxScrollFrame_SetOffset(panel.scroll, 0); local sb=panel.scroll.ScrollBar or _G[panel.scroll:GetName().."ScrollBar"]; if sb then sb:SetValue(0) end end
    local summaryHeight = panel.accountPanel and panel.accountPanel:GetHeight() or 150
    local visible = math.max(1, math.min(DASHBOARD_MAX_ROWS, math.floor((panel:GetHeight() - summaryHeight - 82) / DASHBOARD_ROW_HEIGHT)))
    FauxScrollFrame_Update(panel.scroll, #chars, visible, DASHBOARD_ROW_HEIGHT)
    local offset = FauxScrollFrame_GetOffset(panel.scroll) or 0
    for i=1,DASHBOARD_MAX_ROWS do
        local row=panel.rows[i]
        if i<=visible and chars[offset+i] then self:PopulateDashboardRow(row, chars[offset+i]) else row:Hide() end
    end
    if panel.status then panel.status:SetText(string.format("%d character(s) in active realm scope", #chars)) end
end

function AA:RefreshDashboard(resetScroll)
    local frame = self.dashboardFrame
    if not frame then return end
    local chars = self:GetDashboardCharactersSorted()
    local section = self:GetMainDashboardSection()
    local tab = self:GetMainDashboardTab()

    for _, detail in pairs(frame.detailFrames or {}) do detail:Hide() end
    self:UpdateMainSectionStyles(section)

    if section == "summary" then
        frame.characterPane:Hide()
        for _, button in pairs(frame.tabButtons or {}) do button:Hide() end

        frame.detailHost:ClearAllPoints()
        frame.detailHost:SetPoint("TOPLEFT", frame, "TOPLEFT", 18, -118)
        frame.detailHost:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -18, 24)
        frame.detailFrames.summary:Show()
        self:RefreshMainSummary(resetScroll)
    else
        frame.characterPane:Show()
        for _, button in pairs(frame.tabButtons or {}) do button:Show() end
        self:UpdateMainTabStyles(tab)

        frame.detailHost:ClearAllPoints()
        frame.detailHost:SetPoint("TOPLEFT", frame.characterPane, "TOPRIGHT", 12, 0)
        frame.detailHost:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -18, 24)
        self:RefreshMainCharacterList(chars)
        local char = self:GetSelectedDashboardCharacter(chars)
        local detail = frame.detailFrames[tab]
        if detail then detail:Show() end
        if char then
            if tab == "overview" then self:RefreshOverviewDetail(char)
            elseif tab == "gear" then self:RefreshGearDetail(char)
            elseif tab == "reputations" then self:RefreshReputationsDetail(char, resetScroll)
            elseif tab == "professions" then self:RefreshProfessionsDetail(char)
            elseif tab == "legendary" then self:RefreshLegendaryDetail(char)
            elseif tab == "collections" then self:RefreshCollectionsDetail(char) end
        end
    end
end

function AA:ConfigureDashboardLayout()
    if self.dashboardFrame and self.dashboardFrame._newMainLayout then
        self:RefreshDashboard(false)
    end
end

local function CreateMainDetailHeader(panel)
    panel.title = MainSectionTitle(panel, "")
    panel.title:SetPoint("TOPLEFT", panel, "TOPLEFT", 16, -14)
    panel.charName = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
    panel.charName:SetPoint("TOPLEFT", panel.title, "BOTTOMLEFT", 0, -6)

    panel.headerBanner = panel:CreateTexture(nil, "BACKGROUND")
    panel.headerBanner:SetPoint("TOPLEFT", panel, "TOPLEFT", 2, -2)
    panel.headerBanner:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -2, -2)
    panel.headerBanner:SetHeight(62)
    panel.headerBanner:SetTexture(HEADER_TEXTURE_BASE .. "DEFAULT.tga")

    -- Legacy fields are preserved so other parts of the addon can keep referencing
    -- them safely, but the visible art now comes from the packaged banner texture.
    panel.headerTint = panel:CreateTexture(nil, "BACKGROUND")
    panel.headerTint:SetPoint("TOPLEFT", panel, "TOPLEFT", 2, -2)
    panel.headerTint:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -2, -2)
    panel.headerTint:SetHeight(62)
    panel.headerTint:SetTexture("Interface\\Buttons\\WHITE8X8")
    panel.headerTint:SetVertexColor(.22, .22, .22)
    panel.headerTint:SetAlpha(.16)
    panel.headerTint:Hide()

    panel.headerClassBackdrop = panel:CreateTexture(nil, "ARTWORK")
    panel.headerClassBackdrop:SetSize(1, 1)
    panel.headerClassBackdrop:Hide()

    panel.headerClassArt = panel:CreateTexture(nil, "OVERLAY")
    panel.headerClassArt:SetSize(46, 46)
    panel.headerClassArt:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -16, -8)
    panel.headerClassArt:SetAlpha(1)
    panel.headerClassArt:Hide()

    panel.headerClassBorder = panel:CreateTexture(nil, "OVERLAY")
    panel.headerClassBorder:SetSize(1, 1)
    panel.headerClassBorder:Hide()

    panel.headerSpecArt = panel:CreateTexture(nil, "BORDER")
    panel.headerSpecArt:SetSize(1, 1)
    panel.headerSpecArt:Hide()
    panel.headerSpecBorder = panel:CreateTexture(nil, "ARTWORK")
    panel.headerSpecBorder:SetSize(1, 1)
    panel.headerSpecBorder:Hide()

    panel.headerBottomLine = panel:CreateTexture(nil, "BORDER")
    panel.headerBottomLine:SetPoint("TOPLEFT", panel, "TOPLEFT", 4, -62)
    panel.headerBottomLine:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -4, -62)
    panel.headerBottomLine:SetHeight(1)
    panel.headerBottomLine:SetTexture(.50, .37, .16, .55)
end

function AA:CreateDashboardFrame()
    if self.dashboardFrame then return self.dashboardFrame end
    local frame = CreateFrame("Frame", "AlternatorDashboardFrame", UIParent)
    frame._newMainLayout = true
    local saved = self.db and self.db.settings and self.db.settings.dashboardSize or {}
    frame:SetSize(tonumber(saved.width) or DASHBOARD_WIDTH, tonumber(saved.height) or DASHBOARD_HEIGHT)
    frame:SetPoint("CENTER", UIParent, "CENTER", 0, 10)
    frame:SetFrameStrata("DIALOG")
    if frame.SetToplevel then frame:SetToplevel(true) end
    frame:SetMovable(true); frame:SetResizable(true); frame:SetClampedToScreen(true); frame:EnableMouse(true); frame:RegisterForDrag("LeftButton")
    if frame.SetMinResize then frame:SetMinResize(DASHBOARD_MIN_WIDTH, DASHBOARD_MIN_HEIGHT) end
    if frame.SetMaxResize then frame:SetMaxResize(DASHBOARD_MAX_WIDTH, DASHBOARD_MAX_HEIGHT) end
    frame:SetScript("OnDragStart", function(self) self:StartMoving() end)
    frame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
    frame:SetBackdrop({ edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border", tile=true, tileSize=32, edgeSize=32, insets={left=11,right=12,top=12,bottom=11} })
    local bg=frame:CreateTexture(nil,"BACKGROUND"); bg:SetPoint("TOPLEFT",frame,"TOPLEFT",11,-12); bg:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",-12,11); bg:SetTexture(0.018,0.015,0.012,1)

    local title=frame:CreateFontString(nil,"OVERLAY","GameFontNormal"); title:SetPoint("TOPLEFT",frame,"TOPLEFT",18,-15); title:SetText("Alternator")
    local version=frame:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall"); version:SetPoint("LEFT",title,"RIGHT",8,0); version:SetText("v"..VERSION); version:SetTextColor(.65,.65,.65)
    local close=CreateFrame("Button",nil,frame,"UIPanelCloseButton"); close:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-5,-5)

    local realmLabel=MainSectionTitle(frame,"Realms:"); realmLabel:SetPoint("TOPLEFT",frame,"TOPLEFT",18,-45)
    local realmDD=CreateFrame("Frame","AlternatorDashboardRealmDropDown",frame,"UIDropDownMenuTemplate"); realmDD:SetPoint("LEFT",realmLabel,"RIGHT",-12,-2); self:SetupRealmDropDown(realmDD,125); self.dashboardRealmDropDown=realmDD
    local sortLabel=MainSectionTitle(frame,"Sort:"); sortLabel:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-300,-45)
    local sortDD=CreateFrame("Frame","AlternatorDashboardSortDropDown",frame,"UIDropDownMenuTemplate"); sortDD:SetPoint("LEFT",sortLabel,"RIGHT",-12,-2); self:SetupSortDropDown(sortDD,145); self.dashboardSortDropDown=sortDD
    local scan=CreateFrame("Button",nil,frame,"UIPanelButtonTemplate"); scan:SetSize(105,22); scan:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-34,-39); scan:SetText("Scan current"); scan:SetScript("OnClick",function() AA:ScanCurrentCharacterProfile(false); AA:StartScan(true) end)

    local function CreateNavigationButton(parent, textValue, width)
        local b=CreateFrame("Button",nil,parent)
        b:SetSize(width,28)
        b:SetFrameLevel(parent:GetFrameLevel() + 12)

        b.bgTexture=b:CreateTexture(nil,"BACKGROUND")
        b.bgTexture:SetPoint("TOPLEFT",b,"TOPLEFT",1,-1)
        b.bgTexture:SetPoint("BOTTOMRIGHT",b,"BOTTOMRIGHT",-1,1)

        b.borderTextures={}
        local top=b:CreateTexture(nil,"BORDER"); top:SetPoint("TOPLEFT",b,"TOPLEFT",0,0); top:SetPoint("TOPRIGHT",b,"TOPRIGHT",0,0); top:SetHeight(1); table.insert(b.borderTextures,top); b.topBorder=top
        local left=b:CreateTexture(nil,"BORDER"); left:SetPoint("TOPLEFT",b,"TOPLEFT",0,0); left:SetPoint("BOTTOMLEFT",b,"BOTTOMLEFT",0,0); left:SetWidth(1); table.insert(b.borderTextures,left); b.leftBorder=left
        local right=b:CreateTexture(nil,"BORDER"); right:SetPoint("TOPRIGHT",b,"TOPRIGHT",0,0); right:SetPoint("BOTTOMRIGHT",b,"BOTTOMRIGHT",0,0); right:SetWidth(1); table.insert(b.borderTextures,right); b.rightBorder=right
        local bottom=b:CreateTexture(nil,"BORDER"); bottom:SetPoint("BOTTOMLEFT",b,"BOTTOMLEFT",0,0); bottom:SetPoint("BOTTOMRIGHT",b,"BOTTOMRIGHT",0,0); bottom:SetHeight(1); table.insert(b.borderTextures,bottom); b.bottomBorder=bottom

        b.joinTexture=b:CreateTexture(nil,"OVERLAY")
        b.joinTexture:SetPoint("TOPLEFT",b,"BOTTOMLEFT",1,1)
        b.joinTexture:SetPoint("TOPRIGHT",b,"BOTTOMRIGHT",-1,1)
        b.joinTexture:SetHeight(3)
        b.joinTexture:SetTexture(0.018,0.016,0.014,1)
        b.joinTexture:Hide()

        b.label=b:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        b.label:SetPoint("CENTER",b,"CENTER",0,0)
        b.label:SetText(textValue)
        b.activeLine=b:CreateTexture(nil,"OVERLAY"); b.activeLine:SetSize(1,1); b.activeLine:Hide()
        b:SetScript("OnEnter",function(self)
            if not self._alternatorActive then
                if self.bgTexture then self.bgTexture:SetTexture(0.09,0.075,0.05,1) end
                SetMainTabBorderColor(self,.62,.46,.18,1)
                if self.label then self.label:SetTextColor(1,.84,.28) end
            end
        end)
        b:SetScript("OnLeave",function(self) StyleMainTabButton(self,self._alternatorActive) end)
        return b
    end

    -- Main navigation on the left: Summary and Characters.
    frame.sectionButtons={}
    local previousSection
    for _,opt in ipairs(MAIN_SECTION_OPTIONS) do
        local w = opt.value == "characters" and 96 or 82
        local b=CreateNavigationButton(frame,opt.text,w)
        if previousSection then b:SetPoint("LEFT",previousSection,"RIGHT",4,0) else b:SetPoint("TOPLEFT",frame,"TOPLEFT",18,-90) end
        local sectionValue=opt.value
        b.sectionValue=sectionValue
        b:SetScript("OnClick",function() AA:SetMainDashboardSection(sectionValue) end)
        frame.sectionButtons[sectionValue]=b
        previousSection=b
    end

    -- Character detail navigation lives above the right-hand pane and is only
    -- visible while the Characters section is selected.
    frame.tabButtons={}
    local previous
    for _,opt in ipairs(MAIN_TAB_OPTIONS) do
        local widths = { overview=82, gear=62, reputations=98, professions=98, legendary=118, collections=136 }
        local w = widths[opt.value] or 82
        local b=CreateNavigationButton(frame,opt.text,w)
        if previous then b:SetPoint("LEFT",previous,"RIGHT",4,0) else b:SetPoint("TOPLEFT",frame,"TOPLEFT",400,-90) end
        local tabValue=opt.value
        b.tabValue=tabValue
        b:SetScript("OnClick",function() AA:SetMainDashboardTab(tabValue) end)
        frame.tabButtons[tabValue]=b
        previous=b
    end

    local characterPane=MainShellPanel(frame,2); characterPane:SetPoint("TOPLEFT",frame,"TOPLEFT",18,-118); characterPane:SetPoint("BOTTOMLEFT",frame,"BOTTOMLEFT",18,24); characterPane:SetWidth(370); frame.characterPane=characterPane
    characterPane.title=MainSectionTitle(characterPane,"Characters"); characterPane.title:SetPoint("TOPLEFT",characterPane,"TOPLEFT",12,-10)
    characterPane.count=MainSmallText(characterPane); characterPane.count:SetPoint("TOPRIGHT",characterPane,"TOPRIGHT",-22,-11)
    local cscroll=CreateFrame("ScrollFrame","AlternatorCharacterListScroll",characterPane,"FauxScrollFrameTemplate"); cscroll:SetPoint("TOPLEFT",characterPane,"TOPLEFT",6,-34); cscroll:SetPoint("BOTTOMRIGHT",characterPane,"BOTTOMRIGHT",-24,44); cscroll:SetScript("OnVerticalScroll",function(self,offset) FauxScrollFrame_OnVerticalScroll(self,offset,CHARACTER_CARD_HEIGHT,function() AA:RefreshMainCharacterList() end) end); cscroll:EnableMouseWheel(true); cscroll:SetScript("OnMouseWheel",function(self,d) local sb=self.ScrollBar or _G[self:GetName().."ScrollBar"]; if sb then sb:SetValue(sb:GetValue()-(d*CHARACTER_CARD_HEIGHT*2)) end end); characterPane.scroll=cscroll

    local footerLine=characterPane:CreateTexture(nil,"BORDER"); footerLine:SetPoint("BOTTOMLEFT",characterPane,"BOTTOMLEFT",8,38); footerLine:SetPoint("BOTTOMRIGHT",characterPane,"BOTTOMRIGHT",-26,38); footerLine:SetHeight(1); footerLine:SetTexture(.50,.37,.16,.55)
    local settingsButton=CreateFrame("Button",nil,characterPane,"UIPanelButtonTemplate"); settingsButton:SetSize(150,24); settingsButton:SetPoint("BOTTOMLEFT",characterPane,"BOTTOMLEFT",8,8); settingsButton:SetText("Settings"); settingsButton:SetScript("OnClick",function() AA:OpenOptions() end); characterPane.settingsButton=settingsButton
    local backupManagerButton=CreateFrame("Button",nil,characterPane,"UIPanelButtonTemplate"); backupManagerButton:SetSize(160,24); backupManagerButton:SetPoint("BOTTOMRIGHT",characterPane,"BOTTOMRIGHT",-26,8); backupManagerButton:SetText("Backup Manager"); backupManagerButton:SetScript("OnClick",function() AA:OpenBackupManager() end); characterPane.backupManagerButton=backupManagerButton
    characterPane.cards={}
    for i=1,CHARACTER_CARD_MAX_ROWS do
        local card=CreateFrame("Button",nil,characterPane); card:SetHeight(CHARACTER_CARD_HEIGHT-4); card:SetPoint("TOPLEFT",characterPane,"TOPLEFT",8,-36-((i-1)*CHARACTER_CARD_HEIGHT)); card:SetPoint("RIGHT",characterPane,"RIGHT",-26,0); card:EnableMouse(true)
        card:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",tile=true,tileSize=16,edgeSize=10,insets={left=3,right=3,top=3,bottom=3}}); card:SetBackdropColor(.05,.05,.05,.96); card:SetBackdropBorderColor(.28,.28,.28,1); card.border=card
        card.selectedBG=card:CreateTexture(nil,"BORDER"); card.selectedBG:SetPoint("TOPLEFT",card,"TOPLEFT",4,-4); card.selectedBG:SetPoint("BOTTOMRIGHT",card,"BOTTOMRIGHT",-4,4); card.selectedBG:SetTexture(.32,.18,.03,.55); card.selectedBG:Hide()
        card.selectedStripe=card:CreateTexture(nil,"ARTWORK"); card.selectedStripe:SetPoint("TOPLEFT",card,"TOPLEFT",1,-2); card.selectedStripe:SetPoint("BOTTOMLEFT",card,"BOTTOMLEFT",1,2); card.selectedStripe:SetWidth(3); card.selectedStripe:SetTexture(1,.68,.08,.95); card.selectedStripe:Hide()
        card.classIcon=card:CreateTexture(nil,"ARTWORK"); card.classIcon:SetSize(50,50); card.classIcon:SetPoint("LEFT",card,"LEFT",9,0)
        card.name=card:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); card.name:SetPoint("TOPLEFT",card,"TOPLEFT",68,-8); card.name:SetPoint("RIGHT",card,"RIGHT",-8,0); card.name:SetJustifyH("LEFT")
        card.meta=MainSmallText(card); card.meta:SetPoint("TOPLEFT",card.name,"BOTTOMLEFT",0,-2)
        card.location=MainSmallText(card); card.location:SetPoint("TOPLEFT",card.meta,"BOTTOMLEFT",0,-1); card.location:SetPoint("RIGHT",card,"RIGHT",-8,0); card.location:SetHeight(13); card.location:SetJustifyH("LEFT"); card.location:SetTextColor(.72,.72,.72); if card.location.SetWordWrap then card.location:SetWordWrap(false) end
        card.resources=card:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall"); card.resources:SetPoint("BOTTOMLEFT",card,"BOTTOMLEFT",68,7); card.resources:SetPoint("RIGHT",card,"RIGHT",-8,0); card.resources:SetJustifyH("LEFT"); card.resources:SetTextColor(1,.82,0)
        if STANDARD_TEXT_FONT then
            card.resources:SetFont(STANDARD_TEXT_FONT, 10, "OUTLINE")
            card.meta:SetFont(STANDARD_TEXT_FONT, 10, "OUTLINE")
            card.location:SetFont(STANDARD_TEXT_FONT, 10, "OUTLINE")
        end
        card:SetScript("OnClick",function(self) if self.char then AA:SetSelectedDashboardCharacter(self.char.key) end end)
        card:SetScript("OnEnter",function(self) AA:ShowCharacterCardTooltip(self) end); card:SetScript("OnLeave",function() GameTooltip:Hide() end)
        characterPane.cards[i]=card
    end

    local detailHost=MainShellPanel(frame,2); detailHost:SetPoint("TOPLEFT",characterPane,"TOPRIGHT",12,0); detailHost:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",-18,24); frame.detailHost=detailHost

    -- Tie the navigation strip geometrically to the detail pane rather than to
    -- fixed dashboard coordinates.  A 1px overlap makes the active tab merge
    -- cleanly into the pane even after the window is resized.
    local firstMainTab = frame.tabButtons and frame.tabButtons.overview
    if firstMainTab then
        firstMainTab:ClearAllPoints()
        firstMainTab:SetPoint("BOTTOMLEFT",detailHost,"TOPLEFT",0,0)
    end
    frame.detailFrames={}
    for _,opt in ipairs(MAIN_TAB_OPTIONS) do
        local d=CreateFrame("Frame",nil,detailHost); d:SetAllPoints(detailHost); d:Hide(); frame.detailFrames[opt.value]=d
    end
    local summaryDetail=CreateFrame("Frame",nil,detailHost); summaryDetail:SetAllPoints(detailHost); summaryDetail:Hide(); frame.detailFrames.summary=summaryDetail

    -- Overview detail
    local ov=frame.detailFrames.overview; CreateMainDetailHeader(ov)
    ov.armoryButton=CreateFrame("Button",nil,ov,"UIPanelButtonTemplate")
    ov.armoryButton:SetSize(72,22)
    ov.armoryButton:SetPoint("RIGHT",ov.headerClassArt,"LEFT",-8,0)
    ov.armoryButton:SetText("Armory")
    ov.armoryButton:SetScript("OnClick",function(self)
        if self.character then AA:ShowArmoryLinkPopup(self.character) end
    end)
    ov.armoryButton:SetScript("OnEnter",function(self)
        GameTooltip:SetOwner(self,"ANCHOR_BOTTOM")
        GameTooltip:AddLine("TwinStar Armory",1,.82,0)
        GameTooltip:AddLine("Show a selectable Armory URL for this character.",.78,.78,.78,true)
        GameTooltip:Show()
    end)
    ov.armoryButton:SetScript("OnLeave",function() GameTooltip:Hide() end)

    -- Keep the class banner fixed while the complete Overview body scrolls.
    -- This gives Character statistics its own lower section and prevents any
    -- content from disappearing when the dashboard is made shorter.
    ov.contentScroll=CreateFrame("ScrollFrame","AlternatorOverviewContentScroll",ov,"UIPanelScrollFrameTemplate")
    ov.contentScroll:SetPoint("TOPLEFT",ov,"TOPLEFT",10,-70)
    ov.contentScroll:SetPoint("BOTTOMRIGHT",ov,"BOTTOMRIGHT",-30,10)
    ov.contentScroll:EnableMouseWheel(true)
    ov.contentChild=CreateFrame("Frame",nil,ov.contentScroll)
    ov.contentChild:SetWidth(math.max(620,(ov:GetWidth() or 650)-54))
    ov.contentChild:SetHeight(650)
    ov.contentScroll:SetScrollChild(ov.contentChild)
    ov.contentScroll:SetScript("OnMouseWheel",function(self,delta)
        local current=self:GetVerticalScroll() or 0
        local maximum=self:GetVerticalScrollRange() or 0
        local target=current-(delta*42)
        if target<0 then target=0 end
        if target>maximum then target=maximum end
        self:SetVerticalScroll(target)
    end)
    ov.contentScroll:SetScript("OnSizeChanged",function(self,width)
        if ov.contentChild then ov.contentChild:SetWidth(math.max(620,(tonumber(width) or 650)-8)) end
    end)
    local overviewBody=ov.contentChild

    local labels={
        {"Level","levelValue"},
        {"Realm","realmValue"},
        {"Race","raceValue"},
        {"Gender","genderValue"},
        {"Primary specialization","primarySpecValue","primary"},
        {"Secondary specialization","secondarySpecValue","secondary"},
        {"Location","locationValue"},
        {"Gold","moneyValue"},
        {"Last seen","lastSeenValue"},
        {"Played time","playedValue"},
        {"Achievement points","apValue"},
    }
    local last
    for i,entry in ipairs(labels) do
        local l=MainSmallText(overviewBody); l:SetText(entry[1]); if i==1 then l:SetPoint("TOPLEFT",overviewBody,"TOPLEFT",6,-8) else l:SetPoint("TOPLEFT",last,"BOTTOMLEFT",0,-12) end; l:SetWidth(150); l:SetJustifyH("LEFT"); l:SetTextColor(.65,.65,.65)
        local v=overviewBody:CreateFontString(nil,"OVERLAY","GameFontHighlight")
        if entry[3] then
            local prefix=entry[3]
            local icon=overviewBody:CreateTexture(nil,"ARTWORK"); icon:SetSize(22,22); icon:SetPoint("LEFT",l,"RIGHT",12,0); icon:SetTexCoord(.08,.92,.08,.92); ov[prefix.."SpecIcon"]=icon
            v:SetPoint("LEFT",icon,"RIGHT",7,0)
            local hitbox=CreateFrame("Frame",nil,overviewBody); hitbox:SetPoint("LEFT",icon,"LEFT",-2,0); hitbox:SetPoint("RIGHT",v,"RIGHT",0,0); hitbox:SetHeight(26); hitbox:EnableMouse(true); ov[prefix.."SpecHitbox"]=hitbox
            hitbox:SetScript("OnEnter",function(self)
                local spec=self.specialization
                if not spec then return end
                GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
                GameTooltip:ClearLines()
                GameTooltip:AddLine(spec.name or "Specialization",1,.82,0)
                if self.isActive then GameTooltip:AddLine("Active specialization",1,.82,0) end
                if spec.role and spec.role ~= "" then GameTooltip:AddLine("Role: "..tostring(spec.role),.85,.85,.85) end
                if spec.description and spec.description ~= "" then GameTooltip:AddLine(spec.description,.72,.72,.72,true) end
                GameTooltip:Show()
            end)
            hitbox:SetScript("OnLeave",function() GameTooltip:Hide() end)
        else
            v:SetPoint("LEFT",l,"RIGHT",12,0)
        end
        v:SetPoint("RIGHT",overviewBody,"LEFT",395,0); v:SetJustifyH("LEFT"); ov[entry[2]]=v; last=l
    end

    -- Character statistics occupy the upper-right side of the Overview while
    -- the original character profile remains unchanged on the upper-left.
    local statisticsX = 430
    ov.statisticsTitle=MainSectionTitle(overviewBody,"Character statistics")
    ov.statisticsTitle:SetPoint("TOPLEFT",overviewBody,"TOPLEFT",statisticsX,-8)

    ov.statisticsPeriodLabel=MainSmallText(overviewBody); ov.statisticsPeriodLabel:SetText("Period:")
    ov.statisticsPeriodLabel:SetPoint("TOPLEFT",ov.statisticsTitle,"BOTTOMLEFT",0,-12)
    ov.statisticsPeriodLabel:SetTextColor(.65,.65,.65)
    local statsPeriodDD=CreateFrame("Frame","AlternatorStatisticsPeriodDropDown",overviewBody,"UIDropDownMenuTemplate")
    statsPeriodDD:SetPoint("LEFT",ov.statisticsPeriodLabel,"RIGHT",-8,-2)
    AA:SetupStatisticsPeriodDropDown(statsPeriodDD)
    ov.statisticsPeriodDropDown=statsPeriodDD
    frame.statisticsPeriodDropDown=statsPeriodDD

    local customFromLabel=MainSmallText(overviewBody); customFromLabel:SetText("From:")
    customFromLabel:SetPoint("TOPLEFT",ov.statisticsPeriodLabel,"BOTTOMLEFT",0,-12); customFromLabel:SetTextColor(.65,.65,.65); customFromLabel:Hide()

    local function CreateStatisticsDateEditBox(parent)
        local box=CreateFrame("EditBox",nil,parent)
        box:SetSize(92,22)
        box:SetAutoFocus(false)
        box:SetMaxLetters(10)
        box:SetFontObject(GameFontHighlightSmall)
        box:SetJustifyH("CENTER")
        if box.SetTextInsets then box:SetTextInsets(5,5,0,0) end
        box:SetBackdrop({
            bgFile="Interface\\ChatFrame\\ChatFrameBackground",
            edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",
            tile=true, tileSize=16, edgeSize=10,
            insets={left=3,right=3,top=3,bottom=3},
        })
        box:SetBackdropColor(.03,.03,.03,.95)
        box:SetBackdropBorderColor(.38,.38,.38,1)
        return box
    end

    local customFromBox=CreateStatisticsDateEditBox(overviewBody)
    customFromBox:SetPoint("LEFT",customFromLabel,"RIGHT",6,0); customFromBox:Hide()
    local customToLabel=MainSmallText(overviewBody); customToLabel:SetText("To:")
    customToLabel:SetPoint("LEFT",customFromBox,"RIGHT",10,0); customToLabel:SetTextColor(.65,.65,.65); customToLabel:Hide()
    local customToBox=CreateStatisticsDateEditBox(overviewBody)
    customToBox:SetPoint("LEFT",customToLabel,"RIGHT",6,0); customToBox:Hide()

    local function CommitCustomDate(self)
        self:ClearFocus()
        AA:CommitStatisticsCustomRange()
    end
    customFromBox:SetScript("OnEnterPressed",CommitCustomDate)
    customToBox:SetScript("OnEnterPressed",CommitCustomDate)
    customFromBox:SetScript("OnEditFocusLost",function() AA:CommitStatisticsCustomRange() end)
    customToBox:SetScript("OnEditFocusLost",function() AA:CommitStatisticsCustomRange() end)
    customFromBox:SetScript("OnEscapePressed",function(self) self:SetText(AA.db.settings.statisticsCustomFrom or ""); self:ClearFocus() end)
    customToBox:SetScript("OnEscapePressed",function(self) self:SetText(AA.db.settings.statisticsCustomTo or ""); self:ClearFocus() end)

    ov.statisticsCustomFromLabel=customFromLabel; ov.statisticsCustomFromBox=customFromBox
    ov.statisticsCustomToLabel=customToLabel; ov.statisticsCustomToBox=customToBox
    frame.statisticsCustomFromLabel=customFromLabel; frame.statisticsCustomFromBox=customFromBox
    frame.statisticsCustomToLabel=customToLabel; frame.statisticsCustomToBox=customToBox

    local function CreateStatValueRow(labelText, anchor, y, valueKey)
        local label=MainSmallText(overviewBody)
        label:SetText(labelText)
        label:SetPoint("TOPLEFT",anchor,"BOTTOMLEFT",0,y)
        label:SetWidth(118)
        label:SetJustifyH("LEFT")
        label:SetTextColor(.65,.65,.65)
        local value=overviewBody:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        value:SetPoint("LEFT",label,"RIGHT",8,0)
        value:SetPoint("RIGHT",overviewBody,"RIGHT",-18,0)
        value:SetJustifyH("LEFT")
        ov[valueKey]=value
        return label
    end

    -- Quests and Gold are stacked vertically in one right-side statistics block.
    ov.statQuestHeader=MainSectionTitle(overviewBody,"Quests")
    ov.statQuestHeader:SetPoint("TOPLEFT",ov.statisticsTitle,"BOTTOMLEFT",0,-64)
    CreateStatValueRow("Completed",ov.statQuestHeader,-10,"statQuestTotalValue")
    CreateStatValueRow("Daily quests",ov.statQuestHeader,-30,"statQuestDailyValue")
    ov.statQuestModeValue=overviewBody:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    ov.statQuestModeValue:SetPoint("TOPLEFT",ov.statQuestHeader,"BOTTOMLEFT",0,-50)

    ov.statGoldHeader=MainSectionTitle(overviewBody,"Gold acquired")
    ov.statGoldHeader:SetPoint("TOPLEFT",ov.statQuestHeader,"BOTTOMLEFT",0,-78)
    CreateStatValueRow("Total acquired",ov.statGoldHeader,-10,"statGoldTotalValue")
    CreateStatValueRow("Looted",ov.statGoldHeader,-30,"statGoldLootedValue")
    CreateStatValueRow("Quest rewards",ov.statGoldHeader,-50,"statGoldQuestValue")
    CreateStatValueRow("Auctions",ov.statGoldHeader,-70,"statGoldAuctionValue")
    CreateStatValueRow("Vendors",ov.statGoldHeader,-90,"statGoldVendorValue")
    ov.statisticsTrackingNote=overviewBody:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    ov.statisticsTrackingNote:SetPoint("TOPLEFT",ov.statGoldHeader,"BOTTOMLEFT",0,-112)
    ov.statisticsTrackingNote:SetPoint("RIGHT",overviewBody,"RIGHT",-18,0)
    ov.statisticsTrackingNote:SetJustifyH("LEFT")

    -- All currencies are shown below both upper blocks in a single vertical list.
    ov.currencyTitle=MainSectionTitle(overviewBody,"Currencies")
    ov.currencyTitle:SetPoint("TOPLEFT",overviewBody,"TOPLEFT",6,-330)
    ov.currencyRows={}
    for i=1,#TRACKED_CURRENCIES do
        local r=CreateFrame("Frame",nil,overviewBody)
        r:SetHeight(21)
        r:SetWidth(390)
        r:SetPoint("TOPLEFT",ov.currencyTitle,"BOTTOMLEFT",0,-8-((i-1)*22))
        r.icon=r:CreateTexture(nil,"ARTWORK")
        r.icon:SetSize(17,17)
        r.icon:SetPoint("LEFT",r,"LEFT",0,0)
        r.label=MainSmallText(r)
        r.label:SetPoint("LEFT",r.icon,"RIGHT",5,0)
        r.label:SetWidth(270)
        r.label:SetJustifyH("LEFT")
        r.value=r:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        r.value:SetPoint("RIGHT",r,"RIGHT",0,0)
        r.value:SetJustifyH("RIGHT")
        ov.currencyRows[i]=r
    end

    -- Gear detail
    local gear=frame.detailFrames.gear; CreateMainDetailHeader(gear)
    gear.itemLevelLabel=MainSmallText(gear); gear.itemLevelLabel:SetPoint("TOPLEFT",gear.charName,"BOTTOMLEFT",0,-22); gear.itemLevelLabel:SetText("Equipped item level"); gear.itemLevelLabel:SetTextColor(.65,.65,.65)
    gear.itemLevelValue=gear:CreateFontString(nil,"OVERLAY","GameFontNormalLarge"); gear.itemLevelValue:SetPoint("LEFT",gear.itemLevelLabel,"RIGHT",12,0); gear.itemLevelValue:SetTextColor(1,.82,0)
    gear.scanInfo=MainSmallText(gear); gear.scanInfo:SetPoint("TOPRIGHT",gear,"TOPRIGHT",-18,-82); gear.scanInfo:SetJustifyH("RIGHT"); gear.scanInfo:SetTextColor(.55,.55,.55)
    gear.auditStatus=gear:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); gear.auditStatus:SetPoint("TOPLEFT",gear,"TOPLEFT",18,-88); gear.auditStatus:SetPoint("RIGHT",gear,"RIGHT",-300,0); gear.auditStatus:SetJustifyH("LEFT"); gear.auditStatus:SetTextColor(1,.62,.15)

    gear.tableHeader=CreateFrame("Frame",nil,gear)
    gear.tableHeader:SetPoint("TOPLEFT",gear,"TOPLEFT",18,-116)
    gear.tableHeader:SetWidth(800)
    gear.tableHeader:SetHeight(24)
    local headerBG=gear.tableHeader:CreateTexture(nil,"BACKGROUND"); headerBG:SetAllPoints(gear.tableHeader); headerBG:SetTexture(.04,.04,.04,.95)
    gear.tableHeader.slot=gear.tableHeader:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    gear.tableHeader.item=gear.tableHeader:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    gear.tableHeader.ilvl=gear.tableHeader:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    gear.tableHeader.gems=gear.tableHeader:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    gear.tableHeader.enchant=gear.tableHeader:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    gear.tableHeader.tinker=gear.tableHeader:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    gear.tableHeader.reforge=gear.tableHeader:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    gear.tableHeader.slot:SetText("Slot"); gear.tableHeader.item:SetText("Item"); gear.tableHeader.ilvl:SetText("iLevel"); gear.tableHeader.gems:SetText("Gems"); gear.tableHeader.enchant:SetText("Enchant"); gear.tableHeader.tinker:SetText("Tinker"); gear.tableHeader.reforge:SetText("Reforge")

    local function LayoutGearColumns(container,isHeader,showTinker)
        local slot=container.slot or container.slotLabel
        local item=container.item or container.itemName
        local ilvl=container.ilvl or container.itemLevel
        local gems=container.gems or container.gemsAnchor
        local enchant=container.enchant or (container.enchantBox and container.enchantBox.text)
        local tinker=container.tinker or (container.tinkerBox and container.tinkerBox.text)
        local reforge=container.reforge or (container.reforgeBox and container.reforgeBox.text)
        if not slot or not item or not ilvl or not gems or not enchant or not tinker or not reforge then return end

        slot:ClearAllPoints(); slot:SetPoint("LEFT",container,"LEFT",8,0); slot:SetWidth(56); slot:SetJustifyH("LEFT")
        if isHeader then
            item:ClearAllPoints(); item:SetPoint("LEFT",container,"LEFT",70,0); item:SetPoint("RIGHT",container,"CENTER",-130,0); item:SetJustifyH("LEFT")
        else
            container.icon:ClearAllPoints(); container.icon:SetPoint("LEFT",container,"LEFT",70,0)
            item:ClearAllPoints(); item:SetPoint("LEFT",container.icon,"RIGHT",6,0); item:SetPoint("RIGHT",container,"CENTER",-130,0); item:SetJustifyH("LEFT")
        end
        ilvl:ClearAllPoints(); ilvl:SetPoint("LEFT",container,"CENTER",-120,0); ilvl:SetWidth(78); ilvl:SetJustifyH("CENTER")
        gems:ClearAllPoints(); gems:SetPoint("LEFT",container,"CENTER",-34,0); gems:SetWidth(74); gems:SetJustifyH("LEFT")
        enchant:ClearAllPoints(); enchant:SetPoint("LEFT",container,"CENTER",46,0); enchant:SetWidth(110); enchant:SetJustifyH("LEFT")
        tinker:ClearAllPoints(); tinker:SetPoint("LEFT",container,"CENTER",162,0); tinker:SetWidth(100); tinker:SetJustifyH("LEFT")
        reforge:ClearAllPoints()
        if showTinker then
            reforge:SetPoint("LEFT",container,"CENTER",268,0)
        else
            reforge:SetPoint("LEFT",container,"CENTER",162,0)
        end
        reforge:SetPoint("RIGHT",container,"RIGHT",-8,0); reforge:SetJustifyH("LEFT")

        if not isHeader then
            if container.enchantBox then
                container.enchantBox:ClearAllPoints(); container.enchantBox:SetPoint("LEFT",container,"CENTER",46,0); container.enchantBox:SetWidth(110)
            end
            if container.tinkerBox then
                container.tinkerBox:ClearAllPoints(); container.tinkerBox:SetPoint("LEFT",container,"CENTER",162,0); container.tinkerBox:SetWidth(100)
            end
            if container.reforgeBox then
                container.reforgeBox:ClearAllPoints()
                if showTinker then container.reforgeBox:SetPoint("LEFT",container,"CENTER",268,0)
                else container.reforgeBox:SetPoint("LEFT",container,"CENTER",162,0) end
                container.reforgeBox:SetPoint("RIGHT",container,"RIGHT",-8,0)
            end
        end
    end
    gear.LayoutGearColumns=LayoutGearColumns
    LayoutGearColumns(gear.tableHeader,true,true)

    -- Gear rows live in their own clipped ScrollFrame.  No matter how short the
    -- dashboard becomes, rows can never draw outside the Gear page.
    gear.scrollFrame=CreateFrame("ScrollFrame","AlternatorGearScrollFrame",gear,"UIPanelScrollFrameTemplate")
    gear.scrollFrame:SetPoint("TOPLEFT",gear.tableHeader,"BOTTOMLEFT",0,-2)
    gear.scrollFrame:SetPoint("BOTTOMRIGHT",gear,"BOTTOMRIGHT",-30,12)
    gear.scrollFrame:EnableMouseWheel(true)
    gear.scrollChild=CreateFrame("Frame",nil,gear.scrollFrame)
    gear.scrollChild:SetPoint("TOPLEFT",gear.scrollFrame,"TOPLEFT",0,0)
    gear.scrollChild:SetHeight(math.max(1,#GEAR_SLOTS*29))
    gear.scrollFrame:SetScrollChild(gear.scrollChild)
    gear.scrollFrame:SetScript("OnMouseWheel",function(self,delta)
        local sb=_G[self:GetName().."ScrollBar"]
        if sb and sb:IsShown() then sb:SetValue(sb:GetValue()-(delta*58)) end
    end)

    gear.gearRows={}
    for i,slot in ipairs(GEAR_SLOTS) do
        local row=MainPanel(gear.scrollChild,1)
        row:SetHeight(27)
        row:SetPoint("TOPLEFT",gear.scrollChild,"TOPLEFT",0,-((i-1)*29))
        row:SetWidth(800)
        row.slotDef=slot
        row.slotLabel=MainSmallText(row); row.slotLabel:SetTextColor(.62,.62,.62)
        row.auditMark=row:CreateFontString(nil,"OVERLAY","GameFontNormalLarge"); row.auditMark:SetPoint("RIGHT",row.slotLabel,"RIGHT",-2,0); row.auditMark:SetText("!"); row.auditMark:SetTextColor(1.0,0.12,0.12); row.auditMark:Hide()
        row.icon=row:CreateTexture(nil,"ARTWORK"); row.icon:SetSize(22,22); row.icon:SetTexCoord(.06,.94,.06,.94)
        row.itemName=row:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall"); row.itemName:SetWordWrap(false)
        row.itemLevel=row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); row.itemLevel:SetTextColor(1,.82,0); row.itemLevel:SetWordWrap(false)
        row.gemsAnchor=row:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall"); row.gemsAnchor:SetText("")

        row.gemButtons={}
        for gemIndex=1,4 do
            local gemButton=CreateFrame("Frame",nil,row)
            gemButton:SetSize(18,18)
            gemButton.icon=gemButton:CreateTexture(nil,"ARTWORK"); gemButton.icon:SetAllPoints(gemButton); gemButton.icon:SetTexCoord(.08,.92,.08,.92)
            gemButton.extraBorder=CreateFrame("Frame",nil,gemButton)
            gemButton.extraBorder:SetPoint("TOPLEFT",gemButton,"TOPLEFT",-2,2); gemButton.extraBorder:SetPoint("BOTTOMRIGHT",gemButton,"BOTTOMRIGHT",2,-2)
            gemButton.extraBorder:SetFrameLevel(gemButton:GetFrameLevel()+2)
            if gemButton.extraBorder.SetBackdrop then
                gemButton.extraBorder:SetBackdrop({edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",edgeSize=7})
                gemButton.extraBorder:SetBackdropBorderColor(1,.72,.08,1)
            end
            gemButton.extraBorder:Hide()
            gemButton.emptyPlus=gemButton:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            gemButton.emptyPlus:SetPoint("CENTER",gemButton,"CENTER",0,0); gemButton.emptyPlus:SetText("+"); gemButton.emptyPlus:SetTextColor(1,.82,0); gemButton.emptyPlus:Hide()
            gemButton:EnableMouse(true)
            gemButton:SetScript("OnEnter",function(self)
                local gem=self.gemData
                GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
                if gem and gem.link then
                    GameTooltip:SetHyperlink(gem.link)
                else
                    GameTooltip:ClearLines()
                    if gem then GameTooltip:AddLine(gem.name or "Gem",1,.82,0)
                    elseif self.extraSocketLabel then GameTooltip:AddLine(self.extraSocketLabel,1,.82,0) end
                end
                if self.extraSocketLabel then
                    GameTooltip:AddLine(" ")
                    GameTooltip:AddLine(self.extraSocketLabel,1,.72,.08,true)
                    if not gem then GameTooltip:AddLine("Empty prismatic socket",.7,.7,.7,true) end
                end
                GameTooltip:Show()
            end)
            gemButton:SetScript("OnLeave",function() GameTooltip:Hide() end)
            gemButton:Hide(); row.gemButtons[gemIndex]=gemButton
        end

        row.enchantBox=CreateFrame("Frame",nil,row); row.enchantBox:SetHeight(24); row.enchantBox:EnableMouse(true)
        row.enchantBox.text=row.enchantBox:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall"); row.enchantBox.text:SetPoint("LEFT",row.enchantBox,"LEFT",0,0); row.enchantBox.text:SetPoint("RIGHT",row.enchantBox,"RIGHT",0,0); row.enchantBox.text:SetWordWrap(false)
        row.enchantBox:SetScript("OnEnter",function(self)
            local item=self.itemData; if not item then return end
            GameTooltip:SetOwner(self,"ANCHOR_RIGHT"); GameTooltip:ClearLines(); GameTooltip:AddLine("Enchant",1,.82,0)
            local text=AA:GearCleanEnchantText(item.enchantText)
            if text=="" and item.enchantID and tonumber(item.enchantID)>0 then text="Enchant ID "..tostring(item.enchantID) end
            if text~="" then
                GameTooltip:AddLine(text,.3,1,.3,true)
            elseif self:GetParent() and self:GetParent().slotDef and GearItemShouldHaveEnchant(self:GetParent().slotDef.key,item) then
                GameTooltip:AddLine("No enchant",1,.18,.18,true)
            else
                GameTooltip:AddLine("Not applicable",.55,.55,.55,true)
            end
            GameTooltip:Show()
        end)
        row.enchantBox:SetScript("OnLeave",function() GameTooltip:Hide() end)

        row.tinkerBox=CreateFrame("Frame",nil,row); row.tinkerBox:SetHeight(24); row.tinkerBox:EnableMouse(true)
        row.tinkerBox.text=row.tinkerBox:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall"); row.tinkerBox.text:SetPoint("LEFT",row.tinkerBox,"LEFT",0,0); row.tinkerBox.text:SetPoint("RIGHT",row.tinkerBox,"RIGHT",0,0); row.tinkerBox.text:SetWordWrap(false)
        row.tinkerBox:SetScript("OnEnter",function(self)
            local item=self.itemData; if not item then return end
            GameTooltip:SetOwner(self,"ANCHOR_RIGHT"); GameTooltip:ClearLines(); GameTooltip:AddLine("Engineering tinker",1,.82,0)
            local text=tostring(item.tinkerText or "")
            GameTooltip:AddLine(text~="" and text or "No tinker detected",.95,.65,.15,true); GameTooltip:Show()
        end)
        row.tinkerBox:SetScript("OnLeave",function() GameTooltip:Hide() end)

        row.reforgeBox=CreateFrame("Frame",nil,row); row.reforgeBox:SetHeight(24); row.reforgeBox:EnableMouse(true)
        row.reforgeBox.text=row.reforgeBox:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall"); row.reforgeBox.text:SetPoint("LEFT",row.reforgeBox,"LEFT",0,0); row.reforgeBox.text:SetPoint("RIGHT",row.reforgeBox,"RIGHT",0,0); row.reforgeBox.text:SetWordWrap(false)
        row.reforgeBox:SetScript("OnEnter",function(self)
            local item=self.itemData; if not item then return end
            GameTooltip:SetOwner(self,"ANCHOR_RIGHT"); GameTooltip:ClearLines(); GameTooltip:AddLine("Reforge",1,.82,0)
            local text=AA:GearCleanReforgeText(item.reforgeText)
            GameTooltip:AddLine(text~="" and text or "Not reforged",.4,.75,1,true); GameTooltip:Show()
        end)
        row.reforgeBox:SetScript("OnLeave",function() GameTooltip:Hide() end)

        row:EnableMouse(true)
        row:SetScript("OnEnter",function(self)
            local item=self.itemData; local auditData=self.auditData
            GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
            if item and item.link then GameTooltip:SetHyperlink(item.link) else GameTooltip:ClearLines(); GameTooltip:AddLine((self.slotDef and self.slotDef.label) or "Gear slot",1,.82,0) end
            if auditData and #(auditData.issues or {})>0 then
                GameTooltip:AddLine(" "); GameTooltip:AddLine("Gear audit",1,.82,0)
                for _,issue in ipairs(auditData.issues) do
                    local r,g,b=1.0,0.65,0.15; if issue.severity=="error" then r,g,b=1.0,0.28,0.28 end
                    GameTooltip:AddLine("• "..tostring(issue.text or "Issue"),r,g,b,true)
                end
            end
            GameTooltip:Show()
        end)
        row:SetScript("OnLeave",function() GameTooltip:Hide() end)

        LayoutGearColumns(row,false,true)
        row.gemsAnchor:SetText("")
        for gemIndex=1,4 do
            local gemButton=row.gemButtons[gemIndex]
            gemButton:ClearAllPoints()
            gemButton:SetPoint("LEFT",row.gemsAnchor,"LEFT",(gemIndex-1)*19,0)
        end
        row.enchantBox:SetWidth(104)
        row.tinkerBox:SetWidth(104)
        gear.gearRows[i]=row
    end

    function gear:UpdateGearScrollLayout()
        local sf=self.scrollFrame
        local child=self.scrollChild
        if not sf or not child then return end
        local viewHeight=math.max(1,sf:GetHeight() or 1)
        local contentHeight=math.max(1,#(self.gearRows or {})*29)
        child:SetHeight(contentHeight)
        local needsScroll=contentHeight>(viewHeight+1)
        local sb=_G[sf:GetName().."ScrollBar"]
        if sb then
            if needsScroll then sb:Show() else sb:Hide(); sf:SetVerticalScroll(0) end
        end
        local contentWidth=math.max(420,(sf:GetWidth() or 800)-(needsScroll and 22 or 0))
        child:SetWidth(contentWidth)
        self.tableHeader:SetWidth(contentWidth)
        if self.LayoutGearColumns then
            self.LayoutGearColumns(self.tableHeader,true,self.showTinker ~= false)
            if self.tableHeader.tinker then
                if self.showTinker ~= false then self.tableHeader.tinker:Show() else self.tableHeader.tinker:Hide() end
            end
            for _,row in ipairs(self.gearRows or {}) do
                row:SetWidth(contentWidth)
                self.LayoutGearColumns(row,false,self.showTinker ~= false)
                for gemIndex=1,4 do
                    local gemButton=row.gemButtons and row.gemButtons[gemIndex]
                    if gemButton then gemButton:ClearAllPoints(); gemButton:SetPoint("LEFT",row.gemsAnchor,"LEFT",(gemIndex-1)*19,0) end
                end
                if row.enchantBox then row.enchantBox:SetWidth(110) end
                if row.tinkerBox then row.tinkerBox:SetWidth(100); if self.showTinker ~= false then row.tinkerBox:Show() else row.tinkerBox:Hide() end end
            end
        end
    end
    gear:HookScript("OnSizeChanged",function(self) self:UpdateGearScrollLayout() end)
    gear.scrollFrame:HookScript("OnSizeChanged",function() gear:UpdateGearScrollLayout() end)
    gear:UpdateGearScrollLayout()

    -- Reputations detail
    local rep=frame.detailFrames.reputations; CreateMainDetailHeader(rep)
    rep.status=MainSmallText(rep); rep.status:SetPoint("TOPLEFT",rep.charName,"BOTTOMLEFT",0,-22); rep.status:SetPoint("RIGHT",rep,"RIGHT",-34,0); rep.status:SetJustifyH("LEFT"); rep.status:SetTextColor(.62,.62,.62)
    rep.scroll=CreateFrame("ScrollFrame","AlternatorReputationScroll",rep,"FauxScrollFrameTemplate")
    rep.scroll:SetPoint("TOPLEFT",rep,"TOPLEFT",10,-98)
    rep.scroll:SetPoint("BOTTOMRIGHT",rep,"BOTTOMRIGHT",-24,10)
    rep.scroll:SetScript("OnVerticalScroll",function(self,offset) FauxScrollFrame_OnVerticalScroll(self,offset,38,function() local c=AA:GetSelectedDashboardCharacter(AA:GetDashboardCharactersSorted()); if c then AA:RefreshReputationsDetail(c,false) end end) end)
    rep.scroll:EnableMouseWheel(true)
    rep.scroll:SetScript("OnMouseWheel",function(self,d) local sb=self.ScrollBar or _G[self:GetName().."ScrollBar"]; if sb then sb:SetValue(sb:GetValue()-(d*76)) end end)
    rep.rows={}
    for i=1,16 do
        local row=CreateFrame("Frame",nil,rep); row:SetHeight(34); row:SetPoint("TOPLEFT",rep,"TOPLEFT",18,-100-((i-1)*38)); row:SetPoint("RIGHT",rep,"RIGHT",-34,0); row:EnableMouse(true)
        row.barBG=row:CreateTexture(nil,"BACKGROUND"); row.barBG:SetPoint("TOPLEFT",row,"TOPLEFT",0,-16); row.barBG:SetPoint("BOTTOMRIGHT",row,"BOTTOMRIGHT",0,0); row.barBG:SetTexture(.06,.06,.06,.92)
        row.barFill=row:CreateTexture(nil,"BORDER"); row.barFill:SetPoint("TOPLEFT",row.barBG,"TOPLEFT",1,-1); row.barFill:SetPoint("BOTTOMLEFT",row.barBG,"BOTTOMLEFT",1,1); row.barFill:SetWidth(1)
        row.name=row:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall"); row.name:SetPoint("TOPLEFT",row,"TOPLEFT",4,0); row.name:SetPoint("RIGHT",row,"RIGHT",-250,0); row.name:SetJustifyH("LEFT")
        row.standing=row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); row.standing:SetPoint("TOPRIGHT",row,"TOPRIGHT",-118,0); row.standing:SetWidth(120); row.standing:SetJustifyH("RIGHT")
        row.value=row:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall"); row.value:SetPoint("TOPRIGHT",row,"TOPRIGHT",-4,0); row.value:SetWidth(104); row.value:SetJustifyH("RIGHT")
        row:SetScript("OnEnter",function(self)
            local data=self.repData
            if not data then return end
            GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
            GameTooltip:ClearLines()
            GameTooltip:AddLine(data.name or "Reputation",1,.82,0)
            GameTooltip:AddDoubleLine("Standing",data.standing or "Unknown",.72,.72,.72,1,1,1)
            if data.needed and data.needed>0 then GameTooltip:AddDoubleLine("Progress",string.format("%d / %d",data.progress or 0,data.needed or 0),.72,.72,.72,1,1,1) end
            if data.description and data.description~="" then GameTooltip:AddLine(" "); GameTooltip:AddLine(data.description,.78,.78,.78,true) end
            GameTooltip:Show()
        end)
        row:SetScript("OnLeave",function() GameTooltip:Hide() end)
        row:SetScript("OnSizeChanged",function(self) if self.progressRatio and self.barBG then self.barFill:SetWidth(math.max(1,((self.barBG:GetWidth() or 280)-2)*self.progressRatio)) end end)
        rep.rows[i]=row
    end

    -- Professions detail
    -- The whole profession body scrolls as one unit. The header and bottom
    -- Recipe Scan / Recipe Search controls remain fixed, while profession rows,
    -- the empty-state message and cooldown list live inside one scroll child.
    local pf = frame.detailFrames.professions
    CreateMainDetailHeader(pf)
    pf.profRows = {}

    pf.contentScroll=CreateFrame("ScrollFrame","AlternatorProfessionsContentScroll",pf,"UIPanelScrollFrameTemplate")
    pf.contentScroll:SetPoint("TOPLEFT",pf,"TOPLEFT",10,-70)
    pf.contentScroll:SetPoint("BOTTOMRIGHT",pf,"BOTTOMRIGHT",-30,56)
    pf.contentScroll:EnableMouseWheel(true)
    pf.contentChild=CreateFrame("Frame",nil,pf.contentScroll)
    pf.contentChild:SetWidth(math.max(420,(pf:GetWidth() or 600)-54))
    pf.contentChild:SetHeight(520)
    pf.contentScroll:SetScrollChild(pf.contentChild)
    pf.contentScroll:SetScript("OnMouseWheel",function(self,delta)
        local current=self:GetVerticalScroll() or 0
        local maximum=self:GetVerticalScrollRange() or 0
        local target=current-(delta*42)
        if target<0 then target=0 end
        if target>maximum then target=maximum end
        self:SetVerticalScroll(target)
    end)

    local function SetProfessionTooltip(button)
        local prof = button.profession
        if not prof then return end
        GameTooltip:SetOwner(button, "ANCHOR_RIGHT")
        GameTooltip:ClearLines()
        GameTooltip:AddLine(ProfessionDisplayName(prof), 1, 0.82, 0)
        GameTooltip:AddDoubleLine("Skill", tostring(prof.skill or 0) .. " / " .. tostring(prof.max or 0), 0.7,0.7,0.7, 1,1,1)
        if button.actionMode == "secure" then
            GameTooltip:AddLine("Click to open Blizzard's profession window.", 0.65, 0.85, 1.0, true)
            GameTooltip:AddLine("/cast " .. tostring(button.professionSpellName or prof.name or ProfessionDisplayName(prof)), 0.55, 0.55, 0.55, true)
        elseif button.actionMode == "archaeology" then
            GameTooltip:AddLine("Click to open Blizzard's Archaeology window.", 0.65, 0.85, 1.0, true)
        elseif button.actionMode == "snapshot" then
            GameTooltip:AddLine("Click to open Alternator's stored profession view for this character.", 0.65, 0.85, 1.0, true)
        elseif button.actionMode == "combat" then
            GameTooltip:AddLine("Profession actions are locked while combat lockdown is active.", 1.0, 0.55, 0.25, true)
        end
        GameTooltip:Show()
    end

    local function StandardProfessionOpenClick(button)
        local prof = button.profession
        if not prof then return end
        if button.actionMode == "archaeology" then
            AA:OpenNativeProfessionForCharacter(button.charKey, prof)
        elseif button.actionMode == "snapshot" then
            AA:OpenStoredProfessionForCharacter(button.charKey, prof)
        elseif button.actionMode == "secure" then
            AA:OpenProfessionForRecipeScan(prof.name or ProfessionDisplayName(prof))
        end
    end

    local function StyleProfessionOpenButton(button)
        if not button then return end
        button:SetText("Open")
        local fs = button:GetFontString()
        if fs then fs:SetTextColor(1, 0.82, 0) end
        button:SetScript("OnEnter", function(self)
            local font = self:GetFontString()
            if font then font:SetTextColor(1.0, 0.92, 0.45) end
            SetProfessionTooltip(self)
        end)
        button:SetScript("OnLeave", function(self)
            local font = self:GetFontString()
            if font then font:SetTextColor(1, 0.82, 0) end
            GameTooltip:Hide()
        end)
    end

    for i = 1, 6 do
        local row = MainPanel(pf.contentChild, 1)
        row:SetHeight(48)
        row:SetPoint("TOPLEFT", pf.contentChild, "TOPLEFT", 0, -2 - ((i - 1) * 52))
        row:SetPoint("RIGHT", pf.contentChild, "RIGHT", -4, 0)

        row.title = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        row.title:SetPoint("LEFT", row, "LEFT", 12, 0)
        row.title:SetPoint("RIGHT", row, "RIGHT", -205, 0)
        row.title:SetHeight(28)
        row.title:SetJustifyH("LEFT")
        row.title:SetTextColor(0.55, 0.55, 0.55)
        row.title:SetText("Profession")

        row.skill = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        row.skill:SetPoint("RIGHT", row, "RIGHT", -12, 0)
        row.skill:SetWidth(86)
        row.skill:SetJustifyH("RIGHT")
        row.skill:SetTextColor(0.55, 0.55, 0.55)
        row.skill:SetText("-")

        local openButton = CreateFrame("Button", nil, pf.contentChild, "UIPanelButtonTemplate")
        openButton:SetSize(72, 24)
        openButton:SetPoint("RIGHT", row, "RIGHT", -108, 0)
        openButton:SetFrameLevel(pf.contentChild:GetFrameLevel() + 40)
        openButton:RegisterForClicks("LeftButtonUp")
        openButton:SetScript("OnClick", StandardProfessionOpenClick)
        StyleProfessionOpenButton(openButton)
        openButton:Hide()
        row.openButton = openButton

        local secureOpenButton = CreateFrame("Button", nil, pf.contentChild, "SecureActionButtonTemplate")
        secureOpenButton:SetSize(72, 24)
        secureOpenButton:SetPoint("RIGHT", row, "RIGHT", -108, 0)
        secureOpenButton:SetFrameLevel(pf.contentChild:GetFrameLevel() + 80)
        secureOpenButton:EnableMouse(true)
        secureOpenButton:RegisterForClicks("AnyDown", "AnyUp")
        secureOpenButton:SetScript("OnEnter", function(self)
            local visual = self.visualButton
            local font = visual and visual:GetFontString()
            if font then font:SetTextColor(1.0, 0.92, 0.45) end
            SetProfessionTooltip(self)
        end)
        secureOpenButton:SetScript("OnLeave", function(self)
            local visual = self.visualButton
            local font = visual and visual:GetFontString()
            if font then font:SetTextColor(1, 0.82, 0) end
            GameTooltip:Hide()
        end)
        secureOpenButton.visualButton = openButton
        secureOpenButton:Hide()
        row.secureOpenButton = secureOpenButton

        pf.profRows[i] = row
    end

    pf.emptyText = pf.contentChild:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    pf.emptyText:SetPoint("TOPLEFT", pf.contentChild, "TOPLEFT", 0, -318)
    pf.emptyText:SetPoint("RIGHT", pf.contentChild, "RIGHT", -10, 0)
    pf.emptyText:SetJustifyH("LEFT")
    pf.emptyText:SetTextColor(0.72, 0.72, 0.72)
    pf.emptyText:SetText("")
    pf.emptyText:Hide()

    pf.cooldownTitle=MainSectionTitle(pf.contentChild,"Profession cooldowns")
    pf.cooldownTitle:SetPoint("TOPLEFT",pf.contentChild,"TOPLEFT",0,-350)

    pf.cooldownEmpty=MainSmallText(pf.contentChild)
    pf.cooldownEmpty:SetPoint("TOPLEFT",pf.cooldownTitle,"BOTTOMLEFT",0,-7)
    pf.cooldownEmpty:SetPoint("RIGHT",pf.contentChild,"RIGHT",-10,0)
    pf.cooldownEmpty:SetJustifyH("LEFT")
    pf.cooldownEmpty:SetTextColor(.62,.62,.62)

    pf.cooldownRows={}
    for i=1,24 do
        local row=CreateFrame("Frame",nil,pf.contentChild)
        row:SetHeight(24)
        -- Use absolute coordinates inside the scroll child. Keeping the left
        -- edge independent from a stretched RIGHT anchor prevents icon/text
        -- jitter while the main window is being resized.
        row:SetPoint("TOPLEFT",pf.contentChild,"TOPLEFT",0,-382-((i-1)*25))
        row:SetWidth(math.max(400,(pf.contentChild:GetWidth() or 600)-4))
        row.icon=row:CreateTexture(nil,"ARTWORK"); row.icon:SetSize(18,18); row.icon:SetPoint("LEFT",row,"LEFT",2,0)
        row.profession=MainSmallText(row); row.profession:SetPoint("LEFT",row.icon,"RIGHT",6,0); row.profession:SetWidth(105); row.profession:SetJustifyH("LEFT"); row.profession:SetTextColor(1,.82,0)
        row.recipe=MainSmallText(row); row.recipe:SetPoint("LEFT",row.profession,"RIGHT",8,0); row.recipe:SetPoint("RIGHT",row,"RIGHT",-100,0); row.recipe:SetJustifyH("LEFT")
        row.status=row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); row.status:SetPoint("RIGHT",row,"RIGHT",-8,0); row.status:SetWidth(86); row.status:SetJustifyH("RIGHT")
        pf.cooldownRows[i]=row
    end

    pf:HookScript("OnSizeChanged",function(self)
        if self.contentChild then
            local childWidth=math.max(420,(self:GetWidth() or 600)-54)
            self.contentChild:SetWidth(childWidth)
            for _,row in ipairs(self.cooldownRows or {}) do
                row:SetWidth(math.max(400,childWidth-4))
            end
        end
        UpdateProfessionsFooterLayout(self)
    end)

    pf.recipeScanButton = CreateFrame("Button", nil, pf, "UIPanelButtonTemplate")
    pf.recipeScanButton:SetSize(112, 24)
    pf.recipeScanButton:SetPoint("BOTTOMLEFT", pf, "BOTTOMLEFT", 18, 18)
    pf.recipeScanButton:SetText("Recipe Scan")
    pf.recipeScanButton:SetScript("OnClick", function()
        AA:ShowRecipeGuide()
    end)
    pf.recipeScanButton:Hide()

    pf.recipeScanStatus = pf:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    pf.recipeScanStatus:SetPoint("LEFT", pf.recipeScanButton, "RIGHT", 10, 0)
    pf.recipeScanStatus:SetWidth(255)
    pf.recipeScanStatus:SetJustifyH("LEFT")
    pf.recipeScanStatus:SetTextColor(0.70, 0.70, 0.70)
    pf.recipeScanStatus:Hide()

    -- Recipe search is available directly from Professions as well as Summary.
    pf.searchButton=CreateFrame("Button",nil,pf,"UIPanelButtonTemplate")
    pf.searchButton:SetSize(54,22)
    pf.searchButton:SetPoint("BOTTOMRIGHT",pf,"BOTTOMRIGHT",-18,19)
    pf.searchButton:SetText("Search")

    pf.searchBox=CreateFrame("EditBox",nil,pf,"InputBoxTemplate")
    pf.searchBox:SetSize(180,20)
    pf.searchBox:SetPoint("RIGHT",pf.searchButton,"LEFT",-8,0)
    pf.searchBox:SetAutoFocus(false)

    pf.searchLabel=MainSectionTitle(pf,"Recipe Search:")
    pf.searchLabel:SetPoint("RIGHT",pf.searchBox,"LEFT",-8,0)

    local function RunProfessionRecipeSearch()
        AA:SearchRecipes(pf.searchBox:GetText() or "")
        pf.searchBox:ClearFocus()
    end
    pf.searchButton:SetScript("OnClick",RunProfessionRecipeSearch)
    pf.searchBox:SetScript("OnEnterPressed",RunProfessionRecipeSearch)

    -- Legendary detail: complete chronological Wrathion chain with scrolling
    -- and expandable quest details. Only one quest is expanded at a time.
    local lg=frame.detailFrames.legendary
    CreateMainDetailHeader(lg)
    lg.milestoneRows={}
    lg.chapterHeaders={}

    lg.scrollFrame=CreateFrame("ScrollFrame","AlternatorLegendaryScrollFrame",lg,"UIPanelScrollFrameTemplate")
    lg.scrollFrame:SetPoint("TOPLEFT",lg,"TOPLEFT",10,-70)
    lg.scrollFrame:SetPoint("BOTTOMRIGHT",lg,"BOTTOMRIGHT",-30,12)
    lg.scrollFrame:EnableMouseWheel(true)

    lg.scrollChild=CreateFrame("Frame",nil,lg.scrollFrame)
    lg.scrollChild:SetWidth(math.max(420,(lg:GetWidth() or 600)-54))
    lg.scrollChild:SetHeight(1)
    lg.scrollFrame:SetScrollChild(lg.scrollChild)

    lg.scrollFrame:SetScript("OnMouseWheel",function(self,delta)
        local current=self:GetVerticalScroll() or 0
        local maximum=self:GetVerticalScrollRange() or 0
        local target=current-(delta*45)
        if target<0 then target=0 end
        if target>maximum then target=maximum end
        self:SetVerticalScroll(target)
    end)

    local legendaryY=-2
    local lastChapter=nil
    for i,m in ipairs(LEGENDARY_MILESTONES) do
        if m.chapter~=lastChapter then
            lastChapter=m.chapter
            local chapter=CreateFrame("Frame",nil,lg.scrollChild)
            chapter:SetHeight(24)
            chapter:SetPoint("TOPLEFT",lg.scrollChild,"TOPLEFT",0,legendaryY)
            chapter:SetPoint("RIGHT",lg.scrollChild,"RIGHT",-4,0)
            chapter.text=chapter:CreateFontString(nil,"OVERLAY","GameFontNormal")
            chapter.text:SetPoint("LEFT",chapter,"LEFT",4,0)
            chapter.text:SetText(m.chapterTitle or ("Chapter "..tostring(m.chapter)))
            chapter.text:SetTextColor(1,0.82,0)
            chapter.line=chapter:CreateTexture(nil,"ARTWORK")
            chapter.line:SetPoint("LEFT",chapter.text,"RIGHT",10,0)
            chapter.line:SetPoint("RIGHT",chapter,"RIGHT",-4,0)
            chapter.line:SetHeight(1)
            chapter.line:SetTexture(0.55,0.40,0.12,0.65)
            lg.chapterHeaders[m.chapter]=chapter
            legendaryY=legendaryY-28
        end

        local row=CreateFrame("Button",nil,lg.scrollChild)
        row:SetHeight(34)
        row:SetPoint("TOPLEFT",lg.scrollChild,"TOPLEFT",0,legendaryY)
        row:SetPoint("RIGHT",lg.scrollChild,"RIGHT",-4,0)
        row:RegisterForClicks("LeftButtonUp")
        row.bg=row:CreateTexture(nil,"BACKGROUND")
        row.bg:SetAllPoints(row)
        row.arrow=row:CreateFontString(nil,"OVERLAY","GameFontNormal")
        row.arrow:SetPoint("LEFT",row,"LEFT",9,0)
        row.arrow:SetWidth(14)
        row.arrow:SetJustifyH("CENTER")
        row.arrow:SetText("+")
        row.name=row:CreateFontString(nil,"OVERLAY","GameFontHighlight")
        row.name:SetPoint("LEFT",row.arrow,"RIGHT",4,0)
        row.name:SetPoint("RIGHT",row,"RIGHT",-176,0)
        row.name:SetJustifyH("LEFT")
        row.status=row:CreateFontString(nil,"OVERLAY","GameFontNormal")
        row.status:SetPoint("RIGHT",row,"RIGHT",-12,0)
        row.status:SetWidth(154)
        row.status:SetJustifyH("RIGHT")

        row.detail=CreateFrame("Frame",nil,lg.scrollChild)
        row.detail:SetBackdrop({
            bgFile="Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
            edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",
            tile=true,tileSize=16,edgeSize=12,
            insets={left=4,right=4,top=4,bottom=4},
        })
        row.detail:SetBackdropColor(0.025,0.025,0.025,0.97)
        row.detail:SetBackdropBorderColor(0.6,0.2,0.2,1)
        row.detail:SetFrameLevel(lg.scrollChild:GetFrameLevel()+2)
        row.detail.description=row.detail:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        row.detail.description:SetPoint("TOPLEFT",row.detail,"TOPLEFT",12,-11)
        row.detail.description:SetPoint("RIGHT",row.detail,"RIGHT",-12,0)
        row.detail.description:SetJustifyH("LEFT")
        row.detail.description:SetJustifyV("TOP")
        row.detail.description:SetWordWrap(true)
        row.detail.status=row.detail:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        row.detail.status:SetPoint("TOPLEFT",row.detail.description,"BOTTOMLEFT",0,-8)
        row.detail.status:SetJustifyH("LEFT")
        row.detail.progress=row.detail:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        row.detail.progress:SetPoint("LEFT",row.detail.status,"RIGHT",18,0)
        row.detail.progress:SetJustifyH("LEFT")
        row.detail.questID=row.detail:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
        row.detail.questID:SetPoint("BOTTOMRIGHT",row.detail,"BOTTOMRIGHT",-10,8)
        row.detail.questID:SetJustifyH("RIGHT")
        row.detail:Hide()

        local milestoneKey=m.key
        row:SetScript("OnClick",function()
            AA:SetLegendaryExpanded(lg,milestoneKey,true)
        end)
        row:SetScript("OnEnter",function(self)
            if self.bg then self.bg:SetAlpha(1) end
        end)
        row:SetScript("OnLeave",function(self)
            if self.bg then self.bg:SetAlpha(0.92) end
        end)

        lg.milestoneRows[i]=row
        legendaryY=legendaryY-38
    end
    lg.scrollChild:SetHeight(math.max(1,-legendaryY+8))

    lg:HookScript("OnSizeChanged",function(self)
        if self.scrollChild then
            self.scrollChild:SetWidth(math.max(420,(self:GetWidth() or 600)-54))
            if AA.RefreshLegendaryDetail and AA.dashboardFrame and AA.dashboardFrame.selectedCharacterKey then
                local selected=AA:GetCharacterByKey(AA.dashboardFrame.selectedCharacterKey)
                if selected then AA:RefreshLegendaryDetail(selected) end
            end
        end
    end)

    -- Collections detail
    local co=frame.detailFrames.collections; CreateMainDetailHeader(co)
    co.help=MainSmallText(co)
    co.help:SetPoint("TOPLEFT",co,"TOPLEFT",18,-76)
    co.help:SetPoint("RIGHT",co,"RIGHT",-18,0)
    co.help:SetText("Hover a count to compare this stored collection snapshot with the closest compatible character.")
    co.help:SetJustifyH("LEFT")
    local function collectionCard(x,titleText)
        local card=MainPanel(co,1); card:SetSize(230,120); card:SetPoint("TOPLEFT",co.help,"BOTTOMLEFT",x,-18); card:EnableMouse(true)
        card.title=MainSectionTitle(card,titleText); card.title:SetPoint("TOP",card,"TOP",0,-15)
        card.value=card:CreateFontString(nil,"OVERLAY","GameFontNormalLarge"); card.value:SetPoint("CENTER",card,"CENTER",0,-8)
        card:SetScript("OnEnter",function(self) AA:ShowDashboardCellTooltip(self) end); card:SetScript("OnLeave",function() GameTooltip:Hide(); AA:HideCollectionTooltip() end)
        return card
    end
    co.mountCard=collectionCard(0,"Mounts"); co.mountValue=co.mountCard.value
    co.petCard=collectionCard(250,"Companions"); co.petValue=co.petCard.value

    -- Summary detail: account overview above the existing global table.
    local sm=frame.detailFrames.summary
    sm.accountPanel=MainShellPanel(sm,1)
    sm.accountPanel:SetPoint("TOPLEFT",sm,"TOPLEFT",12,-10)
    sm.accountPanel:SetPoint("TOPRIGHT",sm,"TOPRIGHT",-12,-10)
    sm.accountPanel:SetHeight(170)

    sm.title=MainSectionTitle(sm.accountPanel,"Account Overview")
    sm.title:SetPoint("TOPLEFT",sm.accountPanel,"TOPLEFT",10,-9)
    sm.scope=MainSmallText(sm.accountPanel)
    sm.scope:SetPoint("TOPRIGHT",sm.accountPanel,"TOPRIGHT",-10,-10)
    sm.scope:SetJustifyH("RIGHT")

    sm.accountRows={}
    local function accountRow(key)
        local row=CreateFrame("Frame",nil,sm.accountPanel)
        row:SetHeight(20)
        row.label=MainSectionTitle(row,"")
        row.label:SetPoint("TOPLEFT",row,"TOPLEFT",0,-2)
        row.label:SetWidth(106)
        row.label:SetJustifyH("LEFT")
        row.buttons={}
        sm.accountRows[key]=row
        return row
    end
    accountRow("characters")
    accountRow("played")
    accountRow("races")
    accountRow("professions")
    accountRow("gold")
    accountRow("currencyAlerts")

    sm.status=MainSmallText(sm)
    sm.status:SetPoint("TOPRIGHT",sm.accountPanel,"BOTTOMRIGHT",0,-14)
    sm.status:SetJustifyH("RIGHT")

    local viewLabel=MainSectionTitle(sm,"View:")
    viewLabel:SetPoint("TOPLEFT",sm.accountPanel,"BOTTOMLEFT",0,-14)
    local viewDD=CreateFrame("Frame","AlternatorDashboardViewDropDown",sm,"UIDropDownMenuTemplate")
    viewDD:SetPoint("LEFT",viewLabel,"RIGHT",-12,-2)
    self:SetupDashboardViewDropDown(viewDD,145)
    self.dashboardViewDropDown=viewDD
    sm.viewDropDown=viewDD

    sm.recipeGuide=CreateFrame("Button",nil,sm,"UIPanelButtonTemplate")
    sm.recipeGuide:SetSize(82,20)
    sm.recipeGuide:SetPoint("LEFT",viewDD,"RIGHT",10,2)
    sm.recipeGuide:SetText("Recipe scan")
    sm.recipeGuide:SetScript("OnClick",function() AA:ShowRecipeGuide() end)

    -- Summary Recipe Search intentionally mirrors the working Professions
    -- construction: create the Search button first, then anchor the edit box
    -- to its left, and finally the label to the edit box. A uniquely named
    -- edit box also gives the old 5.4.8 InputBoxTemplate unique texture names.
    sm.searchButton=CreateFrame("Button",nil,sm,"UIPanelButtonTemplate")
    sm.searchButton:SetSize(54,22)
    sm.searchButton:SetPoint("LEFT",sm.recipeGuide,"RIGHT",296,0)
    sm.searchButton:SetText("Search")

    sm.searchBox=CreateFrame("EditBox","AlternatorSummaryRecipeSearchBox",sm,"InputBoxTemplate")
    sm.searchBox:SetSize(180,20)
    sm.searchBox:SetPoint("RIGHT",sm.searchButton,"LEFT",-8,0)
    sm.searchBox:SetAutoFocus(false)
    if sm.searchBox.SetTextInsets then sm.searchBox:SetTextInsets(6,6,0,0) end

    -- MoP's InputBoxTemplate is made from three separate textures. On some
    -- clients the anonymous template could leave its middle texture anchored
    -- to a stale point, producing the two stray horizontal lines seen at the
    -- bottom-right of Summary. Re-anchor every template piece explicitly.
    do
        local boxName=sm.searchBox:GetName()
        local left=_G[boxName.."Left"]
        local middle=_G[boxName.."Middle"] or _G[boxName.."Mid"]
        local right=_G[boxName.."Right"]
        if left then
            left:ClearAllPoints()
            left:SetPoint("LEFT",sm.searchBox,"LEFT",-5,0)
        end
        if right then
            right:ClearAllPoints()
            right:SetPoint("RIGHT",sm.searchBox,"RIGHT",0,0)
        end
        if middle then
            middle:ClearAllPoints()
            if left then middle:SetPoint("LEFT",left,"RIGHT",0,0) else middle:SetPoint("LEFT",sm.searchBox,"LEFT",5,0) end
            if right then middle:SetPoint("RIGHT",right,"LEFT",0,0) else middle:SetPoint("RIGHT",sm.searchBox,"RIGHT",-5,0) end
        end
    end

    sm.searchLabel=MainSectionTitle(sm,"Recipe Search:")
    sm.searchLabel:SetPoint("RIGHT",sm.searchBox,"LEFT",-8,0)

    -- Status uses only the remaining space to the right of Recipe Search.
    sm.status:ClearAllPoints()
    sm.status:SetPoint("LEFT",sm.searchButton,"RIGHT",16,0)
    sm.status:SetPoint("RIGHT",sm.accountPanel,"RIGHT",0,0)
    sm.status:SetJustifyH("RIGHT")

    local function RunSummaryRecipeSearch()
        AA:SearchRecipes(sm.searchBox:GetText() or "")
        sm.searchBox:ClearFocus()
    end
    sm.searchButton:SetScript("OnClick",RunSummaryRecipeSearch)
    sm.searchBox:SetScript("OnEnterPressed",RunSummaryRecipeSearch)

    sm.header=CreateFrame("Frame",nil,sm)
    sm.header:SetPoint("TOPLEFT",sm.accountPanel,"BOTTOMLEFT",0,-48)
    sm.header:SetSize(DashboardTotalWidth(self:GetDashboardView()),DASHBOARD_ROW_HEIGHT)
    sm.header.cells={}
    for _,col in ipairs(DASHBOARD_COLUMNS) do sm.header.cells[col.key]=CreateDashboardCell(sm.header,col,true) end
    PositionDashboardCells(sm.header,self:GetDashboardView())

    sm.scroll=CreateFrame("ScrollFrame","AlternatorSummaryScroll",sm,"FauxScrollFrameTemplate")
    sm.scroll:SetPoint("TOPLEFT",sm.header,"BOTTOMLEFT",0,-2)
    sm.scroll:SetPoint("BOTTOMRIGHT",sm,"BOTTOMRIGHT",-24,8)
    sm.scroll:SetScript("OnVerticalScroll",function(self,offset) FauxScrollFrame_OnVerticalScroll(self,offset,DASHBOARD_ROW_HEIGHT,function() AA:RefreshMainSummary(false) end) end)
    sm.scroll:EnableMouseWheel(true)
    sm.scroll:SetScript("OnMouseWheel",function(self,d) local sb=self.ScrollBar or _G[self:GetName().."ScrollBar"]; if sb then sb:SetValue(sb:GetValue()-(d*DASHBOARD_ROW_HEIGHT*3)) end end)
    sm.rows={}
    for i=1,DASHBOARD_MAX_ROWS do
        local row=CreateFrame("Frame",nil,sm)
        row:SetSize(DashboardTotalWidth(self:GetDashboardView()),DASHBOARD_ROW_HEIGHT)
        row:SetPoint("TOPLEFT",sm.header,"BOTTOMLEFT",0,-2-((i-1)*DASHBOARD_ROW_HEIGHT))
        row.cells={}
        for _,col in ipairs(DASHBOARD_COLUMNS) do row.cells[col.key]=CreateDashboardCell(row,col,false) end
        PositionDashboardCells(row,self:GetDashboardView())
        sm.rows[i]=row
    end

    local grip=CreateFrame("Button",nil,frame); grip:SetSize(18,18); grip:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",-5,5); grip:SetFrameLevel(frame:GetFrameLevel()+20); grip:EnableMouse(true)
    local gu=grip:CreateTexture(nil,"ARTWORK"); gu:SetAllPoints(grip); gu:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    grip:SetScript("OnMouseDown",function(self,b) if b=="LeftButton" then frame:StartSizing("BOTTOMRIGHT") end end)
    grip:SetScript("OnMouseUp",function(self,b) if b=="LeftButton" then frame:StopMovingOrSizing(); AA.db.settings.dashboardSize={width=math.floor(frame:GetWidth()+.5),height=math.floor(frame:GetHeight()+.5)}; AA:RefreshDashboard(false) end end)

    frame:SetScript("OnShow",function(self) if self.Raise then self:Raise() end; AA:RefreshDashboard(true) end)
    frame:SetScript("OnMouseDown",function(self) if self.Raise then self:Raise() end end)
    frame:SetScript("OnSizeChanged",function(self, width, height)
        if AA.dashboardFrame ~= self then return end
        width = tonumber(width) or self:GetWidth()
        height = tonumber(height) or self:GetHeight()
        if width < DASHBOARD_MIN_WIDTH or height < DASHBOARD_MIN_HEIGHT then
            local safeW = math.max(DASHBOARD_MIN_WIDTH, width)
            local safeH = math.max(DASHBOARD_MIN_HEIGHT, height)
            if math.abs(self:GetWidth() - safeW) > 0.5 or math.abs(self:GetHeight() - safeH) > 0.5 then
                self:SetSize(safeW, safeH)
                return
            end
        end
        AA:RefreshDashboard(false)
    end)
    frame:Hide()
    if UISpecialFrames then table.insert(UISpecialFrames,"AlternatorDashboardFrame") end
    self.dashboardFrame=frame
    self:RefreshSortDropDowns(); self:RefreshRealmDropDowns()
    return frame
end

function AA:ToggleDashboard()
    if not self:IsEnabled() then Print("Alternator is disabled. Right-click the minimap button or use /alt options to enable it."); return end
    local frame=self:CreateDashboardFrame()
    if frame:IsShown() then frame:Hide() else frame:Show(); self:RefreshDashboard(true) end
end

SLASH_ALTERNATOR1 = "/alt"
SLASH_ALTERNATOR2 = "/alternator"
SlashCmdList["ALTERNATOR"] = function(message)
    AA:HandleSlashCommand(message)
end

function AA:PrepareLogoutBackup()
    if self._logoutBackupPrepared then return end
    self._logoutBackupPrepared = true
    if self:IsEnabled() then
        -- Money is still available during logout and should be persisted for
        -- the character we are leaving. Profession APIs are less reliable here.
        self.moneySnapshotReady = false
        self:CaptureCurrentCharacterMoney(false)
        self:ScanCurrentCharacterStatistics()
        self:TouchCurrentCharacterLastSeen()
    end
end

eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("PLAYER_LEVEL_UP")
eventFrame:RegisterEvent("PLAYER_LOGOUT")
eventFrame:RegisterEvent("ACHIEVEMENT_EARNED")
eventFrame:RegisterEvent("QUEST_LOG_UPDATE")
eventFrame:RegisterEvent("SKILL_LINES_CHANGED")
eventFrame:RegisterEvent("PLAYER_TALENT_UPDATE")
eventFrame:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED")
eventFrame:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
eventFrame:RegisterEvent("UNIT_INVENTORY_CHANGED")
eventFrame:RegisterEvent("UPDATE_FACTION")
eventFrame:RegisterEvent("TRADE_SKILL_UPDATE")
eventFrame:RegisterEvent("TRADE_SKILL_SHOW")
eventFrame:RegisterEvent("PET_JOURNAL_LIST_UPDATE")
eventFrame:RegisterEvent("COMPANION_UPDATE")
eventFrame:RegisterEvent("PLAYER_MONEY")
eventFrame:RegisterEvent("CURRENCY_DISPLAY_UPDATE")
eventFrame:RegisterEvent("TIME_PLAYED_MSG")
eventFrame:RegisterEvent("ZONE_CHANGED")
eventFrame:RegisterEvent("ZONE_CHANGED_INDOORS")
eventFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")

eventFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        local loadedAddon = ...
        if loadedAddon == ADDON_NAME then
            AA:InitializeDatabase()
            if type(IsAddOnLoaded) == "function" and IsAddOnLoaded("AchievementAlts") then
                Print("Warning: the old AchievementAlts addon is also enabled. Disable/remove AchievementAlts to avoid duplicate Achievement UI hooks and tooltips.")
            end
            AA:CreateOptionsPanel()
            AA:CreateMinimapButton()
            AA:SetMinimapButtonShown(AA:IsMinimapButtonShown())
            if IsAddOnLoaded("Blizzard_AchievementUI") then
                AA:HookAchievementUI()
            end
            if not AA:IsEnabled() then
                AA:SetEnabled(false, true)
            end
        elseif loadedAddon == "Blizzard_AchievementUI" then
            AA:HookAchievementUI()
        end

    elseif event == "PLAYER_LOGIN" then
        AA._logoutBackupPrepared = nil
        if not AA.db then
            AA:InitializeDatabase()
        end
        AA:CreateMinimapButton()
        AA:SetMinimapButtonShown(AA:IsMinimapButtonShown())
        AA.moneySnapshotReady = false
        AA.moneyScanAt = nil
        AA.moneyScanRetryCount = 0
        AA:UpdateCurrentCharacterMetadata()
        AA:SelectCurrentCharacterForDashboardSession()
        if AA:IsEnabled() then
            AA:ScheduleMoneySnapshot(0.75, 10)
            AA:ScheduleStatisticsScan(1.75)
            AA:TouchCurrentCharacterLastSeen()
            AA.lastSeenUpdateAt = GetTime() + 60
            AA.profileScanAt = GetTime() + 1.5
            AA.autoScanAt = GetTime() + AUTO_SCAN_DELAY
        else
            AA.lastSeenUpdateAt = nil
            AA.profileScanAt = nil
            AA.autoScanAt = nil
        end
        if IsAddOnLoaded("Blizzard_AchievementUI") then
            AA:HookAchievementUI()
        end

    elseif event == "PLAYER_ENTERING_WORLD" then
        if AA:IsEnabled() then
            AA:ScheduleProfileScan(1)
            AA:ScheduleStatisticsScan(1.25)
            AA.moneySnapshotReady = false
            AA:ScheduleMoneySnapshot(0.50, 10)
        end

    elseif event == "PLAYER_LEVEL_UP" then
        AA:UpdateCurrentCharacterMetadata()
        if AA:IsEnabled() then
            AA:TouchCurrentCharacterLastSeen()
            AA:ScheduleProfileScan(0.25)
        end

    elseif event == "PLAYER_LOGOUT" then
        -- Finalize AlternatorDB here. The AlternatorBackup companion owns its
        -- SavedVariables file and creates the physical snapshot in its own
        -- PLAYER_LOGOUT handler after this addon has finished updating the DB.
        AA:PrepareLogoutBackup()

    elseif event == "QUEST_LOG_UPDATE" then
        if AA:IsEnabled() then
            AA:ScheduleProfileScan(0.20)
            AA:ScheduleStatisticsScan(0.35)
        end

    elseif event == "SKILL_LINES_CHANGED" then
        if AA:IsEnabled() then
            AA:ScheduleProfileScan(0.40)
        end

    elseif event == "PLAYER_TALENT_UPDATE" or event == "ACTIVE_TALENT_GROUP_CHANGED" then
        if AA:IsEnabled() then
            AA:UpdateCurrentCharacterMetadata()
            AA:ScheduleProfileScan(0.20)
            if AA.dashboardFrame and AA.dashboardFrame:IsShown() then AA:RefreshDashboard(false) end
        end

    elseif event == "PLAYER_EQUIPMENT_CHANGED" then
        if AA:IsEnabled() then
            AA:ScheduleProfileScan(0.25)
        end

    elseif event == "UNIT_INVENTORY_CHANGED" then
        local unit = ...
        if AA:IsEnabled() and (not unit or unit == "player") then
            -- Applying a buckle, socket, enchant or Engineering tinker modifies
            -- the equipped item in-place and may not fire PLAYER_EQUIPMENT_CHANGED.
            AA:ScheduleProfileScan(0.35)
        end

    elseif event == "UPDATE_FACTION" then
        if AA:IsEnabled() and not AA.reputationScanInProgress and (not AA.reputationEventSuppressUntil or GetTime() >= AA.reputationEventSuppressUntil) then
            AA:ScheduleProfileScan(0.35)
        end

    elseif event == "TRADE_SKILL_SHOW" or event == "TRADE_SKILL_UPDATE" then
        if AA:IsEnabled() then
            AA:ScheduleProfileScan(0.40)
            -- The 5.4.8 TradeSkill list often populates over multiple frames.
            -- Capture several delayed passes instead of relying on a single event.
            AA:QueueRecipeCapture(7, 0.12)
        end

    elseif event == "PET_JOURNAL_LIST_UPDATE" or event == "COMPANION_UPDATE" then
        if AA:IsEnabled() then
            local char = AA.db and AA.db.characters and AA.db.characters[AA.currentCharacterKey]
            if char then
                char.collectionsForceDetailScan = true
            end
            AA:ScheduleProfileScan(0.50)
        end

    elseif event == "PLAYER_MONEY" then
        if AA:IsEnabled() then
            AA.moneySnapshotReady = true
            AA.moneyScanAt = nil
            AA.moneyScanRetryCount = 0
            AA:CaptureCurrentCharacterMoney(true)
            AA:UpdateCurrentCharacterMetadata()
            AA:ScheduleStatisticsScan(0.30)
            if AA.dashboardFrame and AA.dashboardFrame:IsShown() then AA:RefreshDashboard(false) end
        end

    elseif event == "TIME_PLAYED_MSG" then
        if AA:IsEnabled() then
            local totalTime, levelTime = ...
            AA:StoreCurrentPlayedTime(totalTime, levelTime)
        end

    elseif event == "CURRENCY_DISPLAY_UPDATE" or event == "ZONE_CHANGED" or event == "ZONE_CHANGED_INDOORS" or event == "ZONE_CHANGED_NEW_AREA" then
        if AA:IsEnabled() then
            AA:UpdateCurrentCharacterMetadata()
            if AA.dashboardFrame and AA.dashboardFrame:IsShown() then AA:RefreshDashboard(false) end
        end

    elseif event == "ACHIEVEMENT_EARNED" then
        local achievementID = ...
        AA:MarkAchievementEarned(achievementID)
    end
end)

eventFrame:SetScript("OnUpdate", function(self, elapsed)
    AA:ProcessQueuedAchievementTooltip()

    if AA.uniqueTabCreateAt and GetTime() >= AA.uniqueTabCreateAt then
        AA.uniqueTabCreateAt = nil
        if AA:IsEnabled() then
            AA:CreateUniqueTab()
        end
    end

    if AA.moneyScanAt and GetTime() >= AA.moneyScanAt then
        AA.moneyScanAt = nil
        if AA:IsEnabled() then
            local money = type(GetMoney) == "function" and tonumber(GetMoney()) or nil
            local retries = tonumber(AA.moneyScanRetryCount) or 0
            if money and money > 0 then
                AA.moneySnapshotReady = true
                AA.moneyScanRetryCount = 0
                AA:CaptureCurrentCharacterMoney(true)
                if AA.dashboardFrame and AA.dashboardFrame:IsShown() then AA:RefreshDashboard(false) end
            else
                retries = retries - 1
                AA.moneyScanRetryCount = retries
                if retries <= 0 then
                    -- A genuine zero-gold character is valid; only commit it after
                    -- the delayed login retries have had time to see real money data.
                    AA.moneySnapshotReady = true
                    AA:CaptureCurrentCharacterMoney(false)
                    if AA.dashboardFrame and AA.dashboardFrame:IsShown() then AA:RefreshDashboard(false) end
                else
                    AA.moneyScanAt = GetTime() + 0.40
                end
            end
        else
            AA.moneyScanRetryCount = 0
        end
    end

    if AA.profileScanAt and GetTime() >= AA.profileScanAt then
        AA.profileScanAt = nil
        if AA:IsEnabled() then
            AA:ScanCurrentCharacterProfile(true)
        end
    end

    if AA.statisticsScanAt and GetTime() >= AA.statisticsScanAt then
        AA.statisticsScanAt = nil
        if AA:IsEnabled() then
            AA:ScanCurrentCharacterStatistics()
            if AA.dashboardFrame and AA.dashboardFrame:IsShown() then AA:RefreshDashboard(false) end
        end
    end

    if AA.recipeScanAt and GetTime() >= AA.recipeScanAt then
        AA.recipeScanAt = nil
        if AA:IsEnabled() then
            AA:ScanOpenTradeSkillRecipes(true)
            local retries = tonumber(AA.recipeScanRetryCount) or 0
            if retries > 0 then
                retries = retries - 1
                AA.recipeScanRetryCount = retries
                if retries > 0 then
                    AA.recipeScanAt = GetTime() + 0.30
                else
                    AA.recipeScanRetryProfession = nil
                end
            end
        else
            AA.recipeScanRetryCount = 0
            AA.recipeScanRetryProfession = nil
        end
    end

    if AA.autoScanAt and GetTime() >= AA.autoScanAt then
        AA.autoScanAt = nil
        if AA:IsEnabled() then
            AA:StartScan(false)
        end
    end

    if AA.lastSeenUpdateAt and GetTime() >= AA.lastSeenUpdateAt then
        if AA:IsEnabled() then
            AA.lastSeenUpdateAt = GetTime() + 60
            AA:TouchCurrentCharacterLastSeen()
        else
            AA.lastSeenUpdateAt = nil
        end
    end

    if AA.scan then
        AA:ProcessScan()
    end
end)

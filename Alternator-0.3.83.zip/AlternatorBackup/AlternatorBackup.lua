-- Alternator Backup companion for WoW 5.4.8
-- WoW addons cannot choose arbitrary filenames/extensions for SavedVariables.
-- Because this is a separate addon, the client persists this table into the
-- separate physical file WTF/.../SavedVariables/AlternatorBackup.lua.

local VERSION = "0.3.83"
local MAX_TODAY_SNAPSHOTS = 10
local DAILY_ROLLOVER_DAYS = 30
local MAX_SNAPSHOTS = MAX_TODAY_SNAPSHOTS + DAILY_ROLLOVER_DAYS
local suppressNextLogoutBackup = false

local function DeepCopy(value, seen)
    if type(value) ~= "table" then return value end
    seen = seen or {}
    if seen[value] then return seen[value] end
    local copy = {}
    seen[value] = copy
    for k, v in pairs(value) do
        copy[DeepCopy(k, seen)] = DeepCopy(v, seen)
    end
    return copy
end

local function CountEntries(tbl)
    local count = 0
    if type(tbl) == "table" then
        for _ in pairs(tbl) do count = count + 1 end
    end
    return count
end

local function BuildDayKey(timestamp)
    if type(timestamp) ~= "number" or timestamp <= 0 or type(date) ~= "function" then return nil end
    local info = date("*t", timestamp)
    if type(info) ~= "table" then return nil end
    return string.format("%04d%02d%02d", tonumber(info.year) or 0, tonumber(info.month) or 0, tonumber(info.day) or 0)
end

local function BuildDayStart(timestamp)
    if type(timestamp) ~= "number" or timestamp <= 0 or type(date) ~= "function" or type(time) ~= "function" then return nil end
    local info = date("*t", timestamp)
    if type(info) ~= "table" then return nil end
    info.hour = 0
    info.min = 0
    info.sec = 0
    return time(info)
end

local function PruneSnapshots(db)
    if type(db) ~= "table" or type(db.snapshots) ~= "table" then return end

    local now = type(time) == "function" and time() or 0
    local todayKey = BuildDayKey(now)
    local todayStart = BuildDayStart(now) or now
    local previousDaysCutoff = todayStart - (DAILY_ROLLOVER_DAYS * 86400)

    local kept = {}
    local keptToday = 0
    local keptDaily = {}

    for _, snapshot in ipairs(db.snapshots) do
        local stamp = type(snapshot) == "table" and (tonumber(snapshot.backupAt) or 0) or 0
        local dayKey = BuildDayKey(stamp)
        if dayKey == todayKey then
            if keptToday < MAX_TODAY_SNAPSHOTS then
                table.insert(kept, snapshot)
                keptToday = keptToday + 1
            end
        else
            if stamp >= previousDaysCutoff and dayKey and not keptDaily[dayKey] then
                table.insert(kept, snapshot)
                keptDaily[dayKey] = true
            end
        end
    end

    db.snapshots = kept
end

local function CountStatisticsCharacters(db)
    local count = 0
    if type(db) == "table" and type(db.characters) == "table" then
        for _, char in pairs(db.characters) do
            if type(char) == "table" and type(char.statistics) == "table" and type(char.statistics.history) == "table" then
                if next(char.statistics.history) ~= nil or char.statistics.scannedAt then
                    count = count + 1
                end
            end
        end
    end
    return count
end

local function CountStatisticsHistoryBuckets(db)
    local count = 0
    if type(db) == "table" and type(db.characters) == "table" then
        for _, char in pairs(db.characters) do
            local history = type(char) == "table" and type(char.statistics) == "table" and char.statistics.history or nil
            if type(history) == "table" then
                for _ in pairs(history) do count = count + 1 end
            end
        end
    end
    return count
end

local function EnsureBackupDatabase()
    if type(AlternatorBackupDB) ~= "table" then
        AlternatorBackupDB = {}
    end

    -- Migrate the old 0.3.78/0.3.79 single-backup format into snapshot #1.
    if type(AlternatorBackupDB.snapshots) ~= "table" then
        local legacy = nil
        if type(AlternatorBackupDB.database) == "table" then
            legacy = {
                backupAt = tonumber(AlternatorBackupDB.backupAt) or 0,
                backupDate = AlternatorBackupDB.backupDate or "Legacy backup",
                alternatorVersion = AlternatorBackupDB.alternatorVersion or "unknown",
                reason = "legacy",
                characterCount = CountEntries(AlternatorBackupDB.database.characters),
                statisticsCharacterCount = CountStatisticsCharacters(AlternatorBackupDB.database),
                historyBucketCount = CountStatisticsHistoryBuckets(AlternatorBackupDB.database),
                database = AlternatorBackupDB.database,
            }
        end

        AlternatorBackupDB = {
            backupVersion = 2,
            maxSnapshots = MAX_SNAPSHOTS,
            snapshots = {},
        }
        if legacy then
            table.insert(AlternatorBackupDB.snapshots, legacy)
        end
    end

    AlternatorBackupDB.backupVersion = 2
    AlternatorBackupDB.maxSnapshots = MAX_SNAPSHOTS
    PruneSnapshots(AlternatorBackupDB)
    return AlternatorBackupDB
end

function AlternatorBackup_SaveNow(reason)
    if type(AlternatorDB) ~= "table" then return false end
    local db = EnsureBackupDatabase()
    local stamp = type(time) == "function" and time() or 0
    local snapshot = {
        backupAt = stamp,
        backupDate = type(date) == "function" and date("%Y-%m-%d %H:%M:%S", stamp) or "",
        alternatorVersion = AlternatorDB.lastAddonVersion or VERSION,
        reason = reason or "logout",
        characterCount = CountEntries(AlternatorDB.characters),
        statisticsCharacterCount = CountStatisticsCharacters(AlternatorDB),
        historyBucketCount = CountStatisticsHistoryBuckets(AlternatorDB),
        database = DeepCopy(AlternatorDB),
    }

    table.insert(db.snapshots, 1, snapshot)
    PruneSnapshots(db)
    db.lastBackupAt = stamp
    db.lastBackupDate = snapshot.backupDate
    return true
end

function AlternatorBackup_GetSnapshotCount()
    local db = EnsureBackupDatabase()
    return #db.snapshots
end

function AlternatorBackup_GetSnapshotInfo(index)
    local db = EnsureBackupDatabase()
    local snap = db.snapshots[tonumber(index) or 0]
    if type(snap) ~= "table" then return nil end
    return {
        index = tonumber(index),
        backupAt = tonumber(snap.backupAt) or 0,
        backupDate = snap.backupDate or "Unknown",
        alternatorVersion = snap.alternatorVersion or "unknown",
        reason = snap.reason or "logout",
        characterCount = tonumber(snap.characterCount) or CountEntries(snap.database and snap.database.characters),
        statisticsCharacterCount = tonumber(snap.statisticsCharacterCount) or CountStatisticsCharacters(snap.database),
        historyBucketCount = tonumber(snap.historyBucketCount) or CountStatisticsHistoryBuckets(snap.database),
    }
end

function AlternatorBackup_RestoreSnapshot(index)
    local db = EnsureBackupDatabase()
    local snap = db.snapshots[tonumber(index) or 0]
    if type(snap) ~= "table" or type(snap.database) ~= "table" then return false end

    -- Copy the target before creating the safety snapshot, because inserting the
    -- safety snapshot changes the snapshot indices.
    local targetDatabase = DeepCopy(snap.database)
    AlternatorBackup_SaveNow("pre-restore")

    -- The main addon will reload the UI immediately after this. Avoid creating a
    -- second logout snapshot of the restored DB during that reload.
    suppressNextLogoutBackup = true
    AlternatorDB = targetDatabase
    return true
end

function AlternatorBackup_ShouldSkipNextLogout()
    if suppressNextLogoutBackup then
        suppressNextLogoutBackup = false
        return true
    end
    return false
end

function AlternatorBackup_GetMaxSnapshots()
    return MAX_SNAPSHOTS
end

function AlternatorBackup_GetRetentionPolicyText()
    return string.format("Up to %d newest snapshots from today plus the newest snapshot from each previous day for the last %d days.", MAX_TODAY_SNAPSHOTS, DAILY_ROLLOVER_DAYS)
end

-- Initialize/migrate as soon as the companion loads. The actual automatic
-- snapshot is intentionally triggered by Alternator's PLAYER_LOGOUT handler,
-- after Alternator has written its final character/statistics values.
EnsureBackupDatabase()

AlternatorBackup 0.3.83
=========================

Companion backup addon for Alternator. Keep this folder enabled together with Alternator.

WoW writes its SavedVariables to a separate physical file:
WTF/Account/<ACCOUNT>/SavedVariables/AlternatorBackup.lua

The file keeps up to 10 newest complete AlternatorDB snapshots from the current day plus the newest snapshot from each previous day for the last 30 days. Automatic snapshots are created on successful logout/reload after Alternator finishes its final character/statistics scan. Manual snapshots and restore are available from Interface > AddOns > Alternator > Backup & Restore or /alt backups.

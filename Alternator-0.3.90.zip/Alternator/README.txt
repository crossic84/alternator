Alternator 0.3.0
================

Main window
-----------
Alternator now uses an alt-manager style layout. The left side is a scrollable character list; the right side contains Overview, Professions, Legendary Cloak, Mounts & Companions and Summary tabs.

Summary preserves the previous account-wide table layout. Inside Summary you can still switch the global table between Professions, Legendary Cloak and Mounts & Companions.

Character resources
-------------------
Each login/profile scan stores the character's last known zone/subzone, money and selected MoP currency balances. Currency visibility can be configured in Interface -> AddOns -> Alternator. Character cards show gold plus the first three enabled currencies; hovering a character card shows every enabled tracked currency. The Overview tab shows the complete enabled currency list for the selected character.

Alternator v0.2.4
World of Warcraft: Mists of Pandaria 5.4.8 (Interface 50400)
Author: Crossic

OVERVIEW
========
Alternator keeps account-wide local snapshots of information that the MoP 5.4.8 client normally exposes only for the currently logged-in character.

Main features:
- Character-specific achievement ownership and completion dates
- Unique achievements and Oldest Shared Achievements inside Blizzard's Achievement UI
- Character achievement-point totals calculated from achievements actually earned by that character
- Realm-scoped comparisons
- Character Overview opened from the minimap button
- Switchable Overview views: Professions, Legendary Cloak, Mounts & Companions
- Stored profession recipe snapshots and recipe search across alts
- Manual deletion of stored characters

INSTALLATION
============
Extract the Alternator folder into Interface/AddOns/ and make sure the final path is:
  Interface/AddOns/Alternator/Alternator.toc

If the old AchievementAlts addon is still installed, disable/remove it to avoid duplicate hooks.

MINIMAP BUTTON
==============
Left click  - Toggle Character Overview
Right click - Open Interface > AddOns > Alternator
Drag        - Move around the minimap

The position is saved account-wide. Settings also contain a Reset minimap position button.

CHARACTER OVERVIEW
==================
Use the View dropdown at the top of the window.

1) Professions
--------------
Shows:
- Full name of primary profession 1 + skill
- Full name of primary profession 2 + skill
- Archaeology
- Fishing
- Cooking
- First Aid

Profession color:
- Green: 600
- Yellow/orange: 450-599
- Red: below 450 / not learned

Click the FULL profession name to open Alternator's stored recipe snapshot for that character.

Recipe snapshots:
- Alternator scans the legacy 5.4.8 TradeSkill API whenever you open/update a profession window.
- Stored recipes are MERGED, not replaced, so an accidentally filtered/collapsed profession window cannot erase previously known recipes.
- For best coverage, open each crafting profession at least once on each character with the normal recipe list visible.
- The Professions view includes Search recipes. Search results show every stored character/profession that knows a matching recipe in the selected realm scope.
- /alt recipes <text> performs the same search.

Important 5.4 limitation:
Patch 5.4 changed trade-skill hyperlinks so the Blizzard TradeSkill window cannot reliably be opened for an arbitrary offline character. Alternator therefore uses its own read-only stored recipe window for offline alts instead of pretending Blizzard's live TradeSkillFrame belongs to that character.

2) Legendary Cloak
------------------
Tracks these milestones:
- A Test of Valor
  Alliance: 32474
  Horde: 32476
- PvP
  Alliance: The Lion Roars (32389)
  Horde: Glory to the Horde (32431)
- Secrets of the First Empire (32591)
- The Crown of Heaven (32595)
- Echoes of the Titans (32596)
- Cloak of Virtue (32861)
- A Pandaren Legend (33104)

Cell colors:
- Green + done: completed
- Red + blank: not completed / not active
- Orange: active quest; objective progress is shown as current/required when the 5.4.8 API exposes it

3) Mounts & Companions
----------------------
Shows the mount count and battle-pet/companion count seen while each character was logged in.

Hover a Mounts or Companions number to compare that character with the closest complete stored snapshot in the active realm scope. The collection tooltip shows the net count difference plus the full list of entries that exist only on the hovered character's snapshot. Long lists are laid out in multiple compact columns (normally about 10 entries per column).

A different-faction mount comparison can contain many faction counterpart substitutions even when the numeric count differs by only one. Alternator labels that case explicitly; the full list is a snapshot difference, not a claim that every listed mount is account-unique.

Detailed collection comparison requires a verified 0.2.4+ snapshot for that character. Alternator validates that the number of captured mount/pet entries matches the count reported by the game before using a snapshot. Older detail snapshots are rebuilt automatically when the character is logged.

MoP note: mounts and battle-pet collections became account-wide in 5.0.4. These columns are therefore snapshots of the collection visible from that character and will usually be the same across alts (with possible usability/faction differences depending on the client/core).

ACHIEVEMENT TAB
===============
The embedded Unique tab still provides:
- Unique Achievements
- Oldest Shared Achievements
- Realm filters
- Character sorting
- Per-character deletion

Each character row now also shows its character-specific Achievement Points, calculated by summing points for achievements where the API says wasEarnedByMe=true.
Older Alternator snapshots show ? AP until that character completes a fresh achievement scan with v0.2.0+.

REALM FILTER
============
The selected realms are the actual comparison/search scope.
If only Helios is selected, other realms are ignored by:
- Unique calculations
- Oldest calculations
- Achievement tooltips
- Character Overview
- Recipe search

SCANNING LIMITATIONS
====================
The 5.4.8 addon API cannot read arbitrary offline characters. Log each character at least once.

For recipe knowledge, the TradeSkill API must actually load that profession. Open each crafting profession once on each character so Alternator can capture and retain the recipe list.

SLASH COMMANDS
==============
/alt overview                  Toggle Character Overview
/alt scan                      Rescan profile + achievements
/alt profile                   Rescan professions, collections and cloak progress
/alt recipes <text>            Search stored recipes
/alt chars                     List stored/scanned characters
/alt unique                    Unique-achievement summary
/alt uniqueui                  Open embedded Unique tab
/alt unique <character> [page] List one character's unique achievements
/alt who <achievementID>       Show who has/misses an achievement
/alt status                    Show addon/scanning status
/alt debug                     Achievement UI hook diagnostics
/alt options                   Open Interface > AddOns > Alternator
/alt remove <character>        Remove one stored character
/alt reset confirm             Erase the Alternator database

WINDOWS / LAYERING
==================
Character Overview and stored Recipe windows use a compact layout with an opaque dark background.
They are top-level dialog frames: clicking a window raises it above the other Alternator window.

ACHIEVEMENT POINTS
==================
Unique/Oldest character rows show character-specific AP / total account AP seen while that character was last logged.
Example: 386 unique | 167 / 20670 AP
Older snapshots show ? for the total until that character is logged/scanned again.

Cooking / First Aid recipe snapshots
-----------------------------------
In the Professions view, click the Cooking or First Aid skill number to open the stored recipe snapshot for that character. Recipe search includes these professions after their trade-skill window has been opened at least once on that character.

Recipe Scan Guide (v0.2.12+)
-----------------------------
In the Professions view click "Recipe scan" (or use /alt recipescan). The guide shows every recipe-capable profession on the current character, including Cooking and First Aid. Click Open/Refresh for a specific profession, or Open next missing to step through them. Alternator captures recipes automatically when the standard TradeSkill window loads. Due to the 5.4.8 API limitation, the actual TradeSkill list still has to be loaded at least once per profession/character; the guide automates the opening and tracks completion.


Missing achievements
--------------------
The Achievement window includes a Missing tab that groups achievements not earned by any scanned character. It uses all scanned characters across all realms and reads the full 5.4.8 client achievement catalogue, including hidden/incomplete achievements and Feats of Strength when exposed by the client API.


Character statistics (0.3.66+)
--------------------------------
The Character Overview stores lifetime quest and wealth statistics from the WoW 5.4.8 Statistics API. Period views (Today / 7 days / 30 days / This month / Custom days) are built from compact daily deltas recorded by Alternator, so period history starts only after the character has been scanned by version 0.3.66 or newer. The AddOns settings panel can include or exclude daily repeatable quest completions from the displayed quest total.

BACKUP COMPANION (0.3.78+)
--------------------------
The release archive also contains the optional AlternatorBackup addon folder.
Keep both Alternator and AlternatorBackup in Interface/AddOns to enable a second
physical SavedVariables copy.  On logout, AlternatorBackup stores a deep copy
of AlternatorDB in:

  WTF/Account/<ACCOUNT>/SavedVariables/AlternatorBackup.lua

World of Warcraft does not allow addons to create arbitrary filenames or file
extensions, so a file named Alternator.luabackup cannot be created directly by
addon Lua.  AlternatorBackup.lua is the separate physical backup equivalent.


BACKUP & RESTORE (0.3.80)
-------------------------
Install both Alternator and AlternatorBackup folders. AlternatorBackup stores lightweight Character Statistics recovery snapshots automatically on Logout / Exit Game (10 recent plus the newest snapshot from each of the last 30 active days). /reload does not create an automatic snapshot. The Backup Manager also supports up to 3 manual Full backups containing the complete AlternatorDB. Statistics restore merges only Character Statistics; Full restore replaces the complete AlternatorDB. Both restore modes create an appropriate safety backup first and then reload the UI.

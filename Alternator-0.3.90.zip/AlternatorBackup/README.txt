AlternatorBackup 0.3.90

Internal recovery companion for Alternator.

This separate addon exists so WoW stores the recovery history in a separate physical SavedVariables file: AlternatorBackup.lua. One addon can declare multiple SavedVariables, but WoW still writes them into that addon's single SavedVariables file.

The companion stores lightweight Character Statistics snapshots automatically on Logout / Exit Game. It keeps 10 automatic Recent statistics snapshots plus the newest snapshot from each of the last 30 active days; /reload creates no automatic snapshot. Manual Statistics and Full backups use a separate shared 10-backup rotation. Manual backups show Saving during the session in which they were created and are confirmed after the next SavedVariables load. Statistics restore merges Character Statistics; Full restore replaces the complete AlternatorDB. Backups can be filtered and deleted from the Backup Manager.
